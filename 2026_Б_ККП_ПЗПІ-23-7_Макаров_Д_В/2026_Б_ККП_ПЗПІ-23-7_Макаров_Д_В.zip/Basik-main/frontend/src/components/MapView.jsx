import { useMemo } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Link } from "react-router-dom";
import { getListingCoords, DEFAULT_CENTER } from "../utils/coords";
import { getCoverPhoto } from "../utils/listingImages";

// Custom price-pill marker (Booking-style).
const priceIcon = (price, active = false) =>
  L.divIcon({
    className: "basik-price-marker",
    html: `<div style="
      background:${active ? "#111827" : "#ffffff"};
      color:${active ? "#ffffff" : "#111827"};
      border:1px solid #111827;
      border-radius:9999px;
      padding:3px 10px;
      font-size:12px;
      font-weight:600;
      box-shadow:0 1px 4px rgba(0,0,0,0.15);
      white-space:nowrap;
      transform:translate(-50%, -50%);
      ">${price} грн</div>`,
    iconSize: [0, 0],
    iconAnchor: [0, 0],
  });

const FitBounds = ({ points }) => {
  const map = useMap();
  if (points.length > 0) {
    const bounds = L.latLngBounds(points.map((p) => [p.lat, p.lng]));
    map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
  }
  return null;
};

// listings: array OR single listing
// height: tailwind class or px
const MapView = ({ listings = [], listing = null, height = "h-96", activeId = null, onMarkerClick }) => {
  const items = useMemo(() => {
    if (listing) return [listing];
    return listings.filter((l) => l && l._id);
  }, [listings, listing]);

  const points = useMemo(
    () => items.map((l) => ({ ...getListingCoords(l), listing: l })),
    [items]
  );

  const center = points[0]
    ? [points[0].lat, points[0].lng]
    : [DEFAULT_CENTER.lat, DEFAULT_CENTER.lng];

  return (
    <div className={`${height} w-full rounded-lg overflow-hidden border border-gray-200 z-0 relative`}>
      <MapContainer
        center={center}
        zoom={13}
        scrollWheelZoom
        style={{ height: "100%", width: "100%" }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {points.map((p) => {
          const active = activeId === p.listing._id;
          return (
            <Marker
              key={p.listing._id}
              position={[p.lat, p.lng]}
              icon={priceIcon(p.listing.price_per_hour, active)}
              eventHandlers={{
                click: () => onMarkerClick && onMarkerClick(p.listing._id),
              }}
            >
              <Popup>
                <Link
                  to={`/listing/${p.listing._id}`}
                  className="block w-44 no-underline text-gray-900"
                >
                  <img
                    src={getCoverPhoto(p.listing)}
                    alt={p.listing.title}
                    className="w-full h-24 object-cover rounded mb-1.5"
                  />
                  <p className="text-sm font-semibold line-clamp-2">{p.listing.title}</p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {p.listing.price_per_hour} грн/год
                  </p>
                </Link>
              </Popup>
            </Marker>
          );
        })}
        {points.length > 1 && <FitBounds points={points} />}
      </MapContainer>
    </div>
  );
};

export default MapView;
