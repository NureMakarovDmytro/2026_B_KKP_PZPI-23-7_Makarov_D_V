import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Hero = () => {
  const [search, setSearch] = useState("");
  const [date, setDate] = useState("");
  const [guests, setGuests] = useState(1);
  const navigate = useNavigate();

  const today = new Date().toISOString().split("T")[0];

  const onSubmit = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (date) params.set("date", date);
    if (guests > 1) params.set("maxGuests", guests);
    navigate(`/search?${params.toString()}`);
  };

  return (
    <div className="relative bg-gradient-to-b from-gray-50 to-white overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(0,0,0,0.04),_transparent_60%)]" />
      <div className="relative max-w-5xl mx-auto px-4 pt-16 pb-14 text-center">
        <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4 tracking-tight leading-tight">
          Простори для будь-якої події
        </h1>
        <p className="text-gray-500 text-base md:text-lg mb-9 max-w-2xl mx-auto">
          Понад сотні унікальних локацій погодинно — коворкінги, студії, зали, події.
        </p>

        <form
          onSubmit={onSubmit}
          className="mx-auto max-w-4xl bg-white border border-gray-300 rounded-2xl sm:rounded-full p-2 shadow-sm hover:shadow-md focus-within:border-gray-900 transition flex flex-col sm:flex-row items-stretch gap-2"
        >
          <label className="flex-1 flex items-center gap-2 px-4 py-2 rounded-xl sm:rounded-full hover:bg-gray-50 transition text-left">
            <span className="text-gray-400">📍</span>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider font-semibold text-gray-500">Куди</p>
              <input
                type="text"
                placeholder="Місто або адреса"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full text-sm bg-transparent focus:outline-none placeholder-gray-400"
              />
            </div>
          </label>

          <div className="hidden sm:block w-px bg-gray-200 my-2" />

          <label className="flex items-center gap-2 px-4 py-2 rounded-xl sm:rounded-full hover:bg-gray-50 transition text-left sm:w-44">
            <span className="text-gray-400">📅</span>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider font-semibold text-gray-500">Дата</p>
              <input
                type="date"
                min={today}
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full text-sm bg-transparent focus:outline-none text-gray-900"
              />
            </div>
          </label>

          <div className="hidden sm:block w-px bg-gray-200 my-2" />

          <label className="flex items-center gap-2 px-4 py-2 rounded-xl sm:rounded-full hover:bg-gray-50 transition text-left sm:w-32">
            <span className="text-gray-400">👥</span>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider font-semibold text-gray-500">Гості</p>
              <input
                type="number"
                min="1"
                value={guests}
                onChange={(e) => setGuests(parseInt(e.target.value) || 1)}
                className="w-full text-sm bg-transparent focus:outline-none"
              />
            </div>
          </label>

          <button
            type="submit"
            className="bg-gray-900 hover:bg-black text-white text-sm font-medium px-6 py-3 sm:py-2 rounded-xl sm:rounded-full transition flex items-center justify-center gap-2"
          >
            <span>⌕</span>
            <span>Знайти</span>
          </button>
        </form>

        <div className="mt-6 flex flex-wrap justify-center gap-2 text-xs text-gray-500">
          <span>Популярне:</span>
          <button onClick={() => navigate("/search?category=Коворкінг")} className="hover:text-gray-900 underline underline-offset-2">Коворкінги</button>
          <span>·</span>
          <button onClick={() => navigate("/search?category=Фотостудія")} className="hover:text-gray-900 underline underline-offset-2">Фотостудії</button>
          <span>·</span>
          <button onClick={() => navigate("/search?category=Конференц-зал")} className="hover:text-gray-900 underline underline-offset-2">Конференц-зали</button>
          <span>·</span>
          <button onClick={() => navigate("/search?search=Київ")} className="hover:text-gray-900 underline underline-offset-2">Київ</button>
        </div>
      </div>
    </div>
  );
};

export default Hero;
