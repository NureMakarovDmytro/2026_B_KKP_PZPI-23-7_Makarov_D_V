// Booking-style pagination: Prev / [1 ... 4 5 6 ... 20] / Next
const buildPages = (page, totalPages) => {
  const out = [];
  const window = 1; // pages on each side of current
  const push = (v) => {
    if (out[out.length - 1] !== v) out.push(v);
  };

  push(1);
  if (page - window > 2) push("…");
  for (let p = Math.max(2, page - window); p <= Math.min(totalPages - 1, page + window); p++) {
    push(p);
  }
  if (page + window < totalPages - 1) push("…");
  if (totalPages > 1) push(totalPages);

  return out;
};

const Pagination = ({ page, totalPages, onChange }) => {
  if (totalPages <= 1) return null;
  const pages = buildPages(page, totalPages);
  const isFirst = page <= 1;
  const isLast = page >= totalPages;

  const Btn = ({ active, disabled, onClick, children, ariaLabel }) => (
    <button
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      aria-current={active ? "page" : undefined}
      className={`min-w-9 h-9 px-3 inline-flex items-center justify-center text-sm rounded-full transition select-none
        ${active
          ? "bg-gray-900 text-white border border-gray-900"
          : disabled
          ? "border border-gray-200 text-gray-300 cursor-not-allowed"
          : "border border-gray-300 text-gray-700 hover:border-gray-900 hover:text-gray-900"
        }`}
    >
      {children}
    </button>
  );

  return (
    <nav aria-label="Сторінки" className="flex flex-col items-center gap-3 mt-10">
      <div className="flex items-center gap-1.5 flex-wrap justify-center">
        <Btn
          disabled={isFirst}
          onClick={() => !isFirst && onChange(page - 1)}
          ariaLabel="Попередня сторінка"
        >
          ‹
        </Btn>

        {pages.map((p, i) =>
          p === "…" ? (
            <span key={`e${i}`} className="text-gray-400 px-1.5 select-none">…</span>
          ) : (
            <Btn
              key={p}
              active={p === page}
              onClick={() => onChange(p)}
              ariaLabel={`Сторінка ${p}`}
            >
              {p}
            </Btn>
          )
        )}

        <Btn
          disabled={isLast}
          onClick={() => !isLast && onChange(page + 1)}
          ariaLabel="Наступна сторінка"
        >
          ›
        </Btn>
      </div>
      <p className="text-xs text-gray-400">
        Сторінка {page} з {totalPages}
      </p>
    </nav>
  );
};

export default Pagination;
