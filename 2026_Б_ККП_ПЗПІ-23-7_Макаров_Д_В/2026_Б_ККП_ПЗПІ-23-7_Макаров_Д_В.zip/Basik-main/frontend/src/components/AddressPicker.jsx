import { forwardRef, memo, useEffect, useImperativeHandle, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const DEFAULT_CENTER = [50.4501, 30.5234];

const search = async (q) => {
  if (!q || q.length < 3) return [];
  const url = `https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&limit=5&countrycodes=ua&accept-language=uk&q=${encodeURIComponent(q)}`;
  const r = await fetch(url, { headers: { "Accept-Language": "uk" } });
  if (!r.ok) return [];
  return r.json();
};

const reverse = async (lat, lng) => {
  const url = `https://nominatim.openstreetmap.org/reverse?format=json&addressdetails=1&accept-language=uk&lat=${lat}&lon=${lng}`;
  const r = await fetch(url, { headers: { "Accept-Language": "uk" } });
  if (!r.ok) return null;
  return r.json();
};

const formatAddress = (item) => {
  const a = item.address || {};
  const parts = [];
  if (a.city || a.town || a.village) parts.push(`м. ${a.city || a.town || a.village}`);
  if (a.road) parts.push(`вул. ${a.road}${a.house_number ? ", " + a.house_number : ""}`);
  return parts.length ? parts.join(", ") : item.display_name;
};

// ─── Vanilla Leaflet map ───
// forwardRef + useImperativeHandle → parent controls marker imperatively
// React re-renders NEVER touch the Leaflet map instance
const LeafletMap = memo(forwardRef(({ onMapClickRef, initialLat, initialLng }, ref) => {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const markerRef = useRef(null);

  // Expose setPosition / clearPosition to parent via ref
  useImperativeHandle(ref, () => ({
    setPosition(lat, lng) {
      const map = mapRef.current;
      if (!map) return;
      if (markerRef.current) {
        markerRef.current.setLatLng([lat, lng]);
      } else {
        markerRef.current = L.circleMarker([lat, lng], {
          radius: 9,
          fillColor: "#111827",
          color: "#ffffff",
          weight: 3,
          fillOpacity: 1,
        }).addTo(map);
      }
      map.setView([lat, lng], 15, { animate: true, duration: 0.4 });
    },
    clearPosition() {
      if (markerRef.current) {
        markerRef.current.remove();
        markerRef.current = null;
      }
    },
  }), []);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: initialLat && initialLng ? [initialLat, initialLng] : DEFAULT_CENTER,
      zoom: initialLat && initialLng ? 15 : 11,
    });

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);

    if (initialLat && initialLng) {
      markerRef.current = L.circleMarker([initialLat, initialLng], {
        radius: 9,
        fillColor: "#111827",
        color: "#ffffff",
        weight: 3,
        fillOpacity: 1,
      }).addTo(map);
    }

    // onMapClickRef.current always points to the latest handler — map never reinitializes
    map.on("click", (e) => {
      onMapClickRef.current(e.latlng.lat, e.latlng.lng);
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
      markerRef.current = null;
    };
  }, []); // ← runs ONCE, never again

  return (
    <div
      ref={containerRef}
      className="h-64 rounded-lg overflow-hidden border border-gray-200"
      style={{ zIndex: 0 }}
    />
  );
}));

// ─── AddressPicker ───
// memo → doesn't re-render when parent updates title/description/etc.
const AddressPicker = memo(({ value, lat, lng, onChange }) => {
  const [query, setQuery] = useState(value || "");
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [pos, setPos] = useState(lat && lng ? { lat, lng } : null);

  const debounceRef = useRef(null);
  const wrapRef = useRef(null);
  const leafletRef = useRef(null);   // imperative handle to LeafletMap
  const onMapClickRef = useRef(null); // stable ref so map click always has latest state

  // Sync initial value in edit mode
  useEffect(() => {
    if (value) setQuery(value);
  }, [value]);

  useEffect(() => {
    if (lat && lng && (!pos || pos.lat !== lat || pos.lng !== lng)) {
      setPos({ lat, lng });
      leafletRef.current?.setPosition(lat, lng);
    }
  }, [lat, lng]);

  // Close on outside click
  useEffect(() => {
    const close = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  // Updated every render via ref — map never reinitializes because of this
  onMapClickRef.current = async (clickLat, clickLng) => {
    setPos({ lat: clickLat, lng: clickLng });
    leafletRef.current?.setPosition(clickLat, clickLng);
    onChange({ address: query, lat: clickLat, lng: clickLng });

    const data = await reverse(clickLat, clickLng);
    if (data) {
      const formatted = formatAddress(data);
      setQuery(formatted);
      onChange({ address: formatted, lat: clickLat, lng: clickLng });
    }
  };

  const onInput = (val) => {
    setQuery(val);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!val || val.length < 3) {
      setSuggestions([]);
      setOpen(false);
      return;
    }
    setLoading(true);
    debounceRef.current = setTimeout(async () => {
      const results = await search(val);
      setSuggestions(results);
      setOpen(results.length > 0);
      setLoading(false);
    }, 450);
  };

  const select = (item) => {
    const formatted = formatAddress(item);
    const next = { lat: parseFloat(item.lat), lng: parseFloat(item.lon) };
    setPos(next);
    setQuery(formatted);
    setOpen(false);
    setSuggestions([]);
    leafletRef.current?.setPosition(next.lat, next.lng);
    onChange({ address: formatted, lat: next.lat, lng: next.lng });
  };

  const clear = () => {
    setPos(null);
    setQuery("");
    setSuggestions([]);
    setOpen(false);
    leafletRef.current?.clearPosition();
    onChange({ address: "", lat: null, lng: null });
  };

  return (
    <div className="space-y-2">
      <div ref={wrapRef} className="relative">
        <input
          type="text"
          required
          placeholder="Почніть вводити адресу..."
          value={query}
          onChange={(e) => onInput(e.target.value)}
          onFocus={() => suggestions.length > 0 && setOpen(true)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              if (suggestions.length > 0) select(suggestions[0]);
            }
          }}
          className="w-full border border-gray-300 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-gray-900 transition pr-10"
        />
        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
          {loading ? "…" : query
            ? <button type="button" onClick={clear} className="hover:text-gray-900">✕</button>
            : "📍"
          }
        </span>

        {open && suggestions.length > 0 && (
          <ul className="absolute left-0 right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-[1000] max-h-64 overflow-auto">
            {suggestions.map((s) => (
              <li key={s.place_id}>
                <button
                  type="button"
                  onClick={() => select(s)}
                  className="w-full text-left px-3.5 py-2.5 text-sm hover:bg-gray-50 border-b border-gray-100 last:border-0"
                >
                  <p className="text-gray-900 font-medium leading-tight">{formatAddress(s)}</p>
                  <p className="text-xs text-gray-400 mt-0.5 truncate">{s.display_name}</p>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <p className="text-xs text-gray-500">
        {pos
          ? "Натисніть на карту, щоб уточнити розташування"
          : "Введіть адресу або клацніть на карту, щоб поставити позначку"}
      </p>

      <LeafletMap
        ref={leafletRef}
        onMapClickRef={onMapClickRef}
        initialLat={lat}
        initialLng={lng}
      />

      {pos && (
        <p className="text-xs text-gray-400">
          Координати: {pos.lat.toFixed(5)}, {pos.lng.toFixed(5)}
        </p>
      )}
    </div>
  );
});

export default AddressPicker;
