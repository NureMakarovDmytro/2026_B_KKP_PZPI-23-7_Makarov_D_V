import { useState, useEffect } from "react";

const GalleryModal = ({ photos, initialIndex = 0, onClose }) => {
  const [current, setCurrent] = useState(initialIndex);

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") setCurrent((p) => (p > 0 ? p - 1 : photos.length - 1));
      if (e.key === "ArrowRight") setCurrent((p) => (p < photos.length - 1 ? p + 1 : 0));
    };
    window.addEventListener("keydown", handleKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handleKey);
      document.body.style.overflow = "";
    };
  }, [photos.length, onClose]);

  return (
    <div className="fixed inset-0 bg-black/95 z-50 flex flex-col">
      <div className="flex items-center justify-between px-5 py-3 text-white text-sm">
        <span>{current + 1} / {photos.length}</span>
        <button onClick={onClose} className="hover:opacity-70 text-base">Закрити ✕</button>
      </div>

      <div className="flex-1 flex items-center justify-center px-4 relative">
        <button
          onClick={() => setCurrent((p) => (p > 0 ? p - 1 : photos.length - 1))}
          className="absolute left-4 text-white text-2xl px-3 py-1 hover:opacity-70"
          aria-label="prev"
        >
          ‹
        </button>

        <img
          src={photos[current]?.url}
          alt=""
          className="max-h-[80vh] max-w-[85vw] object-contain"
          onError={(e) => { e.target.src = "https://placehold.co/1200x900?text=Basik"; }}
        />

        <button
          onClick={() => setCurrent((p) => (p < photos.length - 1 ? p + 1 : 0))}
          className="absolute right-4 text-white text-2xl px-3 py-1 hover:opacity-70"
          aria-label="next"
        >
          ›
        </button>
      </div>

      <div className="flex gap-2 overflow-x-auto px-5 py-3 justify-center">
        {photos.map((p, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`flex-shrink-0 w-14 h-14 rounded overflow-hidden border-2 transition ${
              i === current ? "border-white" : "border-transparent opacity-50 hover:opacity-80"
            }`}
          >
            <img src={p.url} alt="" className="w-full h-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
};

export default GalleryModal;
