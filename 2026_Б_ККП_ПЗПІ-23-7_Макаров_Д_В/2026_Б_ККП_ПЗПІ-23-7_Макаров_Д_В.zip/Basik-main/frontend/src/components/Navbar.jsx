import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";

const Navbar = ({ auth }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const navigate = useNavigate();
  const role = auth.user?.role;

  useEffect(() => {
    const close = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const logout = () => {
    auth.logout();
    setOpen(false);
    navigate("/");
  };

  const homeLink = role === "Host" ? "/host" : role === "Admin" ? "/admin" : "/";

  const hostCtaLink = role === "Host" ? "/add-listing" : "/host-landing";
  const hostCtaLabel = role === "Host" ? "Додати локацію" : "Здати в оренду";

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
        <Link to={homeLink} className="flex items-center gap-2 flex-shrink-0">
          <span className="w-8 h-8 rounded-full bg-gray-900 text-white flex items-center justify-center text-sm font-bold">
            B
          </span>
          <span className="text-lg font-semibold text-gray-900">Basik</span>
        </Link>

        <div className="hidden md:flex items-center gap-1 text-sm">
          {role === "Host" ? (
            <>
              <Link to="/host" className="px-3 py-2 text-gray-700 hover:text-gray-900">Панель</Link>
              <Link to="/my-listings" className="px-3 py-2 text-gray-700 hover:text-gray-900">Локації</Link>
              <Link to="/host-bookings" className="px-3 py-2 text-gray-700 hover:text-gray-900">Бронювання</Link>
            </>
          ) : role === "Admin" ? (
            <Link to="/admin" className="px-3 py-2 text-gray-700 hover:text-gray-900">Адмін</Link>
          ) : null}
        </div>

        <div className="flex items-center gap-2">
          {role !== "Admin" && (
            <Link
              to={hostCtaLink}
              className="hidden sm:inline-flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-full text-gray-900 hover:bg-gray-100 transition"
            >
              {hostCtaLabel}
            </Link>
          )}

          <div className="relative" ref={ref}>
            <button
              onClick={() => setOpen(!open)}
              className="flex items-center gap-2 border border-gray-300 hover:border-gray-900 rounded-full pl-3 pr-2 py-1.5 text-sm transition"
            >
              <span className="hidden md:block">{auth.user ? auth.user.name : "Меню"}</span>
              <span className="md:hidden">≡</span>
              <span className="w-7 h-7 rounded-full bg-gray-200 text-gray-700 flex items-center justify-center text-xs font-medium">
                {auth.user ? auth.user.name?.[0]?.toUpperCase() : "B"}
              </span>
            </button>

            {open && (
              <div className="absolute right-0 mt-2 w-56 bg-white border border-gray-200 rounded-lg shadow-md py-1 z-50">
                {auth.user ? (
                  <>
                    <div className="px-3 py-2 border-b border-gray-100">
                      <p className="text-sm text-gray-900 font-medium">{auth.user.name}</p>
                      <p className="text-xs text-gray-500 truncate">{auth.user.email}</p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {role === "Host" ? "Власник" : role === "Admin" ? "Адмін" : "Гість"}
                      </p>
                    </div>
                    <Link to="/profile" onClick={() => setOpen(false)} className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50">
                      Профіль
                    </Link>
                    {role === "Guest" && (
                      <Link to="/bookings" onClick={() => setOpen(false)} className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50">
                        Мої бронювання
                      </Link>
                    )}
                    {role === "Host" && (
                      <Link to="/add-listing" onClick={() => setOpen(false)} className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50">
                        Додати локацію
                      </Link>
                    )}
                    <button onClick={logout} className="block w-full text-left px-3 py-2 text-sm text-red-600 hover:bg-gray-50 border-t border-gray-100">
                      Вийти
                    </button>
                  </>
                ) : (
                  <>
                    <Link to="/host-landing" onClick={() => setOpen(false)} className="sm:hidden block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 border-b border-gray-100">
                      Здати в оренду
                    </Link>
                    <Link to="/auth" onClick={() => setOpen(false)} className="block px-3 py-2 text-sm text-gray-900 font-medium hover:bg-gray-50">
                      Увійти
                    </Link>
                    <Link to="/auth?mode=register" onClick={() => setOpen(false)} className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50">
                      Зареєструватися
                    </Link>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
