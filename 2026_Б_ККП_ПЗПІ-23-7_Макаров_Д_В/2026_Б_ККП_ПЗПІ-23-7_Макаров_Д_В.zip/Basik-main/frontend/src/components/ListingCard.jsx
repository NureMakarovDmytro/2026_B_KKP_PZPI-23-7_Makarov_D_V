import { Link } from "react-router-dom";
import { getCoverPhoto, makeFallbackHandler } from "../utils/listingImages";

const ListingCard = ({ listing }) => {
  const photo = getCoverPhoto(listing);

  return (
    <Link
      to={`/listing/${listing._id}`}
      className="group block bg-white rounded-lg overflow-hidden border border-gray-200 hover:border-gray-900 hover:shadow-sm transition"
    >
      <div className="relative aspect-[4/3] bg-gray-100 overflow-hidden">
        <img
          src={photo}
          alt={listing.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
          onError={makeFallbackHandler(listing.category, 0)}
        />
        <span className="absolute top-2 left-2 bg-white/95 backdrop-blur text-[11px] text-gray-900 font-medium px-2 py-0.5 rounded">
          {listing.category}
        </span>
        <span className="absolute bottom-2 left-2 bg-gray-900/90 text-white text-xs font-semibold px-2 py-1 rounded">
          {listing.price_per_hour} грн<span className="font-normal opacity-80">/год</span>
        </span>
      </div>
      <div className="p-3">
        <h3 className="font-medium text-gray-900 text-sm mb-1 truncate">{listing.title}</h3>
        <p className="text-xs text-gray-500 mb-1 truncate">{listing.address}</p>
        <p className="text-xs text-gray-500">До {listing.max_guests} гостей</p>
      </div>
    </Link>
  );
};

export default ListingCard;
