import { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";

const AuthSuccess = ({ auth }) => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const data = searchParams.get("data");
    if (data) {
      try {
        const userData = JSON.parse(decodeURIComponent(data));
        auth.login(userData);
        navigate("/");
      } catch {
        navigate("/auth");
      }
    } else {
      navigate("/auth");
    }
  }, []);

  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <p className="text-gray-500">Авторизація...</p>
    </div>
  );
};

export default AuthSuccess;
