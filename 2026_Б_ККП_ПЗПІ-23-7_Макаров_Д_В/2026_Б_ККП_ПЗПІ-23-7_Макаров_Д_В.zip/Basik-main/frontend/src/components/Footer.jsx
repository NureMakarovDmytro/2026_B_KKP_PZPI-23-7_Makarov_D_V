import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="border-t border-gray-200 mt-auto bg-white">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-3">
              <span className="w-8 h-8 rounded-full bg-gray-900 text-white flex items-center justify-center text-sm font-bold">
                B
              </span>
              <span className="text-lg font-semibold text-gray-900">Basik</span>
            </Link>
            <p className="text-sm text-gray-500 max-w-xs">
              Платформа для пошуку та оренди унікальних просторів погодинно по всій Україні.
            </p>
            <a
              href="mailto:support@basik.com"
              className="inline-block mt-4 text-sm text-gray-900 underline underline-offset-4 hover:opacity-70"
            >
              support@basik.com
            </a>
          </div>

          <div>
            <p className="text-xs uppercase tracking-wider font-semibold text-gray-900 mb-3">Локації</p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link to="/search?category=Коворкінг" className="hover:text-gray-900">Коворкінги</Link></li>
              <li><Link to="/search?category=Конференц-зал" className="hover:text-gray-900">Конференц-зали</Link></li>
              <li><Link to="/search?category=Фотостудія" className="hover:text-gray-900">Фотостудії</Link></li>
              <li><Link to="/search?category=Спортзал" className="hover:text-gray-900">Спортзали</Link></li>
              <li><Link to="/search?category=Подієва локація" className="hover:text-gray-900">Подієві локації</Link></li>
            </ul>
          </div>

          <div>
            <p className="text-xs uppercase tracking-wider font-semibold text-gray-900 mb-3">Власникам</p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link to="/register-host" className="hover:text-gray-900">Здати простір</Link></li>
              <li><Link to="/for-hosts" className="hover:text-gray-900">Як це працює</Link></li>
              <li><Link to="/pricing" className="hover:text-gray-900">Тарифи</Link></li>
              <li><Link to="/tips" className="hover:text-gray-900">Поради</Link></li>
            </ul>
          </div>

          <div>
            <p className="text-xs uppercase tracking-wider font-semibold text-gray-900 mb-3">Підтримка</p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="mailto:support@basik.com" className="hover:text-gray-900">Зв'язатися</a></li>
              <li><Link to="/support" className="hover:text-gray-900">Допомога</Link></li>
              <li><Link to="/safety" className="hover:text-gray-900">Безпека</Link></li>
              <li><Link to="/faq" className="hover:text-gray-900">FAQ</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-gray-400">
            © {new Date().getFullYear()} Basik. Усі права захищено.
          </p>
          <div className="flex flex-wrap gap-4 text-xs text-gray-500">
            <Link to="/legal#terms" className="hover:text-gray-900">Умови</Link>
            <Link to="/legal#privacy" className="hover:text-gray-900">Приватність</Link>
            <Link to="/legal#cookies" className="hover:text-gray-900">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
