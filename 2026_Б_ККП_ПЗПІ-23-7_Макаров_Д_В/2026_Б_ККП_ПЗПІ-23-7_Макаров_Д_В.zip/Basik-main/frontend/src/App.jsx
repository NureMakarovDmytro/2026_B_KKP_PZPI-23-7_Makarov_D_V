import { Routes, Route, Navigate } from "react-router-dom";
import useAuth from "./hooks/useAuth";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import HomePage from "./pages/HomePage";
import AuthPage from "./pages/AuthPage";
import AuthSuccess from "./components/AuthSuccess";
import SearchResults from "./pages/SearchResults";
import ListingPage from "./pages/ListingPage";
import BookingPage from "./pages/BookingPage";
import BookingsPage from "./pages/BookingsPage";
import ProfilePage from "./pages/ProfilePage";
import AddListingPage from "./pages/AddListingPage";
import MyListingsPage from "./pages/MyListingsPage";
import HostBookingsPage from "./pages/HostBookingsPage";
import HostDashboard from "./pages/HostDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import AdminUsers from "./pages/AdminUsers";
import AdminListings from "./pages/AdminListings";
import AdminBookings from "./pages/AdminBookings";
import PaymentStatusPage from "./pages/PaymentStatusPage";
import ForHostsPage from "./pages/ForHostsPage";
import SupportPage from "./pages/SupportPage";
import HostLandingPage from "./pages/HostLandingPage";
import HostRegisterPage from "./pages/HostRegisterPage";
import LegalPage from "./pages/LegalPage";
import PricingPage from "./pages/PricingPage";
import TipsPage from "./pages/TipsPage";
import SafetyPage from "./pages/SafetyPage";
import FaqPage from "./pages/FaqPage";

function App() {
  const auth = useAuth();
  const role = auth.user?.role;
  const isHost = role === "Host";
  const isAdmin = role === "Admin";

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar auth={auth} />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage auth={auth} />} />
          <Route path="/auth" element={<AuthPage auth={auth} />} />
          <Route path="/auth-success" element={<AuthSuccess auth={auth} />} />
          <Route path="/search" element={<SearchResults auth={auth} />} />
          <Route path="/for-hosts" element={<ForHostsPage />} />
          <Route path="/support" element={<SupportPage />} />
          <Route path="/pricing" element={<PricingPage />} />
          <Route path="/tips" element={<TipsPage />} />
          <Route path="/safety" element={<SafetyPage />} />
          <Route path="/faq" element={<FaqPage />} />
          <Route path="/host-landing" element={<HostLandingPage />} />
          <Route path="/register-host" element={<HostRegisterPage auth={auth} />} />
          <Route path="/legal" element={<LegalPage />} />
          <Route path="/listing/:id" element={<ListingPage auth={auth} />} />
          <Route path="/profile" element={<ProfilePage auth={auth} />} />
          <Route path="/booking/:id" element={<BookingPage auth={auth} />} />
          <Route path="/bookings" element={<BookingsPage auth={auth} />} />
          <Route path="/booking/success" element={<PaymentStatusPage auth={auth} status="success" />} />
          <Route path="/booking/cancel" element={<PaymentStatusPage auth={auth} status="cancel" />} />
          <Route path="/host" element={isHost ? <HostDashboard auth={auth} /> : <Navigate to="/" />} />
          <Route path="/add-listing" element={isHost ? <AddListingPage auth={auth} /> : <Navigate to="/auth?mode=register" />} />
          <Route path="/edit-listing/:id" element={isHost ? <AddListingPage auth={auth} /> : <Navigate to="/" />} />
          <Route path="/my-listings" element={isHost ? <MyListingsPage auth={auth} /> : <Navigate to="/" />} />
          <Route path="/host-bookings" element={isHost ? <HostBookingsPage auth={auth} /> : <Navigate to="/" />} />
          <Route path="/admin" element={isAdmin ? <AdminDashboard auth={auth} /> : <Navigate to="/" />} />
          <Route path="/admin/users" element={isAdmin ? <AdminUsers auth={auth} /> : <Navigate to="/" />} />
          <Route path="/admin/listings" element={isAdmin ? <AdminListings auth={auth} /> : <Navigate to="/" />} />
          <Route path="/admin/bookings" element={isAdmin ? <AdminBookings auth={auth} /> : <Navigate to="/" />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;
