import { useState, useEffect } from "react";
import axios from "axios";

const useAuth = () => {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("basik_user");
    return saved ? JSON.parse(saved) : null;
  });

  const [token, setToken] = useState(() => {
    return localStorage.getItem("basik_token") || null;
  });

  useEffect(() => {
    if (user && token) {
      localStorage.setItem("basik_user", JSON.stringify(user));
      localStorage.setItem("basik_token", token);
      axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    } else {
      localStorage.removeItem("basik_user");
      localStorage.removeItem("basik_token");
      delete axios.defaults.headers.common["Authorization"];
    }
  }, [user, token]);

  useEffect(() => {
    if (token) {
      axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    }
  }, []);

  const login = (userData) => {
    setUser(userData);
    setToken(userData.token);
  };

  const logout = () => {
    setUser(null);
    setToken(null);
  };

  const updateUser = (updatedData) => {
    setUser((prev) => ({ ...prev, ...updatedData }));
  };

  return { user, token, login, logout, updateUser };
};

export default useAuth;
