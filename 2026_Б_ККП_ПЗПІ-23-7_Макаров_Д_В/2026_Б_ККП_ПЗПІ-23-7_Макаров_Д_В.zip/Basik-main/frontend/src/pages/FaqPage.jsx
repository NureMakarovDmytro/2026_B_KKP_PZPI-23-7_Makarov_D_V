import { useState } from "react";

const faqs = [
  {
    category: "Бронювання",
    items: [
      { q: "Як забронювати локацію?", a: "Оберіть простір, виберіть дату та час, вкажіть кількість гостей і натисніть «Забронювати». Оплата проходить одразу через захищений платіжний шлюз." },
      { q: "Чи можна скасувати бронювання?", a: "Так. Ви можете скасувати бронювання у розділі «Мої бронювання». Повернення коштів відбувається автоматично на вашу картку." },
      { q: "Що відбувається після оплати?", a: "Після успішної оплати ви отримаєте підтвердження на email з деталями бронювання та адресою локації." },
      { q: "Чи можна змінити час бронювання?", a: "Зміна часу наразі недоступна. Скасуйте поточне бронювання та створіть нове з потрібним часом." },
    ],
  },
  {
    category: "Оплата",
    items: [
      { q: "Які способи оплати доступні?", a: "Оплата здійснюється карткою Visa або Mastercard через захищений платіжний шлюз Stripe." },
      { q: "Коли повертаються кошти при скасуванні?", a: "Кошти повертаються на вашу картку протягом 5–10 робочих днів залежно від банку." },
      { q: "Чи безпечно платити на Basik?", a: "Так. Ми використовуємо Stripe — один із найнадійніших платіжних провайдерів у світі. Дані вашої картки не зберігаються на наших серверах." },
    ],
  },
  {
    category: "Для власників",
    items: [
      { q: "Як стати власником на Basik?", a: "Натисніть «Здати в оренду», зареєструйтесь як власник, підтвердіть email і додайте першу локацію. Після модерації вона з'явиться в пошуку." },
      { q: "Яка комісія платформи?", a: "Basik утримує 10% з кожного підтвердженого бронювання. Реєстрація та публікація локацій — безкоштовні." },
      { q: "Коли я отримаю виплату?", a: "Виплати здійснюються на українську картку або рахунок протягом 1–3 робочих днів після завершення бронювання." },
      { q: "Скільки локацій можна додати?", a: "Немає обмежень — додавайте будь-яку кількість локацій." },
    ],
  },
  {
    category: "Технічне",
    items: [
      { q: "Чи є мобільний застосунок?", a: "Поки ні — Basik повністю працює у браузері та адаптований для смартфонів. Застосунок плануємо випустити у майбутньому." },
      { q: "Я забув пароль. Що робити?", a: "На Basik немає паролів — вхід здійснюється через код підтвердження на email або через Google акаунт." },
      { q: "Як видалити акаунт?", a: "Напишіть на support@basik.com із запитом на видалення акаунту — ми обробимо його протягом 24 годин." },
    ],
  },
];

const FaqItem = ({ q, a }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-gray-100">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full text-left flex items-center justify-between py-4 gap-4"
      >
        <span className="text-sm font-medium text-gray-900">{q}</span>
        <span className="text-gray-400 shrink-0 text-lg leading-none">{open ? "−" : "+"}</span>
      </button>
      {open && <p className="text-sm text-gray-600 pb-4 leading-relaxed">{a}</p>}
    </div>
  );
};

const FaqPage = () => (
  <div className="max-w-3xl mx-auto px-4 py-12">
    <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">FAQ</p>
    <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Часті питання</h1>
    <p className="text-gray-500 text-sm mb-10">Не знайшли відповідь? Напишіть нам на{" "}
      <a href="mailto:support@basik.com" className="text-gray-900 underline underline-offset-4">support@basik.com</a>
    </p>

    <div className="space-y-10">
      {faqs.map(({ category, items }) => (
        <section key={category}>
          <h2 className="text-base font-semibold text-gray-900 mb-2 pb-2 border-b border-gray-200">{category}</h2>
          <div>
            {items.map(({ q, a }) => <FaqItem key={q} q={q} a={a} />)}
          </div>
        </section>
      ))}
    </div>
  </div>
);

export default FaqPage;
