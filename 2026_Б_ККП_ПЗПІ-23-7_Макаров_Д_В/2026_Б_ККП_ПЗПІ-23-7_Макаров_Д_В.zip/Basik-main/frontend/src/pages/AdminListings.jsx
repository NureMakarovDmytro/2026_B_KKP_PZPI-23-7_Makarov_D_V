import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const AdminListings = ({ auth }) => {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!auth.user || auth.user.role !== "Admin") {
      navigate("/");
      return;
    }
    fetchListings();
  }, []);

  const fetchListings = async () => {
    try {
      const { data } = await axios.get("/api/admin/listings");
      setListings(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const toggleApproval = async (id) => {
    try {
      await axios.patch(`/api/admin/listings/${id}/approve`);
      fetchListings();
    } catch (err) {
      console.error(err);
    }
  };

  const toggleListed = async (id) => {
    try {
      await axios.patch(`/api/admin/listings/${id}/toggle-listed`);
      fetchListings();
    } catch (err) {
      console.error(err);
    }
  };

  const deleteListing = async (id) => {
    if (!window.confirm("Видалити локацію?")) return;
    try {
      await axios.delete(`/api/admin/listings/${id}`);
      fetchListings();
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return <div className="text-center py-20 text-gray-400">Завантаження...</div>;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Управління локаціями</h1>

      <div className="overflow-x-auto">
        <table className="w-full bg-white rounded-xl border border-gray-100">
          <thead>
            <tr className="text-left text-sm text-gray-500 border-b">
              <th className="px-4 py-3">Назва</th>
              <th className="px-4 py-3">Власник</th>
              <th className="px-4 py-3">Категорія</th>
              <th className="px-4 py-3">Ціна/год</th>
              <th className="px-4 py-3">Статус</th>
              <th className="px-4 py-3">Дії</th>
            </tr>
          </thead>
          <tbody>
            {listings.map((listing) => (
              <tr key={listing._id} className="border-b last:border-0 text-sm">
                <td className="px-4 py-3">
                  <Link
                    to={`/listing/${listing._id}`}
                    className="font-medium text-indigo-600 hover:underline"
                  >
                    {listing.title}
                  </Link>
                </td>
                <td className="px-4 py-3 text-gray-600">{listing.host_id?.name || "—"}</td>
                <td className="px-4 py-3 text-gray-600">{listing.category}</td>
                <td className="px-4 py-3">{listing.price_per_hour} грн</td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1">
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full inline-block w-fit ${
                        listing.isApproved ? "bg-green-100 text-green-600" : "bg-yellow-100 text-yellow-600"
                      }`}
                    >
                      {listing.isApproved ? "Затверджено" : "На модерації"}
                    </span>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full inline-block w-fit ${
                        listing.isListed ? "bg-blue-100 text-blue-600" : "bg-gray-100 text-gray-500"
                      }`}
                    >
                      {listing.isListed ? "Публічна" : "Прихована"}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-1 flex-wrap">
                    <button
                      onClick={() => toggleApproval(listing._id)}
                      className={`text-xs px-2 py-1 rounded ${
                        listing.isApproved
                          ? "bg-yellow-50 text-yellow-600"
                          : "bg-green-50 text-green-600"
                      }`}
                    >
                      {listing.isApproved ? "Відхилити" : "Затвердити"}
                    </button>
                    <button
                      onClick={() => toggleListed(listing._id)}
                      className="text-xs px-2 py-1 rounded bg-blue-50 text-blue-600"
                    >
                      {listing.isListed ? "Сховати" : "Показати"}
                    </button>
                    <button
                      onClick={() => deleteListing(listing._id)}
                      className="text-xs px-2 py-1 rounded bg-red-50 text-red-600"
                    >
                      Видалити
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminListings;
