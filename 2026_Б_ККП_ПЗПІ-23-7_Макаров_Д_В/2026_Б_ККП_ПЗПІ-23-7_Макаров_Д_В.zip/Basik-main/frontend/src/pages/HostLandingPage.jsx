import { Link } from "react-router-dom";

const Step = ({ n, title, desc }) => (
  <div>
    <p className="text-xs uppercase tracking-wider font-semibold text-gray-400 mb-2">
      Крок {n}
    </p>
    <h3 className="text-base font-semibold text-gray-900 mb-1.5">{title}</h3>
    <p className="text-sm text-gray-500 leading-relaxed">{desc}</p>
  </div>
);

const Faq = ({ q, a }) => (
  <details className="border-b border-gray-200 py-4 group">
    <summary className="flex items-center justify-between cursor-pointer list-none">
      <span className="text-sm font-medium text-gray-900">{q}</span>
      <span className="text-gray-400 group-open:rotate-45 transition-transform text-xl leading-none">+</span>
    </summary>
    <p className="text-sm text-gray-600 mt-3 leading-relaxed">{a}</p>
  </details>
);

const HostLandingPage = () => {
  return (
    <div>
      {/* Hero */}
      <section className="max-w-5xl mx-auto px-4 pt-20 pb-16 text-center">
        <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-4">
          Для власників просторів
        </p>
        <h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-[1.05] tracking-tight mb-5">
          Здавайте простір.<br />Отримуйте дохід.
        </h1>
        <p className="text-base md:text-lg text-gray-500 mb-8 max-w-xl mx-auto">
          Долучайтеся до сотень власників, які здають коворкінги, студії та зали погодинно через Basik.
        </p>
        <Link
          to="/register-host"
          className="inline-block bg-gray-900 hover:bg-black text-white text-sm font-medium px-7 py-3 rounded-full transition"
        >
          Стати власником
        </Link>
        <p className="text-xs text-gray-400 mt-4">
          Безкоштовно · 10 хвилин на реєстрацію · Жодних зобов'язань
        </p>
      </section>

      {/* Hero image */}
      <section className="max-w-6xl mx-auto px-4 pb-16">
        <img
          src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1600&q=80"
          alt="Простір на Basik"
          className="rounded-2xl object-cover w-full h-[280px] md:h-[420px]"
        />
      </section>

      {/* Steps */}
      <section className="max-w-5xl mx-auto px-4 py-16 border-t border-gray-200">
        <h2 className="text-2xl md:text-3xl font-semibold text-gray-900 mb-10 text-center">
          Як це працює
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <Step
            n="1"
            title="Розкажіть про простір"
            desc="Кілька якісних фото, опис та категорія — цього достатньо для першої публікації."
          />
          <Step
            n="2"
            title="Налаштуйте графік"
            desc="Виберіть години роботи та власні правила. Ви повністю керуєте своїм календарем."
          />
          <Step
            n="3"
            title="Отримуйте дохід"
            desc="Гості бронюють — ми переказуємо кошти на картку через 1–3 дні після візиту."
          />
        </div>
      </section>

      {/* Earnings */}
      <section className="bg-gray-900 text-white">
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <p className="text-xs uppercase tracking-wider font-semibold text-white/50 mb-3">
            Скільки можна заробити
          </p>
          <p className="text-5xl md:text-7xl font-bold mb-3 tracking-tight">
            85 000 ₴
          </p>
          <p className="text-sm text-white/70 max-w-md mx-auto">
            Середній дохід на місяць для активної локації у Києві
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-5xl mx-auto px-4 py-16 grid grid-cols-3 gap-6 text-center">
        <div>
          <p className="text-3xl md:text-4xl font-bold text-gray-900">500+</p>
          <p className="text-xs text-gray-500 mt-1">Власників</p>
        </div>
        <div>
          <p className="text-3xl md:text-4xl font-bold text-gray-900">4.8 ★</p>
          <p className="text-xs text-gray-500 mt-1">Середня оцінка</p>
        </div>
        <div>
          <p className="text-3xl md:text-4xl font-bold text-gray-900">500 000 ₴</p>
          <p className="text-xs text-gray-500 mt-1">Гарантія захисту</p>
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-3xl mx-auto px-4 py-16 border-t border-gray-200">
        <h2 className="text-2xl md:text-3xl font-semibold text-gray-900 mb-8 text-center">
          Часті питання
        </h2>
        <Faq
          q="Скільки коштує розмістити простір?"
          a="Безкоштовно. Ми утримуємо 10% з кожного підтвердженого бронювання — без щомісячних платежів."
        />
        <Faq
          q="Як я отримуватиму гроші?"
          a="Після візиту гостя кошти переказуються на вашу українську картку протягом 1–3 робочих днів."
        />
        <Faq
          q="Чи безпечно здавати свій простір?"
          a="Так. Кожне бронювання покриває гарантія до 500 000 грн, а особа кожного гостя верифікується."
        />
        <Faq
          q="Який простір підходить?"
          a="Коворкінги, конференц-зали, фотостудії, спортзали та подієві локації. Якщо у вас є цікаве місце — ми хочемо про нього почути."
        />
      </section>

      {/* Final CTA */}
      <section className="max-w-3xl mx-auto px-4 pb-20 text-center">
        <h2 className="text-2xl md:text-3xl font-semibold text-gray-900 mb-3">
          Готові розпочати?
        </h2>
        <p className="text-sm text-gray-500 mb-6">
          Реєстрація займає менше 10 хвилин
        </p>
        <Link
          to="/register-host"
          className="inline-block bg-gray-900 hover:bg-black text-white text-sm font-medium px-7 py-3 rounded-full transition"
        >
          Стати власником
        </Link>
      </section>
    </div>
  );
};

export default HostLandingPage;
