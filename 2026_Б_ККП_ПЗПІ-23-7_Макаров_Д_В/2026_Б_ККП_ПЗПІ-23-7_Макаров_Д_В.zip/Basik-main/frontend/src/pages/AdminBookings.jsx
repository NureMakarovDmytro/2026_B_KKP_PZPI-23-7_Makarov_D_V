import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const statusLabels = {
  pending: "Очікує",
  confirmed: "Підтверджено",
  completed: "Завершено",
  cancelled_by_guest: "Скасовано гостем",
  cancelled_by_host: "Скасовано власником",
  failed: "Помилка",
};

const AdminBookings = ({ auth }) => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!auth.user || auth.user.role !== "Admin") {
      navigate("/");
      return;
    }
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const { data } = await axios.get("/api/admin/bookings");
      setBookings(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const deleteBooking = async (id) => {
    if (!window.confirm("Видалити бронювання?")) return;
    try {
      await axios.delete(`/api/admin/bookings/${id}`);
      fetchBookings();
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return <div className="text-center py-20 text-gray-400">Завантаження...</div>;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Управління бронюваннями</h1>

      <div className="overflow-x-auto">
        <table className="w-full bg-white rounded-xl border border-gray-100">
          <thead>
            <tr className="text-left text-sm text-gray-500 border-b">
              <th className="px-4 py-3">Локація</th>
              <th className="px-4 py-3">Гість</th>
              <th className="px-4 py-3">Дата</th>
              <th className="px-4 py-3">Час</th>
              <th className="px-4 py-3">Сума</th>
              <th className="px-4 py-3">Статус</th>
              <th className="px-4 py-3">Дії</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b._id} className="border-b last:border-0 text-sm">
                <td className="px-4 py-3 font-medium">{b.listing_id?.title || "—"}</td>
                <td className="px-4 py-3 text-gray-600">{b.guest_id?.name || b.guestFullName || "—"}</td>
                <td className="px-4 py-3 text-gray-600">
                  {new Date(b.date).toLocaleDateString("uk-UA")}
                </td>
                <td className="px-4 py-3 text-gray-600">
                  {b.start_time}:00-{b.end_time}:00
                </td>
                <td className="px-4 py-3 font-medium">{b.total_price} грн</td>
                <td className="px-4 py-3 text-xs">
                  {statusLabels[b.booking_status] || b.booking_status}
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => deleteBooking(b._id)}
                    className="text-xs px-2 py-1 rounded bg-red-50 text-red-600 hover:bg-red-100"
                  >
                    Видалити
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminBookings;
