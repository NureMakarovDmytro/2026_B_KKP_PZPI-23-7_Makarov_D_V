const Section = ({ title, children }) => (
  <section className="mb-10">
    <h2 className="text-xl md:text-2xl font-semibold text-gray-900 mb-3">{title}</h2>
    <div className="text-sm md:text-base text-gray-600 space-y-3 leading-relaxed">{children}</div>
  </section>
);

const Faq = ({ q, a }) => (
  <div className="border-b border-gray-200 py-4">
    <p className="font-medium text-gray-900 mb-1">{q}</p>
    <p className="text-sm text-gray-600">{a}</p>
  </div>
);

const SupportPage = () => {
  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">Підтримка</p>
      <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8">Ми поруч — допоможемо з будь-яким питанням</h1>

      <Section title="Зв'язатися з нами">
        <p>Команда підтримки Basik доступна щодня з 9:00 до 21:00 за київським часом.</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Email: <a href="mailto:support@basik.com" className="text-gray-900 underline">support@basik.com</a></li>
          <li>Telegram: <span className="text-gray-900">@basik_support</span></li>
          <li>Гаряча лінія: <span className="text-gray-900">0 800 00 00 00</span> (безкоштовно по Україні)</li>
        </ul>
        <p>Зазвичай ми відповідаємо протягом 1–2 годин у робочий час.</p>
      </Section>

      <Section title="Безпека">
        <p>Ми робимо все, щоб бронювання на Basik було безпечним як для гостей, так і для власників.</p>
        <ul className="list-disc pl-5 space-y-2">
          <li><b>Перевірка email.</b> Кожен користувач підтверджує пошту перед бронюванням.</li>
          <li><b>Модерація локацій.</b> Адміністратори перевіряють кожну нову локацію перед публікацією.</li>
          <li><b>Захищені платежі.</b> Оплата проходить через сертифікованого еквайра — картки не зберігаються в нашій базі.</li>
          <li><b>Гарантія повернення.</b> Якщо локація не відповідає опису — звертайтесь, і ми повернемо кошти.</li>
          <li><b>Ваші дані під захистом.</b> Дотримуємось вимог GDPR та законодавства України про захист персональних даних.</li>
        </ul>
      </Section>

      <Section title="Часті питання">
        <Faq
          q="Як забронювати локацію?"
          a="Оберіть простір, виберіть дату та час, надішліть запит. Власник підтвердить його — після цього ви оплатите та отримаєте підтвердження."
        />
        <Faq
          q="Чи можна скасувати бронювання?"
          a="Так. Безкоштовне скасування доступне за 24 години до візиту. Пізніше може стягуватись комісія залежно від політики власника."
        />
        <Faq
          q="Як оплатити бронювання?"
          a="Оплата здійснюється карткою Visa або Mastercard через захищений платіжний шлюз одразу після підтвердження власником."
        />
        <Faq
          q="Що робити, якщо локація не відповідає опису?"
          a="Напишіть нам на support@basik.com впродовж 24 годин після візиту з фото та описом проблеми — ми розглянемо звернення та повернемо кошти, якщо претензія підтвердиться."
        />
        <Faq
          q="Чи є мобільний застосунок?"
          a="Поки ні — Basik повністю працює у браузері та адаптований для смартфонів. Застосунок плануємо випустити пізніше."
        />
        <Faq
          q="Як стати власником на Basik?"
          a="Натисніть «Здати в оренду», оберіть роль «Власник», заповніть профіль і додайте першу локацію. Після модерації її побачать гості."
        />
      </Section>
    </div>
  );
};

export default SupportPage;
