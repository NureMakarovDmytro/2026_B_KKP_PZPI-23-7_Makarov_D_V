import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const Stat = ({ label, value, hint, accent }) => (
  <div className="bg-white border border-gray-200 rounded-xl p-5">
    <p className="text-xs uppercase tracking-wider text-gray-500 font-medium mb-2">{label}</p>
    <p className={`text-2xl md:text-3xl font-bold ${accent ? "text-gray-900" : "text-gray-900"}`}>
      {value}
    </p>
    {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
  </div>
);

const StatusBadge = ({ status }) => {
  const map = {
    pending: { c: "bg-yellow-50 text-yellow-700 border-yellow-200", t: "Очікує" },
    confirmed: { c: "bg-green-50 text-green-700 border-green-200", t: "Підтверджено" },
    completed: { c: "bg-gray-100 text-gray-600 border-gray-200", t: "Завершено" },
    cancelled: { c: "bg-red-50 text-red-700 border-red-200", t: "Скасовано" },
  };
  const s = map[status] || map.pending;
  return <span className={`text-[11px] px-2 py-0.5 rounded-full border ${s.c}`}>{s.t}</span>;
};

const HostDashboard = ({ auth }) => {
  const [listings, setListings] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!auth.user || auth.user.role !== "Host") {
      navigate("/");
      return;
    }
    load();
  }, []);

  const load = async () => {
    try {
      const [l, b] = await Promise.all([
        axios.get("/api/listings/my-listings"),
        axios.get("/api/bookings/host"),
      ]);
      setListings(l.data || []);
      setBookings(b.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const active = bookings.filter((b) => ["pending", "confirmed"].includes(b.booking_status));
  const completed = bookings.filter((b) => b.booking_status === "completed");
  const pending = bookings.filter((b) => b.booking_status === "pending");
  const revenue = completed.reduce((s, b) => s + b.total_price, 0);
  const approved = listings.filter((l) => l.isApproved && l.isListed);
  const onModeration = listings.filter((l) => !l.isApproved);

  if (loading) return <p className="text-center py-16 text-gray-400 text-sm">Завантаження...</p>;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-start justify-between mb-8 gap-3 flex-wrap">
        <div>
          <p className="text-xs uppercase tracking-wider text-gray-500 font-medium mb-1">
            Панель власника
          </p>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
            Вітаємо, {auth.user.name}
          </h1>
        </div>
        <Link
          to="/add-listing"
          className="bg-gray-900 hover:bg-black text-white text-sm font-medium px-5 py-2.5 rounded-full transition"
        >
          + Додати локацію
        </Link>
      </div>

      {/* Empty state */}
      {listings.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-gray-300 rounded-2xl">
          <div className="text-4xl mb-3">🏠</div>
          <p className="text-base font-semibold text-gray-900 mb-1">Ще немає локацій</p>
          <p className="text-sm text-gray-500 mb-5">
            Додайте першу локацію і отримайте бронювання
          </p>
          <Link
            to="/add-listing"
            className="inline-block bg-gray-900 hover:bg-black text-white text-sm font-medium px-5 py-2.5 rounded-full transition"
          >
            + Додати першу локацію
          </Link>
        </div>
      ) : (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
            <Stat
              label="Локації"
              value={listings.length}
              hint={`${approved.length} активних${onModeration.length ? ` · ${onModeration.length} на модерації` : ""}`}
            />
            <Stat
              label="Активні"
              value={active.length}
              hint={pending.length > 0 ? `${pending.length} очікує підтвердження` : "Усе під контролем"}
            />
            <Stat
              label="Завершено"
              value={completed.length}
              hint="Всього візитів"
            />
            <Stat
              label="Дохід"
              value={`${revenue.toLocaleString()} ₴`}
              hint="За весь час"
            />
          </div>

          {/* Quick actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-8">
            <Link
              to="/my-listings"
              className="bg-white border border-gray-200 hover:border-gray-900 rounded-xl p-5 transition group"
            >
              <p className="text-xs uppercase tracking-wider text-gray-500 mb-1">Локації</p>
              <p className="font-semibold text-gray-900 group-hover:underline">Мої локації →</p>
              <p className="text-xs text-gray-500 mt-1">Редагувати, ховати, видаляти</p>
            </Link>
            <Link
              to="/host-bookings"
              className="bg-white border border-gray-200 hover:border-gray-900 rounded-xl p-5 transition group"
            >
              <p className="text-xs uppercase tracking-wider text-gray-500 mb-1">Бронювання</p>
              <p className="font-semibold text-gray-900 group-hover:underline">
                {active.length} активних →
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {pending.length > 0 ? `${pending.length} очікує вас` : "Усе під контролем"}
              </p>
            </Link>
            <Link
              to="/profile"
              className="bg-white border border-gray-200 hover:border-gray-900 rounded-xl p-5 transition group"
            >
              <p className="text-xs uppercase tracking-wider text-gray-500 mb-1">Профіль</p>
              <p className="font-semibold text-gray-900 group-hover:underline">Налаштування →</p>
              <p className="text-xs text-gray-500 mt-1">Реквізити, контакти</p>
            </Link>
          </div>

          {/* Upcoming bookings */}
          {active.length > 0 && (
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-base font-semibold text-gray-900">Найближчі бронювання</h2>
                <Link to="/host-bookings" className="text-xs text-gray-500 hover:text-gray-900 underline underline-offset-4">
                  Усі бронювання
                </Link>
              </div>
              <div className="space-y-2">
                {active.slice(0, 5).map((b) => (
                  <div
                    key={b._id}
                    className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {b.listing_id?.title || "Локація"}
                        </p>
                        <StatusBadge status={b.booking_status} />
                      </div>
                      <p className="text-xs text-gray-500">
                        {b.guestFullName || b.guest_id?.name} ·{" "}
                        {new Date(b.date).toLocaleDateString("uk-UA")} ·{" "}
                        {b.start_time}:00–{b.end_time}:00
                      </p>
                    </div>
                    <p className="text-sm font-semibold text-gray-900 whitespace-nowrap">
                      {b.total_price} ₴
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tips when few listings */}
          {listings.length < 3 && (
            <div className="bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-xl p-5">
              <p className="text-sm font-semibold text-gray-900 mb-1">💡 Порада</p>
              <p className="text-sm text-gray-600">
                Власники з 3+ локаціями отримують у середньому в 2 рази більше бронювань.
                Розгляньте можливість додати ще один простір.
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default HostDashboard;
