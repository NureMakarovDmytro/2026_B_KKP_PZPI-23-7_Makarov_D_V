import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import Hero from "../components/Hero";
import ListingCard from "../components/ListingCard";
import { getCategoryFallbacks } from "../utils/listingImages";

const CATEGORIES = [
  { name: "Коворкінг", emoji: "💻" },
  { name: "Конференц-зал", emoji: "🎤" },
  { name: "Фотостудія", emoji: "📸" },
  { name: "Спортзал", emoji: "🏋️" },
  { name: "Подієва локація", emoji: "🎉" },
  { name: "Інше", emoji: "✨" },
];

const CITIES = [
  { name: "Київ", query: "Київ", emoji: "🏛️" },
  { name: "Львів", query: "Львів", emoji: "🦁" },
  { name: "Одеса", query: "Одеса", emoji: "🌊" },
];

const HomePage = ({ auth }) => {
  const [popular, setPopular] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (auth.user?.role === "Admin") {
      navigate("/admin");
      return;
    }
    if (auth.user?.role === "Host") {
      navigate("/host");
      return;
    }
    loadAll();
  }, [auth.user]);

  const loadAll = async () => {
    try {
      const { data } = await axios.get("/api/listings?limit=8&sort=newest");
      setPopular(data.listings || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const Section = ({ title, subtitle, link, children }) => (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="flex items-end justify-between mb-5">
        <div>
          <h2 className="text-xl md:text-2xl font-semibold text-gray-900">{title}</h2>
          {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
        </div>
        {link && (
          <Link to={link} className="hidden sm:inline text-sm text-gray-900 underline underline-offset-4 hover:opacity-70">
            Переглянути всі
          </Link>
        )}
      </div>
      {children}
    </div>
  );

  const Skeleton = ({ count = 4 }) => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="bg-gray-100 rounded-lg aspect-[4/3] animate-pulse" />
      ))}
    </div>
  );

  return (
    <div>
      <Hero />

      {/* Categories */}
      <Section title="Категорії" subtitle="Оберіть тип простору">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {CATEGORIES.map((c) => {
            const cover = getCategoryFallbacks(c.name)[0];
            return (
              <button
                key={c.name}
                onClick={() => navigate(`/search?category=${encodeURIComponent(c.name)}`)}
                className="group relative aspect-square rounded-lg overflow-hidden border border-gray-200 hover:border-gray-900 transition"
              >
                <img
                  src={cover}
                  alt={c.name}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-2 text-left">
                  <p className="text-white text-xs font-medium drop-shadow">{c.emoji} {c.name}</p>
                </div>
              </button>
            );
          })}
        </div>
      </Section>

      {/* Popular */}
      <Section title="Популярні локації" subtitle="Свіжододанні простори на Basik" link="/search">
        {loading ? <Skeleton /> : popular.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {popular.map((l) => <ListingCard key={l._id} listing={l} />)}
          </div>
        ) : (
          <p className="text-sm text-gray-400">Поки що немає локацій</p>
        )}
      </Section>

      {/* Cities */}
      <Section title="За містами" subtitle="Знайдіть простір там, де потрібно">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {CITIES.map((city) => (
            <button
              key={city.name}
              onClick={() => navigate(`/search?search=${encodeURIComponent(city.query)}`)}
              className="group relative h-40 rounded-lg overflow-hidden border border-gray-200 hover:border-gray-900 transition text-left"
            >
              <img
                src={getCategoryFallbacks("Подієва локація")[CITIES.indexOf(city) % 5]}
                alt={city.name}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4">
                <p className="text-white text-lg font-semibold drop-shadow">{city.emoji} {city.name}</p>
                <p className="text-white/80 text-xs">Дивитися локації</p>
              </div>
            </button>
          ))}
        </div>
      </Section>

      {/* How it works */}
      <div className="bg-gray-50 border-y border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-14">
          <div className="text-center mb-10">
            <h2 className="text-xl md:text-2xl font-semibold text-gray-900">Як це працює</h2>
            <p className="text-sm text-gray-500 mt-1">Орендуйте простір за три кроки</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { n: "1", t: "Знайдіть локацію", d: "Оберіть категорію, місто та дату — переглядайте простори з фото та цінами." },
              { n: "2", t: "Забронюйте онлайн", d: "Виберіть години, надішліть запит — власник підтвердить бронювання." },
              { n: "3", t: "Користуйтеся", d: "Приходьте у обраний час та насолоджуйтеся простором." },
            ].map((s) => (
              <div key={s.n} className="bg-white rounded-lg border border-gray-200 p-6">
                <div className="w-10 h-10 rounded-full bg-gray-900 text-white flex items-center justify-center text-sm font-semibold mb-4">
                  {s.n}
                </div>
                <h3 className="text-base font-semibold text-gray-900 mb-2">{s.t}</h3>
                <p className="text-sm text-gray-500">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Host CTA */}
      <div className="border-t border-gray-200 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <div className="max-w-5xl mx-auto px-4 py-16 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <p className="text-xs uppercase tracking-wider text-white/60 font-semibold mb-3">Для власників</p>
            <h2 className="text-2xl md:text-3xl font-semibold mb-3">
              Маєте простір? Здайте його погодинно
            </h2>
            <p className="text-sm md:text-base text-white/70 mb-6">
              Зареєструйтесь як власник, додайте фото, опис та ціну — і починайте отримувати бронювання вже сьогодні.
            </p>
            <button
              onClick={() => navigate("/host-landing")}
              className="bg-white hover:bg-gray-100 text-gray-900 text-sm font-medium px-6 py-3 rounded-full transition"
            >
              Стати власником
            </button>
          </div>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="bg-white/10 rounded-lg p-4 border border-white/10">
              <p className="text-2xl font-bold">100+</p>
              <p className="text-xs text-white/60 mt-1">Локацій</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4 border border-white/10">
              <p className="text-2xl font-bold">3</p>
              <p className="text-xs text-white/60 mt-1">Міста</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4 border border-white/10">
              <p className="text-2xl font-bold">24/7</p>
              <p className="text-xs text-white/60 mt-1">Підтримка</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
