import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const AdminDashboard = ({ auth }) => {
  const [stats, setStats] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!auth.user || auth.user.role !== "Admin") {
      navigate("/");
      return;
    }
    load();
  }, []);

  const load = async () => {
    try {
      const { data } = await axios.get("/api/admin/stats");
      setStats(data);
    } catch (err) {
      console.error(err);
    }
  };

  const links = [
    { to: "/admin/users", label: "Користувачі" },
    { to: "/admin/listings", label: "Локації" },
    { to: "/admin/bookings", label: "Бронювання" },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-xl font-semibold text-gray-900 mb-6">Адмін-панель</h1>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
          <div className="border border-gray-200 rounded p-4">
            <p className="text-xs text-gray-500">Користувачів</p>
            <p className="text-2xl font-semibold text-gray-900">{stats.totalUsers}</p>
          </div>
          <div className="border border-gray-200 rounded p-4">
            <p className="text-xs text-gray-500">Локацій</p>
            <p className="text-2xl font-semibold text-gray-900">{stats.totalListings}</p>
          </div>
          <div className="border border-gray-200 rounded p-4">
            <p className="text-xs text-gray-500">Бронювань</p>
            <p className="text-2xl font-semibold text-gray-900">{stats.totalBookings}</p>
          </div>
          <div className="border border-gray-200 rounded p-4">
            <p className="text-xs text-gray-500">Дохід</p>
            <p className="text-2xl font-semibold text-gray-900">
              {Math.round(stats.totalRevenue).toLocaleString()} грн
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {links.map((l) => (
          <Link
            key={l.to}
            to={l.to}
            className="border border-gray-200 rounded p-5 text-sm text-gray-900 hover:border-gray-900"
          >
            {l.label}
          </Link>
        ))}
      </div>
    </div>
  );
};

export default AdminDashboard;
