const SafetyPage = () => (
  <div className="max-w-3xl mx-auto px-4 py-12">
    <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">Безпека</p>
    <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Ваша безпека — наш пріоритет</h1>
    <p className="text-gray-500 text-sm mb-10">Basik забезпечує захист для всіх учасників платформи — гостей і власників.</p>

    <div className="space-y-6 mb-12">
      {[
        {
          icon: "✉️",
          title: "Підтвердження email",
          text: "Кожен користувач підтверджує свою пошту перед першим бронюванням. Це гарантує, що акаунти реальні й мають власника.",
        },
        {
          icon: "🔍",
          title: "Модерація локацій",
          text: "Кожна нова локація проходить перевірку адміністратором перед публікацією. Ми переконуємося, що опис, фото та інформація відповідають дійсності.",
        },
        {
          icon: "💳",
          title: "Захищені платежі",
          text: "Усі платежі проходять через Stripe — сертифікований платіжний провайдер. Дані вашої картки не зберігаються на наших серверах.",
        },
        {
          icon: "↩️",
          title: "Гарантія повернення",
          text: "Якщо локація не відповідає опису або сталася форс-мажорна ситуація — зверніться до підтримки впродовж 24 годин. Ми розглянемо та повернемо кошти.",
        },
        {
          icon: "🔒",
          title: "Захист персональних даних",
          text: "Ми дотримуємось вимог GDPR та законодавства України. Ваші дані не передаються третім особам без вашої згоди.",
        },
        {
          icon: "🛡️",
          title: "Система відгуків",
          text: "Після кожного бронювання обидві сторони можуть залишити відгук. Це забезпечує прозорість і дозволяє відстежувати несумлінних учасників.",
        },
      ].map(({ icon, title, text }) => (
        <div key={title} className="flex gap-4 p-5 border border-gray-200 rounded-xl">
          <span className="text-2xl shrink-0">{icon}</span>
          <div>
            <p className="font-semibold text-gray-900 mb-1">{title}</p>
            <p className="text-sm text-gray-600 leading-relaxed">{text}</p>
          </div>
        </div>
      ))}
    </div>

    <section className="mb-10">
      <h2 className="text-xl font-semibold text-gray-900 mb-4">Поради для безпечної оренди</h2>
      <div className="space-y-3 text-sm text-gray-600 leading-relaxed">
        <p>— Завжди перевіряйте фото та відгуки перед бронюванням.</p>
        <p>— Не передавайте гроші поза платформою — лише через Basik.</p>
        <p>— Якщо помітили підозрілу активність — одразу повідомте підтримку.</p>
        <p>— Ознайомтесь із правилами локації перед бронюванням.</p>
        <p>— Зберігайте підтвердження бронювання на випадок спору.</p>
      </div>
    </section>

    <div className="p-6 bg-gray-50 rounded-xl border border-gray-200">
      <p className="font-semibold text-gray-900 mb-1">Є питання або проблема?</p>
      <p className="text-sm text-gray-600 mb-3">Команда підтримки відповідає щодня з 9:00 до 21:00.</p>
      <a
        href="mailto:support@basik.com"
        className="inline-block bg-gray-900 hover:bg-black text-white text-sm font-medium px-6 py-2.5 rounded-full transition"
      >
        Написати в підтримку
      </a>
    </div>
  </div>
);

export default SafetyPage;
