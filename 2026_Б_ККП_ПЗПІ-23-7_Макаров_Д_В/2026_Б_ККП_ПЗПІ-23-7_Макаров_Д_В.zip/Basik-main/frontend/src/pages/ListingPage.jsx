import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import GalleryModal from "../components/GalleryModal";
import MapView from "../components/MapView";
import { getCategoryFallbacks } from "../utils/listingImages";

const DAYS = ["Неділя", "Понеділок", "Вівторок", "Середа", "Четвер", "П'ятниця", "Субота"];

const ListingPage = ({ auth }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [listing, setListing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [galleryIndex, setGalleryIndex] = useState(0);

  const [date, setDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [guests, setGuests] = useState(1);
  const [bookedSlots, setBookedSlots] = useState([]);

  useEffect(() => {
    loadListing();
    setBookedSlots([]);
    setDate("");
    setStartTime("");
    setEndTime("");
  }, [id]);

  useEffect(() => {
    if (date && id) loadSlots();
  }, [date, id]);

  const loadListing = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`/api/listings/${id}`);
      setListing(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadSlots = async () => {
    try {
      const { data } = await axios.get(`/api/listings/${id}/booked-slots?date=${date}`);
      setBookedSlots(data);
    } catch (err) {
      console.error(err);
    }
  };

  const isBooked = (h) => bookedSlots.some((s) => h >= s.start_time && h < s.end_time);

  // Get availability for the selected day of week
  const today = new Date().toISOString().split("T")[0];
  const currentHour = new Date().getHours();
  const selectedDayOfWeek = date ? new Date(date + "T12:00:00").getDay() : null;
  const dayAvail = listing?.availability?.find((a) => a.day_of_week === selectedDayOfWeek);
  const isDayClosed = date && dayAvail && !dayAvail.is_available;
  const openHour = dayAvail?.is_available ? dayAvail.open_hour : 0;
  const closeHour = dayAvail?.is_available ? dayAvail.close_hour : 24;

  // For today — block hours that already passed
  const isPastHour = (h) => date === today && h <= currentHour;

  const availableStartHours = Array.from({ length: 24 }, (_, i) => i).filter(
    (h) => h >= openHour && h < closeHour && !isBooked(h) && !isPastHour(h)
  );
  const isNoHoursLeft = date && !isDayClosed && availableStartHours.length === 0;

  const availableEndHours = Array.from({ length: 24 }, (_, i) => i + 1).filter(
    (h) => h > parseInt(startTime || 0) && h <= closeHour
  );

  // Guests validation
  const guestsOverLimit = guests > listing?.max_guests;

  const totalHours = startTime && endTime ? parseInt(endTime) - parseInt(startTime) : 0;
  const totalPrice = totalHours > 0 && listing ? totalHours * listing.price_per_hour : 0;

  const onBook = () => {
    if (!auth.user) {
      navigate("/auth");
      return;
    }
    if (!date || !startTime || !endTime || totalHours <= 0) return;
    const params = new URLSearchParams({ date, startTime, endTime, guests });
    navigate(`/booking/${id}?${params.toString()}`);
  };

  if (loading) return <p className="text-center py-16 text-gray-400 text-sm">Завантаження...</p>;
  if (!listing) return <p className="text-center py-16 text-gray-400 text-sm">Локацію не знайдено</p>;

  // Only real uploaded photos — no stock fallbacks mixed in
  const realPhotos = (listing.photos || []).map((p) => p.url).filter(Boolean);
  const fallback = getCategoryFallbacks(listing.category)[0];
  const photos = realPhotos.length > 0 ? realPhotos : [fallback];
  const photoObjects = photos.map((url) => ({ url }));
  const hostInitial = listing.host_id?.name?.[0]?.toUpperCase() || "B";

  const openGallery = (idx) => {
    setGalleryIndex(idx);
    setGalleryOpen(true);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="mb-4">
        <h1 className="text-2xl md:text-3xl font-semibold text-gray-900">{listing.title}</h1>
        <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
          <span>{listing.category}</span>
          <span className="text-gray-300">•</span>
          <span>{listing.address}</span>
        </div>
      </div>

      <div className="relative mb-8 rounded-lg overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-4 md:grid-rows-2 gap-2 h-[280px] md:h-[440px]">
          <button
            type="button"
            onClick={() => openGallery(0)}
            className="md:col-span-2 md:row-span-2 bg-gray-100 overflow-hidden group h-full w-full"
          >
            <img
              src={photos[0]}
              alt=""
              className="w-full h-full object-cover group-hover:opacity-95 transition"
            />
          </button>
          {[1, 2, 3, 4].map((i) =>
            photos[i] ? (
              <button
                key={i}
                type="button"
                onClick={() => openGallery(i)}
                className="hidden md:block bg-gray-100 overflow-hidden group h-full w-full"
              >
                <img
                  src={photos[i]}
                  alt=""
                  className="w-full h-full object-cover group-hover:opacity-95 transition"
                />
              </button>
            ) : (
              <div key={i} className="hidden md:block bg-gray-100 h-full w-full" />
            )
          )}
        </div>
        {photos.length > 1 && (
          <button
            type="button"
            onClick={() => openGallery(0)}
            className="absolute bottom-3 right-3 bg-white text-gray-900 text-xs px-3 py-1.5 rounded border border-gray-200 hover:border-gray-900 shadow-sm"
          >
            Усі фото ({photos.length})
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-8">
          <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm pb-6 border-b border-gray-200">
            <Stat label="Гості" value={`До ${listing.max_guests}`} />
            <Stat label="Категорія" value={listing.category} />
            <Stat label="Ціна" value={`${listing.price_per_hour} грн/год`} />
            {listing.amenities?.length > 0 && (
              <Stat label="Зручності" value={`${listing.amenities.length} опцій`} />
            )}
          </div>

          <section className="pb-6 border-b border-gray-200">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-gray-900 text-white flex items-center justify-center text-sm font-medium">
                {hostInitial}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">
                  Власник: {listing.host_id?.name || "—"}
                </p>
                <p className="text-xs text-gray-500">Перевірений власник на Basik</p>
              </div>
            </div>
          </section>

          <section className="pb-6 border-b border-gray-200">
            <h2 className="text-base font-semibold text-gray-900 mb-2">Опис</h2>
            <p className="text-sm text-gray-700 whitespace-pre-line leading-relaxed">
              {listing.description}
            </p>
          </section>

          {listing.amenities?.length > 0 && (
            <section className="pb-6 border-b border-gray-200">
              <h2 className="text-base font-semibold text-gray-900 mb-3">Що пропонує локація</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-y-2 gap-x-4 text-sm text-gray-700">
                {listing.amenities.map((a, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-gray-900" />
                    {a}
                  </div>
                ))}
              </div>
            </section>
          )}

          {listing.availability?.length > 0 && (
            <section className="pb-6 border-b border-gray-200">
              <h2 className="text-base font-semibold text-gray-900 mb-3">Графік роботи</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-1 text-sm">
                {[...listing.availability]
                  .sort((a, b) => a.day_of_week - b.day_of_week)
                  .map((av, i) => (
                    <div
                      key={i}
                      className="flex justify-between py-1 border-b border-gray-100 last:border-0"
                    >
                      <span className="text-gray-700">{DAYS[av.day_of_week]}</span>
                      <span className={av.is_available ? "text-gray-900" : "text-gray-400"}>
                        {av.is_available
                          ? `${av.open_hour}:00 – ${av.close_hour}:00`
                          : "Зачинено"}
                      </span>
                    </div>
                  ))}
              </div>
            </section>
          )}

          {listing.rules?.length > 0 && (
            <section>
              <h2 className="text-base font-semibold text-gray-900 mb-3">Правила локації</h2>
              <ul className="text-sm text-gray-700 space-y-1.5">
                {listing.rules.map((r, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-gray-400 mt-0.5">—</span>
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <section>
            <h2 className="text-base font-semibold text-gray-900 mb-3">Розташування</h2>
            <p className="text-sm text-gray-600 mb-3">{listing.address}</p>
            <MapView listing={listing} height="h-72" />
            <p className="text-xs text-gray-400 mt-2">
              Точна адреса буде надіслана після підтвердження бронювання
            </p>
          </section>
        </div>

        <aside className="lg:col-span-1">
          <div className="sticky top-4 border border-gray-200 rounded-lg p-5 bg-white">
            <p className="text-2xl font-semibold text-gray-900 mb-1">
              {listing.price_per_hour} грн
              <span className="text-sm font-normal text-gray-500"> / год</span>
            </p>
            <p className="text-xs text-gray-500 mb-4">До {listing.max_guests} гостей</p>

            <div className="space-y-3">
              <div>
                <label className="block text-[11px] uppercase tracking-wide text-gray-500 mb-1">
                  Дата
                </label>
                <input
                  type="date"
                  value={date}
                  min={today}
                  onChange={(e) => {
                    setDate(e.target.value);
                    setStartTime("");
                    setEndTime("");
                  }}
                  className={`w-full border rounded px-2 py-2 text-sm focus:outline-none transition ${
                    isDayClosed || isNoHoursLeft
                      ? "border-red-300 bg-red-50 focus:border-red-400"
                      : "border-gray-300 focus:border-gray-900"
                  }`}
                />
              </div>

              {isDayClosed && (
                <div className="bg-red-50 border border-red-200 text-red-600 text-xs rounded px-3 py-2">
                  Локація не працює в цей день тижня. Оберіть іншу дату.
                </div>
              )}

              {isNoHoursLeft && (
                <div className="bg-red-50 border border-red-200 text-red-600 text-xs rounded px-3 py-2">
                  На цей день вільних слотів немає. Оберіть іншу дату.
                </div>
              )}

              {date && dayAvail?.is_available && !isNoHoursLeft && (
                <p className="text-xs text-gray-400">
                  Графік роботи: {openHour}:00 – {closeHour}:00
                </p>
              )}

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] uppercase tracking-wide text-gray-500 mb-1">
                    Початок
                  </label>
                  <select
                    value={startTime}
                    onChange={(e) => { setStartTime(e.target.value); setEndTime(""); }}
                    disabled={!date || isDayClosed}
                    className="w-full border border-gray-300 rounded px-2 py-2 text-sm focus:outline-none focus:border-gray-900 disabled:opacity-50"
                  >
                    <option value="">--</option>
                    {availableStartHours.map((h) => (
                      <option key={h} value={h}>{String(h).padStart(2, "0")}:00</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] uppercase tracking-wide text-gray-500 mb-1">
                    Кінець
                  </label>
                  <select
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    disabled={!startTime || isDayClosed}
                    className="w-full border border-gray-300 rounded px-2 py-2 text-sm focus:outline-none focus:border-gray-900 disabled:opacity-50"
                  >
                    <option value="">--</option>
                    {availableEndHours.map((h) => (
                      <option key={h} value={h}>{String(h).padStart(2, "0")}:00</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] uppercase tracking-wide text-gray-500 mb-1">
                  Гості
                </label>
                <input
                  type="number"
                  min="1"
                  max={listing.max_guests}
                  value={guests}
                  onChange={(e) => {
                    const val = parseInt(e.target.value) || 1;
                    setGuests(Math.min(val, listing.max_guests));
                  }}
                  className={`w-full border rounded px-2 py-2 text-sm focus:outline-none transition ${
                    guestsOverLimit
                      ? "border-red-300 bg-red-50 focus:border-red-400"
                      : "border-gray-300 focus:border-gray-900"
                  }`}
                />
                {guestsOverLimit && (
                  <p className="text-xs text-red-500 mt-1">
                    Максимум {listing.max_guests} гостей для цієї локації
                  </p>
                )}
              </div>

              {totalPrice > 0 && (
                <div className="border-t border-gray-100 pt-3 text-sm space-y-1">
                  <div className="flex justify-between text-gray-500">
                    <span>
                      {listing.price_per_hour} × {totalHours} год
                    </span>
                    <span>{totalPrice} грн</span>
                  </div>
                  <div className="flex justify-between font-semibold text-gray-900 pt-1">
                    <span>Разом</span>
                    <span>{totalPrice} грн</span>
                  </div>
                </div>
              )}

              <button
                onClick={onBook}
                disabled={!date || !startTime || !endTime || totalHours <= 0 || isDayClosed || isNoHoursLeft || guestsOverLimit}
                className="w-full bg-gray-900 hover:bg-black text-white text-sm py-2.5 rounded disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                Забронювати
              </button>
              <p className="text-[11px] text-gray-400 text-center">
                Оплата ще не списується
              </p>
            </div>
          </div>
        </aside>
      </div>

      {galleryOpen && (
        <GalleryModal
          photos={photoObjects}
          initialIndex={galleryIndex}
          onClose={() => setGalleryOpen(false)}
        />
      )}
    </div>
  );
};

const Stat = ({ label, value }) => (
  <div>
    <p className="text-[11px] uppercase tracking-wide text-gray-400">{label}</p>
    <p className="text-sm text-gray-900 font-medium">{value}</p>
  </div>
);

export default ListingPage;
