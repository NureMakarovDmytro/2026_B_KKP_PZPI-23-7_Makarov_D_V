import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import axios from "axios";
import ListingCard from "../components/ListingCard";
import MapView from "../components/MapView";
import Pagination from "../components/Pagination";

const CATEGORIES = [
  { name: "Усі", value: "", emoji: "✦" },
  { name: "Коворкінг", value: "Коворкінг", emoji: "💻" },
  { name: "Конференц-зал", value: "Конференц-зал", emoji: "🎤" },
  { name: "Фотостудія", value: "Фотостудія", emoji: "📸" },
  { name: "Спортзал", value: "Спортзал", emoji: "🏋️" },
  { name: "Подієва локація", value: "Подієва локація", emoji: "🎉" },
  { name: "Інше", value: "Інше", emoji: "✨" },
];

const SORT_OPTIONS = [
  { value: "", label: "За замовчуванням" },
  { value: "price_asc", label: "Ціна: менше" },
  { value: "price_desc", label: "Ціна: більше" },
  { value: "newest", label: "Нові" },
];

const QUICK_PRICE = [
  { value: "", label: "Усі ціни" },
  { value: "300", label: "До 300 грн" },
  { value: "500", label: "До 500 грн" },
  { value: "1000", label: "До 1000 грн" },
];

const SearchResults = () => {
  const [searchParams] = useSearchParams();
  const [listings, setListings] = useState([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [activeId, setActiveId] = useState(null);

  const [filters, setFilters] = useState({
    search: searchParams.get("search") || "",
    category: searchParams.get("category") || "",
    minPrice: searchParams.get("minPrice") || "",
    maxPrice: searchParams.get("maxPrice") || "",
    maxGuests: searchParams.get("maxGuests") || "",
    date: searchParams.get("date") || "",
    sort: searchParams.get("sort") || "",
    page: parseInt(searchParams.get("page")) || 1,
  });

  // Local input mirrors for the top search bar (don't trigger fetch on each keystroke)
  const [searchInput, setSearchInput] = useState(filters.search);
  const [guestsInput, setGuestsInput] = useState(filters.maxGuests);
  const [dateInput, setDateInput] = useState(filters.date);

  useEffect(() => {
    load();
  }, [
    filters.page,
    filters.sort,
    filters.category,
    filters.maxPrice,
    filters.minPrice,
    filters.maxGuests,
    filters.search,
    filters.date,
  ]);

  const load = async () => {
    setLoading(true);
    try {
      const params = {};
      Object.entries(filters).forEach(([k, v]) => {
        if (v) params[k] = v;
      });
      const { data } = await axios.get("/api/listings", { params });
      setListings(data.listings || []);
      setTotal(data.total || 0);
      setTotalPages(data.totalPages || 1);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const set = (k, v) => setFilters((p) => ({ ...p, [k]: v, page: 1 }));

  const onTopSearch = (e) => {
    e.preventDefault();
    setFilters((p) => ({
      ...p,
      search: searchInput,
      maxGuests: guestsInput,
      date: dateInput,
      page: 1,
    }));
  };

  const clearAll = () => {
    setSearchInput("");
    setGuestsInput("");
    setDateInput("");
    setFilters({
      search: "",
      category: "",
      minPrice: "",
      maxPrice: "",
      maxGuests: "",
      date: "",
      sort: "",
      page: 1,
    });
  };

  const activeChipCount =
    (filters.search ? 1 : 0) +
    (filters.category ? 1 : 0) +
    (filters.minPrice ? 1 : 0) +
    (filters.maxPrice ? 1 : 0) +
    (filters.maxGuests ? 1 : 0) +
    (filters.date ? 1 : 0);

  return (
    <div>
      {/* Swimply-style top search bar */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <form
            onSubmit={onTopSearch}
            className="flex items-stretch gap-1 bg-white border border-gray-300 rounded-full p-1 shadow-sm focus-within:border-gray-900 transition"
          >
            <div className="flex-1 flex items-center px-4 min-w-0">
              <div className="w-full">
                <p className="text-[10px] uppercase tracking-wide text-gray-400 leading-none">
                  Локація
                </p>
                <input
                  type="text"
                  placeholder="Місто, район, адреса"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  className="w-full text-sm bg-transparent focus:outline-none mt-0.5 placeholder:text-gray-400"
                />
              </div>
            </div>
            <div className="hidden sm:block w-px bg-gray-200 my-2" />
            <div className="hidden sm:flex items-center px-4">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-gray-400 leading-none">
                  Дата
                </p>
                <input
                  type="date"
                  value={dateInput}
                  onChange={(e) => setDateInput(e.target.value)}
                  className="text-sm bg-transparent focus:outline-none mt-0.5 w-32"
                />
              </div>
            </div>
            <div className="hidden sm:block w-px bg-gray-200 my-2" />
            <div className="hidden sm:flex items-center px-4">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-gray-400 leading-none">
                  Гості
                </p>
                <input
                  type="number"
                  min="1"
                  placeholder="1 гість"
                  value={guestsInput}
                  onChange={(e) => setGuestsInput(e.target.value)}
                  className="text-sm bg-transparent focus:outline-none mt-0.5 w-20"
                />
              </div>
            </div>
            <button
              type="submit"
              className="bg-gray-900 hover:bg-black text-white rounded-full w-12 h-12 flex items-center justify-center flex-shrink-0 transition"
              aria-label="Пошук"
            >
              <span className="text-base">⌕</span>
            </button>
          </form>

          {/* Category icon tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pt-3 hide-scrollbar">
            {CATEGORIES.map((c) => {
              const active = filters.category === c.value;
              return (
                <button
                  key={c.value}
                  onClick={() => set("category", c.value)}
                  className={`flex flex-col items-center gap-1 flex-shrink-0 px-3 py-2 border-b-2 transition ${
                    active
                      ? "border-gray-900 text-gray-900"
                      : "border-transparent text-gray-500 hover:text-gray-900"
                  }`}
                >
                  <span className="text-xl leading-none">{c.emoji}</span>
                  <span className="text-[11px] font-medium whitespace-nowrap">{c.name}</span>
                </button>
              );
            })}
            <div className="ml-auto flex items-center gap-2 flex-shrink-0 pl-2">
              {QUICK_PRICE.map((p) => {
                const active =
                  (p.value === "" && !filters.maxPrice) ||
                  (p.value !== "" && filters.maxPrice === p.value);
                return (
                  <button
                    key={p.label}
                    onClick={() => set("maxPrice", p.value)}
                    className={`hidden lg:inline-flex flex-shrink-0 text-xs px-3 py-1.5 rounded-full border transition ${
                      active
                        ? "bg-gray-900 text-white border-gray-900"
                        : "border-gray-300 text-gray-700 hover:border-gray-900"
                    }`}
                  >
                    {p.label}
                  </button>
                );
              })}
              <button
                onClick={() => setFiltersOpen(true)}
                className="flex items-center gap-2 border border-gray-300 hover:border-gray-900 rounded-full px-4 py-2 text-sm transition relative"
              >
                <span>⚙</span>
                <span>Фільтри</span>
                {activeChipCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-gray-900 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center">
                    {activeChipCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Active filter chips */}
      {activeChipCount > 0 && (
        <div className="bg-white border-b border-gray-100">
          <div className="max-w-6xl mx-auto px-4 py-3 flex flex-wrap gap-2 text-xs">
            {filters.search && (
              <Chip onClose={() => { set("search", ""); setSearchInput(""); }}>
                Пошук: {filters.search}
              </Chip>
            )}
            {filters.category && <Chip onClose={() => set("category", "")}>{filters.category}</Chip>}
            {filters.date && (
              <Chip onClose={() => { set("date", ""); setDateInput(""); }}>
                Дата: {filters.date}
              </Chip>
            )}
            {filters.minPrice && <Chip onClose={() => set("minPrice", "")}>Від {filters.minPrice} грн</Chip>}
            {filters.maxPrice && <Chip onClose={() => set("maxPrice", "")}>До {filters.maxPrice} грн</Chip>}
            {filters.maxGuests && (
              <Chip onClose={() => { set("maxGuests", ""); setGuestsInput(""); }}>
                {filters.maxGuests}+ гостей
              </Chip>
            )}
            <button onClick={clearAll} className="text-gray-500 hover:text-gray-900 underline ml-1">
              Очистити все
            </button>
          </div>
        </div>
      )}

      {/* Results */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-5">
          <p className="text-sm text-gray-500">
            {loading ? "Пошук..." : `Знайдено ${total} ${total === 1 ? "локацію" : "локацій"}`}
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowMap((v) => !v)}
              className={`text-sm px-4 py-1.5 rounded-full border transition flex items-center gap-1.5 ${
                showMap
                  ? "bg-gray-900 text-white border-gray-900"
                  : "border-gray-300 text-gray-700 hover:border-gray-900"
              }`}
            >
              <span>🗺️</span>
              <span>{showMap ? "Сховати карту" : "Карта"}</span>
            </button>
            <select
              value={filters.sort}
              onChange={(e) => set("sort", e.target.value)}
              className="border border-gray-300 rounded-full px-4 py-1.5 text-sm focus:outline-none focus:border-gray-900"
            >
              {SORT_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
        </div>

        {showMap && listings.length > 0 && (
          <div className="mb-6 sticky top-16 z-10">
            <MapView
              listings={listings}
              height="h-[420px]"
              activeId={activeId}
              onMarkerClick={(id) => setActiveId(id)}
            />
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-gray-100 rounded-lg aspect-[4/3] animate-pulse" />
            ))}
          </div>
        ) : listings.length > 0 ? (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {listings.map((l) => <ListingCard key={l._id} listing={l} />)}
            </div>

            {totalPages > 1 && (
              <Pagination
                page={filters.page}
                totalPages={totalPages}
                onChange={(p) => {
                  set("page", p);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
              />
            )}
          </>
        ) : (
          <div className="text-center py-20">
            <p className="text-gray-900 font-medium mb-1">Нічого не знайдено</p>
            <p className="text-sm text-gray-500 mb-4">Спробуйте змінити фільтри або категорію</p>
            <button
              onClick={clearAll}
              className="text-sm border border-gray-300 hover:border-gray-900 rounded-full px-4 py-2"
            >
              Очистити фільтри
            </button>
          </div>
        )}
      </div>

      {/* Filters drawer */}
      {filtersOpen && (
        <FiltersDrawer
          filters={filters}
          onClose={() => setFiltersOpen(false)}
          onApply={(next) => {
            setFilters({ ...filters, ...next, page: 1 });
            setSearchInput(next.search ?? filters.search);
            setGuestsInput(next.maxGuests ?? filters.maxGuests);
            setDateInput(next.date ?? filters.date);
            setFiltersOpen(false);
          }}
          onClear={() => {
            clearAll();
            setFiltersOpen(false);
          }}
        />
      )}
    </div>
  );
};

const Chip = ({ children, onClose }) => (
  <span className="inline-flex items-center gap-1.5 bg-gray-900 text-white px-3 py-1 rounded-full">
    {children}
    <button onClick={onClose} className="opacity-70 hover:opacity-100 ml-0.5" aria-label="remove">
      ✕
    </button>
  </span>
);

const FiltersDrawer = ({ filters, onClose, onApply, onClear }) => {
  const [draft, setDraft] = useState(filters);
  const upd = (k, v) => setDraft((p) => ({ ...p, [k]: v }));

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="flex-1 bg-black/40" onClick={onClose} />
      <div className="w-full max-w-md bg-white shadow-xl flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200">
          <h2 className="text-base font-semibold text-gray-900">Фільтри</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-900 text-lg">
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-5 space-y-6">
          <div>
            <label className="block text-xs uppercase tracking-wide text-gray-500 mb-2">
              Пошук
            </label>
            <input
              type="text"
              placeholder="Назва, адреса"
              value={draft.search}
              onChange={(e) => upd("search", e.target.value)}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wide text-gray-500 mb-2">
              Дата
            </label>
            <input
              type="date"
              value={draft.date}
              onChange={(e) => upd("date", e.target.value)}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wide text-gray-500 mb-2">
              Ціна за годину
            </label>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                placeholder="Від, грн"
                value={draft.minPrice}
                onChange={(e) => upd("minPrice", e.target.value)}
                className="border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
              />
              <input
                type="number"
                placeholder="До, грн"
                value={draft.maxPrice}
                onChange={(e) => upd("maxPrice", e.target.value)}
                className="border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wide text-gray-500 mb-2">
              Кількість гостей
            </label>
            <input
              type="number"
              min="1"
              placeholder="Будь-яка"
              value={draft.maxGuests}
              onChange={(e) => upd("maxGuests", e.target.value)}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
            />
          </div>
        </div>

        <div className="flex items-center justify-between gap-2 px-5 py-4 border-t border-gray-200">
          <button
            onClick={onClear}
            className="text-sm text-gray-700 underline hover:text-gray-900"
          >
            Очистити
          </button>
          <button
            onClick={() => onApply(draft)}
            className="bg-gray-900 hover:bg-black text-white text-sm px-6 py-2.5 rounded-full"
          >
            Показати результати
          </button>
        </div>
      </div>
    </div>
  );
};

export default SearchResults;
