import { Link } from "react-router-dom";

const PricingPage = () => (
  <div className="max-w-3xl mx-auto px-4 py-12">
    <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">Тарифи</p>
    <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Прозора та чесна оплата</h1>
    <p className="text-gray-500 text-sm mb-10">Без прихованих платежів. Платіть тільки тоді, коли отримуєте бронювання.</p>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
      <div className="border border-gray-200 rounded-xl p-6">
        <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">Для гостей</p>
        <p className="text-3xl font-bold text-gray-900 mb-1">0 грн</p>
        <p className="text-sm text-gray-500 mb-5">За реєстрацію та пошук</p>
        <ul className="space-y-2 text-sm text-gray-600">
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> Необмежений пошук локацій</li>
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> Безкоштовна реєстрація</li>
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> Оплата тільки за бронювання</li>
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> Захищені платежі через Stripe</li>
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> Повернення коштів при скасуванні</li>
        </ul>
      </div>

      <div className="border-2 border-gray-900 rounded-xl p-6">
        <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">Для власників</p>
        <p className="text-3xl font-bold text-gray-900 mb-1">10%</p>
        <p className="text-sm text-gray-500 mb-5">Комісія з кожного бронювання</p>
        <ul className="space-y-2 text-sm text-gray-600">
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> 0 грн за реєстрацію</li>
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> 0 грн за публікацію локацій</li>
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> 10% з підтвердженого бронювання</li>
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> Виплати протягом 1–3 робочих днів</li>
          <li className="flex items-start gap-2"><span className="text-gray-900 mt-0.5">✓</span> Без щомісячних платежів</li>
        </ul>
      </div>
    </div>

    <section className="mb-10">
      <h2 className="text-xl font-semibold text-gray-900 mb-4">Як розраховується виплата</h2>
      <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 text-sm text-gray-600 space-y-3">
        <p>Приклад: гість бронює простір на 3 години за <b>500 грн/год</b>.</p>
        <div className="space-y-1.5 border-t border-gray-200 pt-3">
          <div className="flex justify-between"><span>Сума від гостя</span><span className="text-gray-900 font-medium">1 500 грн</span></div>
          <div className="flex justify-between"><span>Комісія Basik (10%)</span><span className="text-gray-900 font-medium">−150 грн</span></div>
          <div className="flex justify-between border-t border-gray-200 pt-2 font-semibold text-gray-900"><span>Ваш заробіток</span><span>1 350 грн</span></div>
        </div>
      </div>
    </section>

    <section className="mb-10">
      <h2 className="text-xl font-semibold text-gray-900 mb-4">Часті питання про тарифи</h2>
      <div className="space-y-0 divide-y divide-gray-200">
        {[
          { q: "Коли знімається комісія?", a: "Комісія утримується автоматично з кожного підтвердженого бронювання. Ви отримуєте суму вже за вирахуванням." },
          { q: "Як я отримаю гроші?", a: "Виплати здійснюються на українську банківську картку або рахунок протягом 1–3 робочих днів після завершення бронювання." },
          { q: "Що відбувається при скасуванні?", a: "Якщо гість скасовує — кошти повертаються йому, комісія не утримується. Якщо власник скасовує — кошти повертаються гостю повністю." },
          { q: "Чи є додаткові збори?", a: "Ні. Ви платите лише 10% комісії від підтверджених бронювань. Реєстрація, публікація та підтримка — безкоштовні." },
        ].map(({ q, a }) => (
          <div key={q} className="py-4">
            <p className="font-medium text-gray-900 mb-1">{q}</p>
            <p className="text-sm text-gray-600">{a}</p>
          </div>
        ))}
      </div>
    </section>

    <div className="p-6 bg-gray-50 rounded-xl border border-gray-200 text-center">
      <p className="text-sm text-gray-600 mb-3">Готові почати заробляти?</p>
      <Link to="/register-host" className="inline-block bg-gray-900 hover:bg-black text-white text-sm font-medium px-6 py-3 rounded-full transition">
        Стати власником
      </Link>
    </div>
  </div>
);

export default PricingPage;
