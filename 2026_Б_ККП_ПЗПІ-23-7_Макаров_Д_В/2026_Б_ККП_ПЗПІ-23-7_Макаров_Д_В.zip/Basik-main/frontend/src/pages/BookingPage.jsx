import { useState, useEffect } from "react";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import axios from "axios";

const BookingPage = ({ auth }) => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [listing, setListing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const date = searchParams.get("date") || "";
  const startTime = parseInt(searchParams.get("startTime"));
  const endTime = parseInt(searchParams.get("endTime"));
  const guests = parseInt(searchParams.get("guests")) || 1;

  const [guestFullName, setGuestFullName] = useState(auth.user?.name || "");
  const [guestEmail, setGuestEmail] = useState(auth.user?.email || "");
  const [guestPhone, setGuestPhone] = useState("");

  // Validate params on mount
  const today = new Date().toISOString().split("T")[0];
  const isDateValid = date && date >= today;
  const isTimeValid = !isNaN(startTime) && !isNaN(endTime) && endTime > startTime;
  const paramsValid = isDateValid && isTimeValid && guests > 0;

  useEffect(() => {
    if (!auth.user) {
      navigate("/auth");
      return;
    }
    fetchListing();
  }, [id]);

  const fetchListing = async () => {
    try {
      const { data } = await axios.get(`/api/listings/${id}`);
      setListing(data);
    } catch {
      setError("Локацію не знайдено");
    } finally {
      setLoading(false);
    }
  };

  const hours = isTimeValid ? endTime - startTime : 0;
  const totalPrice = listing && hours > 0 ? hours * listing.price_per_hour : 0;

  // Fix timezone: parse date as local noon to avoid UTC shift
  const displayDate = date
    ? new Date(date + "T12:00:00").toLocaleDateString("uk-UA")
    : "—";

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!paramsValid) {
      setError("Некоректні дата або час бронювання. Поверніться та виберіть знову.");
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      const { data } = await axios.post("/api/bookings/create", {
        listing_id: id,
        date,
        start_time: startTime,
        end_time: endTime,
        guest_count: guests,
        guestFullName,
        guestEmail,
        guestPhoneNumber: guestPhone,
      });
      if (data.url) window.location.href = data.url;
    } catch (err) {
      setError(err.response?.data?.message || "Помилка створення бронювання");
      setSubmitting(false);
    }
  };

  if (loading) return <div className="text-center py-20 text-gray-400 text-sm">Завантаження...</div>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <button
        onClick={() => navigate(-1)}
        className="text-xs text-gray-500 hover:text-gray-900 mb-6 inline-block"
      >
        ← Назад
      </button>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Підтвердження бронювання</h1>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 text-sm p-3 rounded-lg mb-5">
          {error}
        </div>
      )}

      {!paramsValid && !error && (
        <div className="bg-amber-50 border border-amber-200 text-amber-700 text-sm p-4 rounded-lg mb-5">
          <p className="font-medium mb-1">Некоректні параметри бронювання</p>
          {!isDateValid && <p>• Дата не може бути в минулому</p>}
          {!isTimeValid && <p>• Некоректний час (початок має бути раніше за кінець)</p>}
          <button
            onClick={() => navigate(-1)}
            className="mt-3 text-sm underline underline-offset-4 hover:opacity-70"
          >
            Повернутися та вибрати знову
          </button>
        </div>
      )}

      {listing && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Summary */}
          <div className="border border-gray-200 rounded-xl p-5">
            <h2 className="font-semibold text-gray-900 mb-1">{listing.title}</h2>
            <p className="text-sm text-gray-500 mb-5">{listing.address}</p>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Дата</span>
                <span className="font-medium">{displayDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Час</span>
                <span className="font-medium">
                  {isTimeValid
                    ? `${String(startTime).padStart(2, "0")}:00 – ${String(endTime).padStart(2, "0")}:00`
                    : <span className="text-red-500">Некоректний</span>
                  }
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Тривалість</span>
                <span className="font-medium">{hours > 0 ? `${hours} год` : "—"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Гості</span>
                <span className="font-medium">{guests}</span>
              </div>

              {totalPrice > 0 && (
                <>
                  <hr className="my-2 border-gray-100" />
                  <div className="flex justify-between text-gray-500">
                    <span>{listing.price_per_hour} грн × {hours} год</span>
                    <span>{totalPrice} грн</span>
                  </div>
                  <div className="flex justify-between font-semibold text-gray-900 text-base pt-1">
                    <span>Разом</span>
                    <span>{totalPrice} грн</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Guest form */}
          <form onSubmit={handleSubmit} className="border border-gray-200 rounded-xl p-5 space-y-4">
            <h2 className="font-semibold text-gray-900">Дані гостя</h2>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Ім'я</label>
              <input
                type="text"
                required
                value={guestFullName}
                onChange={(e) => setGuestFullName(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                required
                value={guestEmail}
                onChange={(e) => setGuestEmail(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">
                Телефон <span className="text-gray-400 font-normal">(необов'язково)</span>
              </label>
              <input
                type="tel"
                value={guestPhone}
                onChange={(e) => setGuestPhone(e.target.value)}
                placeholder="+380..."
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
              />
            </div>

            <button
              type="submit"
              disabled={submitting || !paramsValid}
              className="w-full bg-gray-900 hover:bg-black text-white text-sm font-medium py-3 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? "Переспрямування на оплату..." : `Оплатити ${totalPrice} грн`}
            </button>

            <p className="text-xs text-gray-400 text-center">
              Оплата обробляється через безпечний Stripe
            </p>
          </form>
        </div>
      )}
    </div>
  );
};

export default BookingPage;
