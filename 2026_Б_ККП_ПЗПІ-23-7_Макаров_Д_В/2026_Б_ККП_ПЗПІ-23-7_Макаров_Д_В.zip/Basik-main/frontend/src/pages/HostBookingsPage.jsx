import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const statusLabels = {
  pending: "Очікує",
  confirmed: "Підтверджено",
  completed: "Завершено",
  cancelled_by_guest: "Скасовано гостем",
  cancelled_by_host: "Скасовано вами",
  failed: "Помилка",
};

const HostBookingsPage = ({ auth }) => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!auth.user) {
      navigate("/auth");
      return;
    }
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const { data } = await axios.get("/api/bookings/host");
      setBookings(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const cancelBooking = async (bookingId) => {
    if (!window.confirm("Скасувати бронювання?")) return;
    try {
      await axios.post(`/api/bookings/${bookingId}/cancel`);
      fetchBookings();
    } catch (err) {
      alert(err.response?.data?.message || "Помилка");
    }
  };

  if (loading) return <div className="text-center py-20 text-gray-400">Завантаження...</div>;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Бронювання моїх локацій</h1>

      {bookings.length === 0 ? (
        <div className="text-center py-16 text-gray-400">Немає бронювань</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full bg-white rounded-xl border border-gray-100">
            <thead>
              <tr className="text-left text-sm text-gray-500 border-b">
                <th className="px-4 py-3">Локація</th>
                <th className="px-4 py-3">Гість</th>
                <th className="px-4 py-3">Дата</th>
                <th className="px-4 py-3">Час</th>
                <th className="px-4 py-3">Сума</th>
                <th className="px-4 py-3">Статус</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b._id} className="border-b last:border-0 text-sm">
                  <td className="px-4 py-3 font-medium text-gray-800">
                    {b.listing_id?.title || "—"}
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {b.guestFullName || b.guest_id?.name || "—"}
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {new Date(b.date).toLocaleDateString("uk-UA")}
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {b.start_time}:00-{b.end_time}:00
                  </td>
                  <td className="px-4 py-3 font-medium">{b.total_price} грн</td>
                  <td className="px-4 py-3">
                    <span className="text-xs">{statusLabels[b.booking_status] || b.booking_status}</span>
                  </td>
                  <td className="px-4 py-3">
                    {["pending", "confirmed"].includes(b.booking_status) && (
                      <button
                        onClick={() => cancelBooking(b._id)}
                        className="text-red-500 hover:text-red-700 text-xs"
                      >
                        Скасувати
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default HostBookingsPage;
