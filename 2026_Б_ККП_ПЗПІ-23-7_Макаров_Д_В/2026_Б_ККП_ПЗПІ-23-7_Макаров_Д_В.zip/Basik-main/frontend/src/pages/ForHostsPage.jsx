import { Link } from "react-router-dom";

const Section = ({ title, children }) => (
  <section className="mb-10">
    <h2 className="text-xl md:text-2xl font-semibold text-gray-900 mb-3">{title}</h2>
    <div className="text-sm md:text-base text-gray-600 space-y-3 leading-relaxed">{children}</div>
  </section>
);

const ForHostsPage = () => {
  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">Для власників</p>
      <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8">Здайте свій простір на Basik</h1>

      <Section title="Як це працює">
        <p>Basik — платформа, де власники просторів розміщують свої локації, а гості бронюють їх погодинно. Ми беремо на себе пошук гостей, оплату та комунікацію.</p>
        <ol className="list-decimal pl-5 space-y-2">
          <li><b>Зареєструйтеся як власник.</b> Створіть акаунт, підтвердіть пошту та заповніть профіль.</li>
          <li><b>Додайте локацію.</b> Завантажте фото, опишіть простір, вкажіть зручності, графік роботи та ціну за годину.</li>
          <li><b>Отримуйте бронювання.</b> Гості надсилають запити — ви підтверджуєте або відхиляєте їх у панелі власника.</li>
          <li><b>Зустрічайте гостей.</b> Після візиту оплата автоматично переказується на ваш рахунок.</li>
        </ol>
      </Section>

      <Section title="Тарифи">
        <p>Розміщення на Basik — безкоштовне. Ми утримуємо комісію 10% з підтверджених бронювань: вона покриває обробку платежів, підтримку та просування вашої локації.</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>0 грн за реєстрацію та публікацію</li>
          <li>10% комісії з кожного бронювання</li>
          <li>Без щомісячних платежів</li>
          <li>Виплати на українську картку протягом 1–3 робочих днів</li>
        </ul>
      </Section>

      <Section title="Поради для успіху">
        <ul className="list-disc pl-5 space-y-2">
          <li><b>Якісні фото.</b> 6–10 світлих знімків з різних ракурсів привертають у 3 рази більше уваги.</li>
          <li><b>Чіткий опис.</b> Розкажіть, для чого підходить простір: фотозйомка, мітинги, тренінги, дні народження.</li>
          <li><b>Конкурентна ціна.</b> Подивіться на схожі локації у вашому місті — починайте з середньої ціни.</li>
          <li><b>Швидкі відповіді.</b> Власники, які відповідають протягом 1 години, отримують у 2 рази більше бронювань.</li>
          <li><b>Точний графік.</b> Тримайте календар доступності в актуальному стані, щоб уникати скасувань.</li>
        </ul>
      </Section>

      <div className="mt-10 p-6 bg-gray-50 rounded-lg border border-gray-200 text-center">
        <p className="text-sm text-gray-600 mb-3">Готові розпочати?</p>
        <Link
          to="/register-host"
          className="inline-block bg-gray-900 hover:bg-black text-white text-sm font-medium px-6 py-3 rounded-full transition"
        >
          Стати власником
        </Link>
      </div>
    </div>
  );
};

export default ForHostsPage;
