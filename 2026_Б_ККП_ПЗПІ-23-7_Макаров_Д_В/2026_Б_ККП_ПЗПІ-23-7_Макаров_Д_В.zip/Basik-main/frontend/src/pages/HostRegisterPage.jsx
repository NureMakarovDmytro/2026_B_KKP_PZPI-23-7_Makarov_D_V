import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";

const CATEGORIES = [
  "Коворкінг",
  "Конференц-зал",
  "Фотостудія",
  "Спортзал",
  "Подієва локація",
  "Інше",
];

const HostRegisterPage = ({ auth }) => {
  const [step, setStep] = useState("form"); // form | verify
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [city, setCity] = useState("");
  const [category, setCategory] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await axios.post("/api/auth/register", { name, email, role: "Host" });
      setStep("verify");
    } catch (err) {
      setError(err.response?.data?.message || "Помилка реєстрації");
    } finally {
      setLoading(false);
    }
  };

  const verify = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const { data } = await axios.post("/api/auth/verify-email", { email, token: code });
      auth.login(data);
      navigate("/host");
    } catch (err) {
      setError(err.response?.data?.message || "Невірний код");
    } finally {
      setLoading(false);
    }
  };

  if (step === "verify") {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-white border border-gray-200 rounded-2xl p-8">
          <div className="w-12 h-12 rounded-full bg-gray-900 text-white flex items-center justify-center text-lg font-bold mb-5 mx-auto">
            ✉
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2 text-center">
            Перевірте пошту
          </h2>
          <p className="text-sm text-gray-500 mb-6 text-center">
            Ми надіслали 6-значний код на <span className="text-gray-900">{email}</span>
          </p>

          {error && (
            <div className="bg-red-50 text-red-600 text-sm p-3 rounded mb-4">{error}</div>
          )}

          <form onSubmit={verify} className="space-y-4">
            <input
              type="text"
              required
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="000000"
              className="w-full border border-gray-300 rounded-lg px-3 py-3 text-center text-2xl tracking-[0.5em] font-mono focus:outline-none focus:border-gray-900"
            />
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gray-900 hover:bg-black text-white text-sm font-medium py-3 rounded-full transition disabled:opacity-50"
            >
              {loading ? "Перевіряю..." : "Підтвердити"}
            </button>
          </form>

          <button
            onClick={() => { setStep("form"); setCode(""); setError(""); }}
            className="w-full mt-3 text-xs text-gray-500 hover:text-gray-900 underline underline-offset-4"
          >
            Змінити email
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[80vh] grid lg:grid-cols-2">
      {/* Left — marketing */}
      <div className="hidden lg:flex relative overflow-hidden bg-gray-900 text-white">
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1497366216548-37526070297c?w=1600&q=80')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900/95 via-gray-900/85 to-gray-900/70" />
        <div className="relative flex flex-col justify-between p-12 w-full">
          <Link to="/" className="flex items-center gap-2 w-fit">
            <span className="w-8 h-8 rounded-full bg-white text-gray-900 flex items-center justify-center text-sm font-bold">
              B
            </span>
            <span className="text-lg font-semibold">Basik</span>
          </Link>

          <div>
            <h2 className="text-3xl xl:text-4xl font-semibold leading-tight mb-4">
              Здавайте простір.<br />Отримуйте дохід.
            </h2>
            <p className="text-sm text-white/70 max-w-sm mb-8">
              Долучайтеся до сотень власників, які заробляють на простоях своїх просторів.
            </p>
            <ul className="space-y-3 text-sm text-white/80">
              <li className="flex items-start gap-3">
                <span className="text-white">✓</span>
                <span>Реєстрація безкоштовна — комісія лише 10% з бронювань</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-white">✓</span>
                <span>Гарантія захисту до 500 000 ₴ на кожне бронювання</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-white">✓</span>
                <span>Виплати на українську картку через 1–3 робочих дні</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-white">✓</span>
                <span>Підтримка 24/7 та повний контроль над календарем</span>
              </li>
            </ul>
          </div>

          <div className="border-t border-white/10 pt-6 flex items-center gap-4 text-xs text-white/60">
            <p>500+ власників</p>
            <span>·</span>
            <p>4.8 ★ середня оцінка</p>
            <span>·</span>
            <p>10 000+ гостей/міс</p>
          </div>
        </div>
      </div>

      {/* Right — form */}
      <div className="flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">
            Реєстрація власника
          </p>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
            Створіть акаунт власника
          </h1>
          <p className="text-sm text-gray-500 mb-8">
            Декілька кроків — і ваша локація вже на Basik
          </p>

          {error && (
            <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg mb-4">{error}</div>
          )}

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Ім'я</label>
              <input
                type="text"
                required
                placeholder="Олена Ш."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-gray-900 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">Email</label>
              <input
                type="email"
                required
                placeholder="ви@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-gray-900 transition"
              />
              <p className="text-xs text-gray-400 mt-1">Надішлемо одноразовий код для підтвердження</p>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">
                Місто простору <span className="text-gray-400 font-normal">· необов'язково</span>
              </label>
              <input
                type="text"
                placeholder="Київ"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-gray-900 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1.5">
                Тип простору <span className="text-gray-400 font-normal">· необов'язково</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {CATEGORIES.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCategory(category === c ? "" : c)}
                    className={`text-xs px-3 py-1.5 rounded-full border transition ${
                      category === c
                        ? "bg-gray-900 text-white border-gray-900"
                        : "border-gray-300 text-gray-700 hover:border-gray-900"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gray-900 hover:bg-black text-white text-sm font-medium py-3 rounded-full transition disabled:opacity-50 mt-2"
            >
              {loading ? "Створюю акаунт..." : "Створити акаунт власника"}
            </button>

            <p className="text-xs text-gray-400 text-center leading-relaxed">
              Натискаючи «Створити акаунт», ви погоджуєтесь з{" "}
              <Link to="/legal#terms" className="underline hover:text-gray-700">умовами</Link>
              {" "}та{" "}
              <Link to="/legal#privacy" className="underline hover:text-gray-700">політикою приватності</Link>.
            </p>
          </form>

          <div className="mt-8 pt-6 border-t border-gray-200 text-center">
            <p className="text-sm text-gray-500">
              Уже маєте акаунт?{" "}
              <Link to="/auth" className="text-gray-900 font-medium underline underline-offset-4">
                Увійти
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HostRegisterPage;
