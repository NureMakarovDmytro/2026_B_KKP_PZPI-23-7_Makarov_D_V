import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const statusLabels = {
  pending: "Очікує",
  confirmed: "Підтверджено",
  completed: "Завершено",
  cancelled_by_guest: "Скасовано вами",
  cancelled_by_host: "Скасовано власником",
  failed: "Помилка",
};

const statusColors = {
  pending: "bg-yellow-100 text-yellow-700",
  confirmed: "bg-green-100 text-green-700",
  completed: "bg-blue-100 text-blue-700",
  cancelled_by_guest: "bg-red-100 text-red-700",
  cancelled_by_host: "bg-red-100 text-red-700",
  failed: "bg-gray-100 text-gray-700",
};

const BookingsPage = ({ auth }) => {
  const [current, setCurrent] = useState([]);
  const [past, setPast] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("current");
  const navigate = useNavigate();

  useEffect(() => {
    if (!auth.user) {
      navigate("/auth");
      return;
    }
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const { data } = await axios.get("/api/bookings/user");
      setCurrent(data.current || []);
      setPast(data.past || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const cancelBooking = async (bookingId) => {
    if (!window.confirm("Скасувати бронювання?")) return;
    try {
      await axios.post(`/api/bookings/${bookingId}/cancel`);
      fetchBookings();
    } catch (err) {
      alert(err.response?.data?.message || "Помилка скасування");
    }
  };

  const bookings = tab === "current" ? current : past;

  if (loading) return <div className="text-center py-20 text-gray-400">Завантаження...</div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Мої бронювання</h1>

      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setTab("current")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
            tab === "current" ? "bg-indigo-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          Поточні ({current.length})
        </button>
        <button
          onClick={() => setTab("past")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
            tab === "past" ? "bg-indigo-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          Минулі ({past.length})
        </button>
      </div>

      {bookings.length === 0 ? (
        <div className="text-center py-16 text-gray-400">Немає бронювань</div>
      ) : (
        <div className="space-y-4">
          {bookings.map((booking) => (
            <div
              key={booking._id}
              className="bg-white rounded-xl border border-gray-100 p-5 flex flex-col sm:flex-row gap-4"
            >
              <div className="flex-1">
                <Link
                  to={`/listing/${booking.listing_id?._id}`}
                  className="font-semibold text-gray-800 hover:text-indigo-600 transition"
                >
                  {booking.listing_id?.title || "Локація"}
                </Link>
                <p className="text-sm text-gray-500 mt-1">
                  {booking.listing_id?.address}
                </p>
                <div className="flex flex-wrap gap-4 mt-2 text-sm text-gray-600">
                  <span>{new Date(booking.date).toLocaleDateString("uk-UA")}</span>
                  <span>{booking.start_time}:00 - {booking.end_time}:00</span>
                  <span>{booking.guest_count} гостей</span>
                </div>
              </div>
              <div className="flex flex-col items-end justify-between">
                <span className="text-lg font-bold text-gray-800">{booking.total_price} грн</span>
                <span
                  className={`text-xs px-2 py-1 rounded-full font-medium ${
                    statusColors[booking.booking_status] || "bg-gray-100"
                  }`}
                >
                  {statusLabels[booking.booking_status] || booking.booking_status}
                </span>
                {["pending", "confirmed"].includes(booking.booking_status) && (
                  <button
                    onClick={() => cancelBooking(booking._id)}
                    className="text-sm text-red-500 hover:text-red-700 mt-2"
                  >
                    Скасувати
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default BookingsPage;
