import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { getCoverPhoto, makeFallbackHandler } from "../utils/listingImages";

const StatusPill = ({ listing }) => {
  if (!listing.isApproved) {
    return (
      <span className="text-[11px] px-2 py-0.5 rounded-full bg-yellow-50 text-yellow-700 border border-yellow-200">
        На модерації
      </span>
    );
  }
  if (!listing.isListed) {
    return (
      <span className="text-[11px] px-2 py-0.5 rounded-full bg-gray-100 text-gray-600 border border-gray-200">
        Прихована
      </span>
    );
  }
  return (
    <span className="text-[11px] px-2 py-0.5 rounded-full bg-green-50 text-green-700 border border-green-200">
      Опублікована
    </span>
  );
};

const MyListingsPage = ({ auth }) => {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const navigate = useNavigate();

  useEffect(() => {
    if (!auth.user) {
      navigate("/auth");
      return;
    }
    fetchListings();
  }, []);

  const fetchListings = async () => {
    try {
      const { data } = await axios.get("/api/listings/my-listings");
      setListings(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const deleteListing = async (id) => {
    if (!window.confirm("Видалити локацію? Цю дію не можна скасувати.")) return;
    try {
      await axios.delete(`/api/listings/${id}`);
      fetchListings();
    } catch (err) {
      alert(err.response?.data?.message || "Помилка видалення");
    }
  };

  const toggleVisibility = async (listing) => {
    try {
      await axios.put(`/api/listings/${listing._id}`, { isListed: !listing.isListed });
      fetchListings();
    } catch (err) {
      alert(err.response?.data?.message || "Помилка");
    }
  };

  const counts = {
    all: listings.length,
    published: listings.filter((l) => l.isApproved && l.isListed).length,
    pending: listings.filter((l) => !l.isApproved).length,
    hidden: listings.filter((l) => l.isApproved && !l.isListed).length,
  };

  const filtered = listings.filter((l) => {
    if (filter === "published") return l.isApproved && l.isListed;
    if (filter === "pending") return !l.isApproved;
    if (filter === "hidden") return l.isApproved && !l.isListed;
    return true;
  });

  if (loading) {
    return <div className="text-center py-20 text-gray-400 text-sm">Завантаження...</div>;
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6 gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Мої локації</h1>
          <p className="text-sm text-gray-500 mt-1">
            Керуйте своїми просторами та їх станом
          </p>
        </div>
        <Link
          to="/add-listing"
          className="bg-gray-900 hover:bg-black text-white text-sm font-medium px-5 py-2.5 rounded-full transition"
        >
          + Додати локацію
        </Link>
      </div>

      {/* Filter tabs */}
      {listings.length > 0 && (
        <div className="flex gap-1 mb-6 border-b border-gray-200 overflow-x-auto">
          {[
            { v: "all", l: "Усі" },
            { v: "published", l: "Опубліковані" },
            { v: "pending", l: "На модерації" },
            { v: "hidden", l: "Приховані" },
          ].map((t) => (
            <button
              key={t.v}
              onClick={() => setFilter(t.v)}
              className={`px-3 py-2 text-sm whitespace-nowrap border-b-2 -mb-px transition ${
                filter === t.v
                  ? "border-gray-900 text-gray-900 font-medium"
                  : "border-transparent text-gray-500 hover:text-gray-900"
              }`}
            >
              {t.l} <span className="text-gray-400 ml-1">{counts[t.v]}</span>
            </button>
          ))}
        </div>
      )}

      {listings.length === 0 ? (
        <div className="text-center py-20 border border-dashed border-gray-300 rounded-2xl">
          <div className="text-4xl mb-3">🏠</div>
          <p className="text-base font-semibold text-gray-900 mb-1">Поки немає локацій</p>
          <p className="text-sm text-gray-500 mb-5">
            Додайте перший простір, щоб почати отримувати бронювання
          </p>
          <Link
            to="/add-listing"
            className="inline-block bg-gray-900 hover:bg-black text-white text-sm font-medium px-5 py-2.5 rounded-full transition"
          >
            + Додати першу локацію
          </Link>
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-10">У цій категорії немає локацій</p>
      ) : (
        <div className="space-y-3">
          {filtered.map((listing) => (
            <div
              key={listing._id}
              className="bg-white border border-gray-200 rounded-xl p-4 flex flex-col sm:flex-row gap-4 hover:border-gray-400 transition"
            >
              <Link to={`/listing/${listing._id}`} className="block flex-shrink-0">
                <img
                  src={getCoverPhoto(listing)}
                  onError={makeFallbackHandler(listing.category, 0)}
                  alt={listing.title}
                  className="w-full sm:w-44 h-32 sm:h-28 object-cover rounded-lg"
                />
              </Link>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <StatusPill listing={listing} />
                  <span className="text-xs text-gray-500">{listing.category}</span>
                </div>
                <Link
                  to={`/listing/${listing._id}`}
                  className="block font-semibold text-gray-900 hover:underline truncate"
                >
                  {listing.title}
                </Link>
                <p className="text-sm text-gray-500 truncate">{listing.address}</p>
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-sm text-gray-700">
                  <span className="font-medium">{listing.price_per_hour} грн/год</span>
                  <span className="text-gray-500">До {listing.max_guests} гостей</span>
                </div>
              </div>
              <div className="flex sm:flex-col gap-2 sm:items-end justify-end">
                <Link
                  to={`/edit-listing/${listing._id}`}
                  className="text-xs px-3 py-1.5 rounded-full border border-gray-300 hover:border-gray-900 text-gray-700 text-center"
                >
                  Редагувати
                </Link>
                {listing.isApproved && (
                  <button
                    onClick={() => toggleVisibility(listing)}
                    className="text-xs px-3 py-1.5 rounded-full border border-gray-300 hover:border-gray-900 text-gray-700"
                  >
                    {listing.isListed ? "Приховати" : "Опублікувати"}
                  </button>
                )}
                <button
                  onClick={() => deleteListing(listing._id)}
                  className="text-xs px-3 py-1.5 rounded-full border border-gray-300 hover:border-red-500 hover:text-red-600 text-gray-500"
                >
                  Видалити
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyListingsPage;
