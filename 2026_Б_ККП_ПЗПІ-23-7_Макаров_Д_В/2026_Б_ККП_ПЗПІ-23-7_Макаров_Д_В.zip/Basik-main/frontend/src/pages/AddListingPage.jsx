import { useState, useEffect, useCallback } from "react";
import { useNavigate, Link, useParams } from "react-router-dom";
import axios from "axios";
import AddressPicker from "../components/AddressPicker";

const DAYS = ["Неділя", "Понеділок", "Вівторок", "Середа", "Четвер", "П'ятниця", "Субота"];

const Section = ({ id: sid, title: stitle, subtitle, done, children }) => (
  <section id={sid} className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 scroll-mt-20">
    <div className="flex items-start justify-between gap-4 mb-5">
      <div>
        <h2 className="text-base md:text-lg font-semibold text-gray-900">{stitle}</h2>
        {subtitle && <p className="text-xs md:text-sm text-gray-500 mt-1">{subtitle}</p>}
      </div>
      <span
        className={`text-xs px-2.5 py-1 rounded-full border ${
          done
            ? "bg-gray-900 text-white border-gray-900"
            : "border-gray-300 text-gray-400"
        }`}
      >
        {done ? "✓ Готово" : "В очікуванні"}
      </span>
    </div>
    {children}
  </section>
);

const AddListingPage = ({ auth }) => {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const [formData, setFormData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(isEdit);
  const [error, setError] = useState("");

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [address, setAddress] = useState("");
  const [coords, setCoords] = useState({ lat: null, lng: null });
  const [pricePerHour, setPricePerHour] = useState("");
  const [maxGuests, setMaxGuests] = useState("");
  const [category, setCategory] = useState("Коворкінг");
  const [amenitiesSel, setAmenitiesSel] = useState([]);
  const [rules, setRules] = useState([""]);
  const [photos, setPhotos] = useState([]); // new File objects
  const [existingPhotos, setExistingPhotos] = useState([]); // [{url, description}]
  const [availability, setAvailability] = useState(
    Array.from({ length: 7 }, (_, i) => ({
      day_of_week: i,
      open_hour: 9,
      close_hour: 18,
      is_available: i !== 0,
    }))
  );

  useEffect(() => {
    if (!auth.user) {
      navigate("/auth");
      return;
    }
    loadForm();
    if (isEdit) loadListing();
  }, [id]);

  const loadForm = async () => {
    try {
      const { data } = await axios.get("/api/listings/form-data");
      setFormData(data);
    } catch (err) {
      console.error(err);
    }
  };

  const loadListing = async () => {
    try {
      const { data } = await axios.get(`/api/listings/${id}`);
      setTitle(data.title || "");
      setDescription(data.description || "");
      setAddress(data.address || "");
      setCoords({
        lat: data.location?.lat || null,
        lng: data.location?.lng || null,
      });
      setPricePerHour(String(data.price_per_hour || ""));
      setMaxGuests(String(data.max_guests || ""));
      setCategory(data.category || "Коворкінг");
      setAmenitiesSel(data.amenities || []);
      setRules(data.rules?.length ? data.rules : [""]);
      setExistingPhotos(data.photos || []);
      if (data.availability?.length === 7) {
        setAvailability(data.availability);
      }
    } catch (err) {
      setError("Не вдалося завантажити локацію");
    } finally {
      setFetching(false);
    }
  };

  const toggleAmenity = (a) => {
    setAmenitiesSel((p) => p.includes(a) ? p.filter((x) => x !== a) : [...p, a]);
  };

  const updateRule = (i, v) => {
    const next = [...rules];
    next[i] = v;
    setRules(next);
  };

  const updateAv = (day, field, value) => {
    setAvailability((p) =>
      p.map((a) =>
        a.day_of_week === day
          ? { ...a, [field]: field === "is_available" ? value : parseInt(value) }
          : a
      )
    );
  };

  const applyAvToAll = (day) => {
    const src = availability.find((a) => a.day_of_week === day);
    if (!src) return;
    setAvailability((p) =>
      p.map((a) => ({ ...a, open_hour: src.open_hour, close_hour: src.close_hour, is_available: src.is_available }))
    );
  };

  const onAddressChange = useCallback(({ address: a, lat, lng }) => {
    setAddress(a || "");
    setCoords({ lat: lat ?? null, lng: lng ?? null });
  }, []);

  const totalPhotos = photos.length + existingPhotos.length;

  const sec = {
    basics: title.trim() && description.trim() && address.trim() && pricePerHour && maxGuests,
    photos: totalPhotos >= 1,
    amenities: true,
    rules: true,
    availability: availability.some((a) => a.is_available),
  };
  const completed = Object.values(sec).filter(Boolean).length;
  const total = Object.keys(sec).length;

  const submit = async (e) => {
    e.preventDefault();
    if (!sec.basics) {
      setError("Заповніть усі поля у розділі «Основна інформація»");
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    if (!sec.photos) {
      setError("Додайте хоча б одну фотографію");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const data = new FormData();
      data.append("title", title);
      data.append("description", description);
      data.append("address", address);
      if (coords.lat) data.append("lat", coords.lat);
      if (coords.lng) data.append("lng", coords.lng);
      data.append("price_per_hour", pricePerHour);
      data.append("max_guests", maxGuests);
      data.append("category", category);
      data.append("amenities", JSON.stringify(amenitiesSel));
      data.append("rules", JSON.stringify(rules.filter((r) => r.trim())));
      data.append("availability", JSON.stringify(availability));
      photos.forEach((p) => data.append("photos", p));

      if (isEdit) {
        data.append("keptPhotoUrls", JSON.stringify(existingPhotos.map((p) => p.url)));
        await axios.put(`/api/listings/${id}`, data, {
          headers: { "Content-Type": "multipart/form-data" },
        });
      } else {
        await axios.post("/api/listings", data, {
          headers: { "Content-Type": "multipart/form-data" },
        });
      }
      navigate("/my-listings");
    } catch (err) {
      setError(err.response?.data?.message || "Помилка");
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return <div className="text-center py-20 text-gray-400 text-sm">Завантаження локації...</div>;
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/my-listings" className="text-xs text-gray-500 hover:text-gray-900">
            ← Мої локації
          </Link>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mt-2 mb-1">
            {isEdit ? "Редагувати локацію" : "Додати локацію"}
          </h1>
          <p className="text-sm text-gray-500">
            {isEdit
              ? "Зміни збережуться одразу. Якщо потрібна повторна модерація, ми вас сповістимо."
              : "Заповніть інформацію — модерація займає до 24 годин"}
          </p>

          <div className="mt-5 bg-white border border-gray-200 rounded-full p-1 flex items-center gap-1">
            <div className="h-2 flex-1 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-gray-900 transition-all duration-500"
                style={{ width: `${(completed / total) * 100}%` }}
              />
            </div>
            <span className="text-xs text-gray-500 px-2 whitespace-nowrap">
              {completed} / {total}
            </span>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg mb-5">{error}</div>
        )}

        <form onSubmit={submit} className="space-y-5">
          {/* Basics */}
          <Section
            id="basics"
            title="Основна інформація"
            subtitle="Назва, опис, адреса та категорія"
            done={sec.basics}
          >
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  Назва локації
                </label>
                <input
                  type="text"
                  required
                  placeholder="Наприклад: Лофт-студія з вікнами на місто"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") e.preventDefault(); }}
                  maxLength={80}
                  className="w-full border border-gray-300 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-gray-900 transition"
                />
                <p className="text-xs text-gray-400 mt-1">
                  {title.length}/80 · Коротка та зрозуміла назва
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  Опис
                </label>
                <textarea
                  required
                  rows={5}
                  placeholder="Розкажіть, для чого підходить простір, які особливості та переваги..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-gray-900 transition resize-y"
                />
                <p className="text-xs text-gray-400 mt-1">
                  Мінімум 50 символів. Поки: {description.length}
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                  Адреса
                </label>
                <AddressPicker
                  value={address}
                  lat={coords.lat}
                  lng={coords.lng}
                  onChange={onAddressChange}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">
                    Ціна за годину
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      required
                      min="1"
                      placeholder="500"
                      value={pricePerHour}
                      onChange={(e) => setPricePerHour(e.target.value)}
                      className="w-full border border-gray-300 rounded-lg pl-3.5 pr-12 py-2.5 text-sm focus:outline-none focus:border-gray-900"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">
                      грн/год
                    </span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">
                    Макс. гостей
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    placeholder="10"
                    value={maxGuests}
                    onChange={(e) => setMaxGuests(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-gray-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1.5">
                    Категорія
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-gray-900 bg-white"
                  >
                    {(formData?.categories || []).map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </Section>

          {/* Photos */}
          <Section
            id="photos"
            title="Фотографії"
            subtitle="Перше фото буде головним — оберіть найкраще"
            done={sec.photos}
          >
            <label
              htmlFor="photo-input"
              className="block border-2 border-dashed border-gray-300 hover:border-gray-900 rounded-xl p-8 text-center cursor-pointer transition bg-gray-50"
            >
              <div className="text-3xl mb-2">📷</div>
              <p className="text-sm font-medium text-gray-900 mb-1">
                Натисніть, щоб обрати фото
              </p>
              <p className="text-xs text-gray-500">
                JPG, PNG до 5 МБ · Рекомендуємо 6+ фото
              </p>
              <input
                id="photo-input"
                type="file"
                multiple
                accept="image/*"
                onChange={(e) => setPhotos([...photos, ...Array.from(e.target.files)])}
                className="hidden"
              />
            </label>

            {(existingPhotos.length > 0 || photos.length > 0) && (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 mt-4">
                {existingPhotos.map((p, i) => (
                  <div key={`ex-${p.url}`} className="relative group">
                    <img
                      src={p.url}
                      alt=""
                      className="w-full aspect-square object-cover rounded-lg border border-gray-200"
                    />
                    {i === 0 && (
                      <span className="absolute top-1.5 left-1.5 bg-gray-900 text-white text-[10px] px-2 py-0.5 rounded-full">
                        Головне
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => setExistingPhotos(existingPhotos.filter((_, idx) => idx !== i))}
                      className="absolute top-1.5 right-1.5 w-6 h-6 bg-white border border-gray-300 hover:bg-gray-900 hover:text-white text-gray-700 rounded-full text-xs shadow-sm transition"
                    >
                      ×
                    </button>
                  </div>
                ))}
                {photos.map((p, i) => (
                  <div key={`new-${i}`} className="relative group">
                    <img
                      src={URL.createObjectURL(p)}
                      alt=""
                      className="w-full aspect-square object-cover rounded-lg border border-gray-200"
                    />
                    {existingPhotos.length === 0 && i === 0 && (
                      <span className="absolute top-1.5 left-1.5 bg-gray-900 text-white text-[10px] px-2 py-0.5 rounded-full">
                        Головне
                      </span>
                    )}
                    <span className="absolute bottom-1.5 left-1.5 bg-blue-600 text-white text-[10px] px-2 py-0.5 rounded-full">
                      Нове
                    </span>
                    <button
                      type="button"
                      onClick={() => setPhotos(photos.filter((_, idx) => idx !== i))}
                      className="absolute top-1.5 right-1.5 w-6 h-6 bg-white border border-gray-300 hover:bg-gray-900 hover:text-white text-gray-700 rounded-full text-xs shadow-sm transition"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </Section>

          {/* Amenities */}
          <Section
            id="amenities"
            title="Зручності"
            subtitle="Що пропонує ваш простір"
            done={sec.amenities}
          >
            <div className="flex flex-wrap gap-2">
              {(formData?.amenities || []).map((a) => (
                <button
                  key={a}
                  type="button"
                  onClick={() => toggleAmenity(a)}
                  className={`px-4 py-2 rounded-full text-sm border transition ${
                    amenitiesSel.includes(a)
                      ? "bg-gray-900 text-white border-gray-900"
                      : "border-gray-300 text-gray-700 hover:border-gray-900"
                  }`}
                >
                  {amenitiesSel.includes(a) && "✓ "}{a}
                </button>
              ))}
            </div>
            {amenitiesSel.length > 0 && (
              <p className="text-xs text-gray-500 mt-3">
                Обрано: {amenitiesSel.length} зручностей
              </p>
            )}
          </Section>

          {/* Rules */}
          <Section
            id="rules"
            title="Правила"
            subtitle="Що гостям варто знати"
            done={sec.rules}
          >
            <div className="space-y-2">
              {rules.map((r, i) => (
                <div key={i} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Наприклад: Не курити в приміщенні"
                    value={r}
                    onChange={(e) => updateRule(i, e.target.value)}
                    className="flex-1 border border-gray-300 rounded-lg px-3.5 py-2 text-sm focus:outline-none focus:border-gray-900"
                  />
                  {rules.length > 1 && (
                    <button
                      type="button"
                      onClick={() => setRules(rules.filter((_, idx) => idx !== i))}
                      className="w-9 h-9 border border-gray-300 hover:border-red-500 hover:text-red-500 text-gray-400 rounded-lg transition"
                    >
                      ×
                    </button>
                  )}
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setRules([...rules, ""])}
              className="mt-3 text-sm text-gray-700 hover:text-gray-900 font-medium"
            >
              + Додати правило
            </button>
          </Section>

          {/* Availability */}
          <Section
            id="availability"
            title="Графік роботи"
            subtitle="Коли простір доступний для бронювання"
            done={sec.availability}
          >
            <div className="space-y-1.5">
              {availability.map((av) => (
                <div
                  key={av.day_of_week}
                  className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-50"
                >
                  <label className="flex items-center gap-2 w-32 text-sm cursor-pointer">
                    <input
                      type="checkbox"
                      checked={av.is_available}
                      onChange={(e) => updateAv(av.day_of_week, "is_available", e.target.checked)}
                      className="w-4 h-4 accent-gray-900"
                    />
                    <span className={av.is_available ? "text-gray-900" : "text-gray-400"}>
                      {DAYS[av.day_of_week]}
                    </span>
                  </label>
                  {av.is_available ? (
                    <>
                      <select
                        value={av.open_hour}
                        onChange={(e) => updateAv(av.day_of_week, "open_hour", e.target.value)}
                        className="border border-gray-300 rounded-lg px-2.5 py-1.5 text-sm bg-white focus:outline-none focus:border-gray-900"
                      >
                        {Array.from({ length: 24 }, (_, i) => (
                          <option key={i} value={i}>{String(i).padStart(2, "0")}:00</option>
                        ))}
                      </select>
                      <span className="text-gray-300">—</span>
                      <select
                        value={av.close_hour}
                        onChange={(e) => updateAv(av.day_of_week, "close_hour", e.target.value)}
                        className="border border-gray-300 rounded-lg px-2.5 py-1.5 text-sm bg-white focus:outline-none focus:border-gray-900"
                      >
                        {Array.from({ length: 24 }, (_, i) => i + 1).map((h) => (
                          <option key={h} value={h}>{String(h).padStart(2, "0")}:00</option>
                        ))}
                      </select>
                      <button
                        type="button"
                        onClick={() => applyAvToAll(av.day_of_week)}
                        title="Застосувати до всіх днів"
                        className="ml-auto text-xs text-gray-400 hover:text-gray-900 underline underline-offset-2"
                      >
                        До всіх
                      </button>
                    </>
                  ) : (
                    <span className="text-xs text-gray-400 ml-1">Закрито</span>
                  )}
                </div>
              ))}
            </div>
          </Section>

          {/* Submit */}
          <div className="bg-white border border-gray-200 rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-center sm:text-left">
              <p className="text-sm font-medium text-gray-900">
                {completed === total
                  ? isEdit ? "Усе готово до збереження" : "Усе готово до публікації"
                  : `Заповнено ${completed} з ${total} розділів`}
              </p>
              <p className="text-xs text-gray-500">
                {isEdit
                  ? "Зміни збережуться одразу"
                  : "Після надсилання локація потрапить на модерацію"}
              </p>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Link
                to="/my-listings"
                className="flex-1 sm:flex-none text-center border border-gray-300 hover:border-gray-900 text-gray-900 text-sm font-medium px-5 py-2.5 rounded-full transition"
              >
                Скасувати
              </Link>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 sm:flex-none bg-gray-900 hover:bg-black text-white text-sm font-medium px-6 py-2.5 rounded-full disabled:opacity-50 transition"
              >
                {loading
                  ? (isEdit ? "Збереження..." : "Створення...")
                  : (isEdit ? "Зберегти зміни" : "Опублікувати локацію")}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddListingPage;
