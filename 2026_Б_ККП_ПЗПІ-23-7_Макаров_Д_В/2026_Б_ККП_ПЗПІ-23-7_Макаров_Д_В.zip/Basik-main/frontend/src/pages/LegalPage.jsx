import { useEffect } from "react";
import { useLocation } from "react-router-dom";

const Section = ({ id, title, children }) => (
  <section id={id} className="mb-12 scroll-mt-24">
    <h2 className="text-xl md:text-2xl font-semibold text-gray-900 mb-4">{title}</h2>
    <div className="text-sm md:text-base text-gray-600 space-y-3 leading-relaxed">
      {children}
    </div>
  </section>
);

const LegalPage = () => {
  const { hash } = useLocation();

  useEffect(() => {
    if (hash) {
      const el = document.querySelector(hash);
      if (el) el.scrollIntoView({ behavior: "smooth" });
    } else {
      window.scrollTo(0, 0);
    }
  }, [hash]);

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">Юридична інформація</p>
      <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">Умови, приватність та cookies</h1>
      <p className="text-sm text-gray-400 mb-10">Останнє оновлення: травень 2026</p>

      <nav className="flex flex-wrap gap-2 mb-10 pb-6 border-b border-gray-200">
        <a href="#terms" className="text-xs px-3 py-1.5 rounded-full border border-gray-300 hover:border-gray-900 text-gray-700">Умови</a>
        <a href="#privacy" className="text-xs px-3 py-1.5 rounded-full border border-gray-300 hover:border-gray-900 text-gray-700">Приватність</a>
        <a href="#cookies" className="text-xs px-3 py-1.5 rounded-full border border-gray-300 hover:border-gray-900 text-gray-700">Cookies</a>
      </nav>

      <Section id="terms" title="Умови користування">
        <p>Користуючись Basik, ви погоджуєтеся з умовами цього договору. Basik — це платформа, що поєднує власників просторів та гостей, які бажають орендувати ці простори погодинно.</p>
        <p><b>Реєстрація.</b> Для бронювання чи розміщення локацій потрібен підтверджений акаунт. Ви несете відповідальність за збереження доступу до нього.</p>
        <p><b>Бронювання.</b> Підтверджуючи бронювання, гість погоджується з правилами власника. Власник зобов'язаний надати простір у заявленому стані.</p>
        <p><b>Оплата та комісія.</b> Basik утримує комісію 10% з кожного підтвердженого бронювання. Виплати здійснюються на українську картку протягом 1–3 робочих днів.</p>
        <p><b>Скасування.</b> Безкоштовне скасування доступне за 24 години до візиту. Пізніше може стягуватися комісія залежно від політики власника.</p>
        <p><b>Заборонене використання.</b> Будь-яка незаконна діяльність, шахрайство та порушення прав третіх осіб призводять до блокування акаунту.</p>
      </Section>

      <Section id="privacy" title="Політика приватності">
        <p>Ми поважаємо вашу приватність та обробляємо персональні дані відповідно до законодавства України та GDPR.</p>
        <p><b>Які дані збираємо:</b> ім'я, email, телефон, дані для виплат (для власників), історію бронювань та технічні логи (IP, тип пристрою).</p>
        <p><b>Для чого використовуємо:</b> підтвердження особи, обробка бронювань та платежів, підтримка користувачів, покращення сервісу.</p>
        <p><b>З ким ділимось:</b> платіжний провайдер (для обробки оплати), email-сервіс (для повідомлень). Ми не продаємо дані третім особам.</p>
        <p><b>Ваші права:</b> ви можете запросити перегляд, виправлення або видалення даних — напишіть на support@basik.com.</p>
        <p><b>Зберігання.</b> Дані бронювань зберігаються до 3 років після останньої активності для бухгалтерських та юридичних потреб.</p>
      </Section>

      <Section id="cookies" title="Файли cookies">
        <p>Basik використовує cookies, щоб ви могли залишатися авторизованими та щоб ми могли покращувати сервіс.</p>
        <p><b>Необхідні cookies.</b> Зберігають вашу сесію та налаштування. Без них сайт не працюватиме.</p>
        <p><b>Аналітичні cookies.</b> Допомагають зрозуміти, які функції популярні. Дані анонімні.</p>
        <p><b>Маркетингові cookies.</b> Ми їх <i>не</i> використовуємо — Basik не показує реклами.</p>
        <p>Ви можете відключити cookies у налаштуваннях браузера, але це може зламати авторизацію та бронювання.</p>
      </Section>
    </div>
  );
};

export default LegalPage;
