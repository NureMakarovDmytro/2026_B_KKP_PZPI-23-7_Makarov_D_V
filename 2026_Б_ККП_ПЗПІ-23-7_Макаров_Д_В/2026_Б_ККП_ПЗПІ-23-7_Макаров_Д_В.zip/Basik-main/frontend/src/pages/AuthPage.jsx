import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import axios from "axios";

const AuthPage = ({ auth }) => {
  const [params, setParams] = useSearchParams();
  const mode = params.get("mode") === "register"
    ? "register"
    : params.get("mode") === "verify"
    ? "verify"
    : "login";
  const emailFromUrl = params.get("email") || "";

  const [email, setEmail] = useState(emailFromUrl);
  const [name, setName] = useState("");
  const [role, setRole] = useState("Guest");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const goToVerify = (e) => {
    setParams({ mode: "verify", email: e });
    setCode("");
    setError("");
  };

  const submitRegister = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await axios.post("/api/auth/register", { name, email, role });
      goToVerify(email);
    } catch (err) {
      setError(err.response?.data?.message || "Помилка");
    } finally {
      setLoading(false);
    }
  };

  const submitLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await axios.post("/api/auth/email-login", { email });
      goToVerify(email);
    } catch (err) {
      setError(err.response?.data?.message || "Помилка");
    } finally {
      setLoading(false);
    }
  };

  const submitVerify = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const { data } = await axios.post("/api/auth/verify-email", {
        email: emailFromUrl || email,
        token: code,
      });
      auth.login(data);
      if (data.role === "Host") navigate("/host");
      else if (data.role === "Admin") navigate("/admin");
      else navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Невірний код");
    } finally {
      setLoading(false);
    }
  };

  const setMode = (m) => {
    setError("");
    setParams(m === "login" ? {} : { mode: m });
  };

  const googleLogin = () => {
    window.location.href = "/api/auth/google";
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-white border border-gray-200 rounded-lg p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-5 text-center">
          {mode === "register" && "Реєстрація"}
          {mode === "login" && "Вхід"}
          {mode === "verify" && "Підтвердження"}
        </h2>

        {error && (
          <div className="bg-red-50 text-red-600 text-sm p-2.5 rounded mb-4">{error}</div>
        )}

        {mode === "register" && (
          <form onSubmit={submitRegister} className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setRole("Guest")}
                className={`py-2 rounded border text-sm ${
                  role === "Guest"
                    ? "bg-gray-900 text-white border-gray-900"
                    : "bg-white text-gray-700 border-gray-300"
                }`}
              >
                Гість
              </button>
              <button
                type="button"
                onClick={() => setRole("Host")}
                className={`py-2 rounded border text-sm ${
                  role === "Host"
                    ? "bg-gray-900 text-white border-gray-900"
                    : "bg-white text-gray-700 border-gray-300"
                }`}
              >
                Власник
              </button>
            </div>
            <input
              type="text"
              required
              placeholder="Ім'я"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
            />
            <input
              type="email"
              required
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
            />
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gray-900 hover:bg-black text-white text-sm py-2.5 rounded disabled:opacity-50"
            >
              {loading ? "..." : "Зареєструватися"}
            </button>
          </form>
        )}

        {mode === "login" && (
          <form onSubmit={submitLogin} className="space-y-3">
            <input
              type="email"
              required
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-gray-900"
            />
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gray-900 hover:bg-black text-white text-sm py-2.5 rounded disabled:opacity-50"
            >
              {loading ? "..." : "Увійти"}
            </button>
          </form>
        )}

        {mode === "verify" && (
          <form onSubmit={submitVerify} className="space-y-3">
            <p className="text-sm text-gray-500 text-center">
              Код надіслано на <span className="text-gray-900">{emailFromUrl || email}</span>
            </p>
            <input
              type="text"
              required
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full border border-gray-300 rounded px-3 py-2 text-center text-lg tracking-[0.4em] focus:outline-none focus:border-gray-900"
              placeholder="000000"
            />
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gray-900 hover:bg-black text-white text-sm py-2.5 rounded disabled:opacity-50"
            >
              {loading ? "..." : "Підтвердити"}
            </button>
            <button
              type="button"
              onClick={() => setMode("login")}
              className="w-full text-xs text-gray-500 hover:text-gray-900 underline pt-1"
            >
              Інший email
            </button>
          </form>
        )}

        {mode !== "verify" && (
          <>
            <div className="flex items-center gap-2 my-4">
              <hr className="flex-1 border-gray-200" />
              <span className="text-xs text-gray-400">або</span>
              <hr className="flex-1 border-gray-200" />
            </div>
            <button
              onClick={googleLogin}
              className="w-full border border-gray-300 text-gray-700 text-sm py-2.5 rounded hover:bg-gray-50"
            >
              Увійти через Google
            </button>
            <p className="text-center text-xs text-gray-500 mt-4">
              {mode === "login" ? (
                <>
                  Немає акаунту?{" "}
                  <button onClick={() => setMode("register")} className="text-gray-900 underline">
                    Зареєструватися
                  </button>
                </>
              ) : (
                <>
                  Вже є акаунт?{" "}
                  <button onClick={() => setMode("login")} className="text-gray-900 underline">
                    Увійти
                  </button>
                </>
              )}
            </p>
          </>
        )}
      </div>
    </div>
  );
};

export default AuthPage;
