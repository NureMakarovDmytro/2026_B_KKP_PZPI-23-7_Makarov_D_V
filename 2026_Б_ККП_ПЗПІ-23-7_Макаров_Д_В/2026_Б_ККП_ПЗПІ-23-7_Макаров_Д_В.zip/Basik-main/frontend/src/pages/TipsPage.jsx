import { Link } from "react-router-dom";

const Tip = ({ num, title, children }) => (
  <div className="flex gap-4 pb-8 border-b border-gray-100 last:border-0">
    <span className="w-8 h-8 rounded-full bg-gray-900 text-white text-sm font-bold flex items-center justify-center shrink-0 mt-0.5">{num}</span>
    <div>
      <p className="font-semibold text-gray-900 mb-1">{title}</p>
      <p className="text-sm text-gray-600 leading-relaxed">{children}</p>
    </div>
  </div>
);

const TipsPage = () => (
  <div className="max-w-3xl mx-auto px-4 py-12">
    <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 mb-2">Поради</p>
    <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Як залучити більше гостей</h1>
    <p className="text-gray-500 text-sm mb-10">Перевірені поради від власників, які регулярно отримують бронювання на Basik.</p>

    <section className="mb-12">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Оголошення та фото</h2>
      <div className="space-y-0">
        <Tip num={1} title="Зробіть якісні фотографії">
          Локації з 6+ яскравими фото отримують втричі більше переглядів. Знімайте вдень при природному освітленні з різних ракурсів — покажіть вхід, основний простір, деталі та зони відпочинку.
        </Tip>
        <Tip num={2} title="Напишіть чіткий опис">
          Вкажіть для чого підходить простір: мітинги, фотозйомки, тренінги, дні народження. Опишіть, що є в приміщенні, скільки людей поміститься і які є правила.
        </Tip>
        <Tip num={3} title="Встановіть конкурентну ціну">
          Перегляньте схожі локації у вашому місті. Починайте з середньої ціни — після перших позитивних відгуків можна підвищити.
        </Tip>
        <Tip num={4} title="Заповніть усі зручності">
          Гості фільтрують пошук за зручностями. Якщо у вас є Wi-Fi, проєктор, кондиціонер — обов'язково вкажіть це.
        </Tip>
      </div>
    </section>

    <section className="mb-12">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Робота з гостями</h2>
      <div className="space-y-0">
        <Tip num={5} title="Відповідайте швидко">
          Власники, які відповідають протягом години, отримують вдвічі більше бронювань. Увімкніть сповіщення, щоб не пропускати запити.
        </Tip>
        <Tip num={6} title="Тримайте календар актуальним">
          Оновлюйте доступність щотижня. Гості не будуть бронювати, якщо бачать, що дати закриті без причини.
        </Tip>
        <Tip num={7} title="Підготуйте простір до візиту">
          Чистота та порядок — основа хорошого відгуку. Перевіряйте, щоб все заявлене обладнання працювало.
        </Tip>
        <Tip num={8} title="Попросіть залишити відгук">
          Після успішного бронювання попросіть гостя залишити відгук. Позитивні відгуки піднімають вашу локацію у пошуку.
        </Tip>
      </div>
    </section>

    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-12">
      {[
        { stat: "3×", label: "більше переглядів з якісними фото" },
        { stat: "2×", label: "більше бронювань при швидких відповідях" },
        { stat: "90%", label: "гостей повертаються до перевірених локацій" },
      ].map(({ stat, label }) => (
        <div key={stat} className="border border-gray-200 rounded-xl p-5 text-center">
          <p className="text-3xl font-bold text-gray-900 mb-1">{stat}</p>
          <p className="text-xs text-gray-500">{label}</p>
        </div>
      ))}
    </div>

    <div className="p-6 bg-gray-50 rounded-xl border border-gray-200 text-center">
      <p className="text-sm text-gray-600 mb-3">Ще не розмістили локацію?</p>
      <Link to="/register-host" className="inline-block bg-gray-900 hover:bg-black text-white text-sm font-medium px-6 py-3 rounded-full transition">
        Здати простір
      </Link>
    </div>
  </div>
);

export default TipsPage;
