import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import axios from "axios";
import { CheckCircleIcon, XCircleIcon } from "@heroicons/react/24/outline";

const PaymentStatusPage = ({ auth, status }) => {
  const [searchParams] = useSearchParams();
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(status === "success");

  useEffect(() => {
    if (status === "success") {
      const sessionId = searchParams.get("session_id");
      if (sessionId) {
        handleSuccess(sessionId);
      }
    }
  }, []);

  const handleSuccess = async (sessionId) => {
    try {
      const { data } = await axios.get(`/api/bookings/success?session_id=${sessionId}`);
      setBooking(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center py-20 text-gray-400">Обробка оплати...</div>;
  }

  return (
    <div className="min-h-[60vh] flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        {status === "success" ? (
          <>
            <CheckCircleIcon className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Оплата успішна!</h1>
            <p className="text-gray-600 mb-6">
              Ваше бронювання підтверджено. Деталі надіслано на email.
            </p>
            {booking && (
              <div className="bg-gray-50 rounded-xl p-4 mb-6 text-sm text-left">
                <p>
                  <strong>Дата:</strong> {new Date(booking.date).toLocaleDateString("uk-UA")}
                </p>
                <p>
                  <strong>Час:</strong> {booking.start_time}:00 - {booking.end_time}:00
                </p>
                <p>
                  <strong>Сума:</strong> {booking.total_price} грн
                </p>
              </div>
            )}
            <Link
              to="/bookings"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2.5 rounded-lg transition inline-block"
            >
              Мої бронювання
            </Link>
          </>
        ) : (
          <>
            <XCircleIcon className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Оплату скасовано</h1>
            <p className="text-gray-600 mb-6">Спробуйте ще раз або оберіть іншу локацію.</p>
            <Link
              to="/search"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2.5 rounded-lg transition inline-block"
            >
              Пошук локацій
            </Link>
          </>
        )}
      </div>
    </div>
  );
};

export default PaymentStatusPage;
