const CATEGORY_IMAGES = {
  "Коворкінг": [
    "https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&q=80",
    "https://images.unsplash.com/photo-1517502884422-41eaead166d4?w=800&q=80",
    "https://images.unsplash.com/photo-1604328698692-f76ea9498e76?w=800&q=80",
    "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&q=80",
    "https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=800&q=80",
  ],
  "Конференц-зал": [
    "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=1200&q=80",
    "https://images.unsplash.com/photo-1431540015161-0bf868a2d407?w=800&q=80",
    "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=800&q=80",
    "https://images.unsplash.com/photo-1540304453527-62f979142a17?w=800&q=80",
    "https://images.unsplash.com/photo-1559223607-a43c990c692c?w=800&q=80",
  ],
  "Фотостудія": [
    "https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=1200&q=80",
    "https://images.unsplash.com/photo-1493863641943-9b68992a8d07?w=800&q=80",
    "https://images.unsplash.com/photo-1554941068-a252680d25d3?w=800&q=80",
    "https://images.unsplash.com/photo-1606293459337-33b1cd5e8b80?w=800&q=80",
    "https://images.unsplash.com/photo-1520962880247-cfaf541c8724?w=800&q=80",
  ],
  "Спортзал": [
    "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200&q=80",
    "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=800&q=80",
    "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=800&q=80",
    "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&q=80",
    "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800&q=80",
  ],
  "Подієва локація": [
    "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=1200&q=80",
    "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=800&q=80",
    "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=800&q=80",
    "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=800&q=80",
    "https://images.unsplash.com/photo-1515169067868-5387ec356754?w=800&q=80",
  ],
  "Інше": [
    "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1200&q=80",
    "https://images.unsplash.com/photo-1497215842964-222b430dc094?w=800&q=80",
    "https://images.unsplash.com/photo-1497366858526-0766cadbe8fa?w=800&q=80",
    "https://images.unsplash.com/photo-1568992687947-868a62a9f521?w=800&q=80",
    "https://images.unsplash.com/photo-1561089489-f13d5e730d72?w=800&q=80",
  ],
};

export const getCategoryFallbacks = (category) =>
  CATEGORY_IMAGES[category] || CATEGORY_IMAGES["Інше"];

export const getListingPhotos = (listing, count = 5) => {
  const real = (listing?.photos || []).map((p) => p.url).filter(Boolean);
  const fallbacks = getCategoryFallbacks(listing?.category);
  const result = [...real];
  let i = 0;
  while (result.length < count && i < fallbacks.length) {
    result.push(fallbacks[i]);
    i++;
  }
  return result.slice(0, count);
};

export const getCoverPhoto = (listing) => {
  const url = listing?.photos?.[0]?.url;
  if (url) return url;
  return getCategoryFallbacks(listing?.category)[0];
};

export const makeFallbackHandler = (category, idx = 0) => (e) => {
  const fb = getCategoryFallbacks(category);
  const target = fb[idx % fb.length];
  if (e.target.src === target) {
    e.target.src = "https://placehold.co/800x600?text=Basik";
  } else {
    e.target.src = target;
  }
};
