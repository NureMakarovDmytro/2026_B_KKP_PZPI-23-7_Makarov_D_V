// Derive approximate coordinates for a listing.
// Uses listing.location if present, otherwise falls back to city centroid + deterministic jitter from address hash.

const CITY_CENTROIDS = {
  "Київ":  { lat: 50.4501, lng: 30.5234 },
  "Львів": { lat: 49.8397, lng: 24.0297 },
  "Одеса": { lat: 46.4825, lng: 30.7233 },
  "Харків": { lat: 49.9935, lng: 36.2304 },
  "Дніпро": { lat: 48.4647, lng: 35.0462 },
};

const DEFAULT_CENTER = { lat: 50.4501, lng: 30.5234 }; // Kyiv

const hashStr = (str = "") => {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
    h |= 0;
  }
  return h;
};

const detectCity = (address = "") => {
  for (const city of Object.keys(CITY_CENTROIDS)) {
    if (address.includes(city)) return city;
  }
  return null;
};

export const getListingCoords = (listing) => {
  if (listing?.location?.lat && listing?.location?.lng) {
    return { lat: listing.location.lat, lng: listing.location.lng };
  }
  const city = detectCity(listing?.address || "");
  const center = city ? CITY_CENTROIDS[city] : DEFAULT_CENTER;
  const seed = hashStr((listing?._id || "") + (listing?.address || ""));
  // Jitter ~0.025 deg ≈ ~2 km
  const dLat = ((seed % 1000) / 1000 - 0.5) * 0.05;
  const dLng = (((seed >> 10) % 1000) / 1000 - 0.5) * 0.07;
  return { lat: center.lat + dLat, lng: center.lng + dLng };
};

export const getCityCenter = (city) =>
  CITY_CENTROIDS[city] || DEFAULT_CENTER;

export { CITY_CENTROIDS, DEFAULT_CENTER };
