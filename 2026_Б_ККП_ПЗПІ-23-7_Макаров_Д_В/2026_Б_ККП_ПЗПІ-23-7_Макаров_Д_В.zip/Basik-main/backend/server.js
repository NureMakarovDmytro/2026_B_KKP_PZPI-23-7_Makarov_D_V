const dotenv = require("dotenv");
dotenv.config();

const app = require("./app");
const connectDB = require("./config/connectDB");
const { verifyConnection } = require("./config/email");

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Basik server running on port ${PORT}`);
  });
  verifyConnection();
});
