const mongoose = require("mongoose");
const dotenv = require("dotenv");
dotenv.config();

const connectDB = require("./config/connectDB");
const User = require("./models/user");
const Listing = require("./models/listing");

const fullWeek = (open = 9, close = 22, closedSundays = false) =>
  Array.from({ length: 7 }, (_, i) => ({
    day_of_week: i,
    open_hour: open,
    close_hour: close,
    is_available: !(closedSundays && i === 0),
  }));

const photoSet = (urls) => urls.map((u, i) => ({ url: u, description: `Фото ${i + 1}` }));

const COWORK = [
  "https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&q=80",
  "https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1200&q=80",
  "https://images.unsplash.com/photo-1604328698692-f76ea9498e76?w=1200&q=80",
  "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=1200&q=80",
  "https://images.unsplash.com/photo-1517502884422-41eaead166d4?w=1200&q=80",
];

const CONFER = [
  "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=1200&q=80",
  "https://images.unsplash.com/photo-1431540015161-0bf868a2d407?w=1200&q=80",
  "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=1200&q=80",
  "https://images.unsplash.com/photo-1540304453527-62f979142a17?w=1200&q=80",
  "https://images.unsplash.com/photo-1559223607-a43c990c692c?w=1200&q=80",
];

const STUDIO = [
  "https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=1200&q=80",
  "https://images.unsplash.com/photo-1493863641943-9b68992a8d07?w=1200&q=80",
  "https://images.unsplash.com/photo-1554941068-a252680d25d3?w=1200&q=80",
  "https://images.unsplash.com/photo-1606293459337-33b1cd5e8b80?w=1200&q=80",
  "https://images.unsplash.com/photo-1520962880247-cfaf541c8724?w=1200&q=80",
];

const GYM = [
  "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200&q=80",
  "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=1200&q=80",
  "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=1200&q=80",
  "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1200&q=80",
  "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1200&q=80",
];

const EVENT = [
  "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=1200&q=80",
  "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=1200&q=80",
  "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=1200&q=80",
  "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=1200&q=80",
  "https://images.unsplash.com/photo-1515169067868-5387ec356754?w=1200&q=80",
];

const OTHER = [
  "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1200&q=80",
  "https://images.unsplash.com/photo-1497215842964-222b430dc094?w=1200&q=80",
  "https://images.unsplash.com/photo-1497366858526-0766cadbe8fa?w=1200&q=80",
  "https://images.unsplash.com/photo-1568992687947-868a62a9f521?w=1200&q=80",
  "https://images.unsplash.com/photo-1561089489-f13d5e730d72?w=1200&q=80",
];

const seedData = async () => {
  await connectDB();
  console.log("Seeding Basik database...");

  const admin = await User.findOneAndUpdate(
    { email: "admin@basik.com" },
    { userId: 100001, name: "Admin Basik", email: "admin@basik.com", role: "Admin", is_verified: true },
    { upsert: true, new: true }
  );
  console.log("Admin:", admin.email);

  const hosts = await Promise.all([
    User.findOneAndUpdate(
      { email: "host@basik.com" },
      { userId: 100002, name: "Іван Хост", email: "host@basik.com", role: "Host", is_verified: true, phone: "+380991234567" },
      { upsert: true, new: true }
    ),
    User.findOneAndUpdate(
      { email: "olena@basik.com" },
      { userId: 100003, name: "Олена Шевченко", email: "olena@basik.com", role: "Host", is_verified: true, phone: "+380501112233" },
      { upsert: true, new: true }
    ),
    User.findOneAndUpdate(
      { email: "studio@basik.com" },
      { userId: 100004, name: "Андрій Студія", email: "studio@basik.com", role: "Host", is_verified: true, phone: "+380671112233" },
      { upsert: true, new: true }
    ),
  ]);
  console.log(`Hosts: ${hosts.length}`);

  const pickHost = (i) => hosts[i % hosts.length]._id;

  const listings = [
    // Coworking — Kyiv
    {
      host_id: pickHost(0),
      title: "Стильний коворкінг у центрі Києва",
      description: "Сучасний коворкінг на Хрещатику. Швидкий Wi-Fi, безкоштовна кава, окремі переговорні. Тиха атмосфера для продуктивної роботи.",
      address: "м. Київ, вул. Хрещатик, 10",
      location: { lat: 50.4501, lng: 30.5234 },
      price_per_hour: 150,
      max_guests: 20,
      category: "Коворкінг",
      amenities: ["Wi-Fi", "Кава/Чай", "Кондиціонер", "Принтер", "Дошка"],
      rules: ["Не їсти за робочим місцем", "Тримати тишу"],
      availability: fullWeek(8, 22, true),
      photos: photoSet(COWORK),
    },
    {
      host_id: pickHost(1),
      title: "Лофт-коворкінг на Подолі",
      description: "Цегляні стіни, велосипеди для гостей, тераса з краєвидом. Ідеально для команди до 10 осіб.",
      address: "м. Київ, вул. Костянтинівська, 18",
      location: { lat: 50.4636, lng: 30.5168 },
      price_per_hour: 200,
      max_guests: 12,
      category: "Коворкінг",
      amenities: ["Wi-Fi", "Кава/Чай", "Тераса", "Кухня"],
      rules: ["Прибирання включено"],
      availability: fullWeek(9, 21),
      photos: photoSet([COWORK[1], COWORK[2], COWORK[3], COWORK[0]]),
    },
    {
      host_id: pickHost(2),
      title: "Mini-коворкінг для 4 осіб",
      description: "Невеликий простір для маленької команди. Все необхідне для повного робочого дня.",
      address: "м. Київ, вул. Велика Васильківська, 72",
      location: { lat: 50.4242, lng: 30.5179 },
      price_per_hour: 90,
      max_guests: 4,
      category: "Коворкінг",
      amenities: ["Wi-Fi", "Кава/Чай", "Принтер"],
      rules: [],
      availability: fullWeek(8, 23),
      photos: photoSet([COWORK[3], COWORK[4], COWORK[0]]),
    },
    {
      host_id: pickHost(0),
      title: "Коворкінг біля Олімпійської",
      description: "12 робочих місць, переговорна, кухня. Поруч метро.",
      address: "м. Київ, вул. Велика Васильківська, 92",
      location: { lat: 50.4304, lng: 30.5188 },
      price_per_hour: 130,
      max_guests: 15,
      category: "Коворкінг",
      amenities: ["Wi-Fi", "Кава/Чай", "Кондиціонер", "Кухня"],
      rules: ["Без алкоголю"],
      availability: fullWeek(8, 22),
      photos: photoSet([COWORK[2], COWORK[1], COWORK[4]]),
    },
    {
      host_id: pickHost(1),
      title: "Коворкінг у Львові з краєвидом",
      description: "У серці старого Львова. Велика тераса, дизайнерські меблі, кав'ярня поруч.",
      address: "м. Львів, вул. Дорошенка, 5",
      location: { lat: 49.8419, lng: 24.0235 },
      price_per_hour: 110,
      max_guests: 10,
      category: "Коворкінг",
      amenities: ["Wi-Fi", "Кава/Чай", "Тераса"],
      rules: [],
      availability: fullWeek(8, 22, true),
      photos: photoSet([COWORK[0], COWORK[3]]),
    },

    // Conference rooms
    {
      host_id: pickHost(0),
      title: "Конференц-зал для 50 осіб",
      description: "Просторий зал з проєктором, мікрофоном та системою відеозв'язку. Підходить для семінарів і презентацій.",
      address: "м. Київ, вул. Велика Васильківська, 25",
      location: { lat: 50.4381, lng: 30.5178 },
      price_per_hour: 500,
      max_guests: 50,
      category: "Конференц-зал",
      amenities: ["Wi-Fi", "Проєктор", "Мікрофон", "Кондиціонер", "Кава/Чай", "Дошка"],
      rules: ["Прибирання після заходу", "Заборонено палити"],
      availability: fullWeek(9, 21, true),
      photos: photoSet(CONFER),
    },
    {
      host_id: pickHost(1),
      title: "Премʼєрний конференц-холл",
      description: "Великий зал з амфітеатром на 120 осіб. LED-екран, професійна аудіосистема, гримерні.",
      address: "м. Київ, просп. Перемоги, 15",
      location: { lat: 50.4543, lng: 30.4655 },
      price_per_hour: 1200,
      max_guests: 120,
      category: "Конференц-зал",
      amenities: ["Wi-Fi", "Проєктор", "Мікрофон", "Кондиціонер", "Освітлення для фото", "Звукоізоляція"],
      rules: ["Reqіstration ID гостей"],
      availability: fullWeek(9, 22),
      photos: photoSet([CONFER[1], CONFER[2], CONFER[3]]),
    },
    {
      host_id: pickHost(2),
      title: "Камерна переговорна на 8 осіб",
      description: "Затишна переговорна зі скляними стінами, ТВ для презентацій, кавою.",
      address: "м. Київ, вул. Антоновича, 50",
      location: { lat: 50.4262, lng: 30.5135 },
      price_per_hour: 200,
      max_guests: 8,
      category: "Конференц-зал",
      amenities: ["Wi-Fi", "Телевізор", "Кава/Чай", "Кондиціонер"],
      rules: [],
      availability: fullWeek(8, 22),
      photos: photoSet([CONFER[4], CONFER[0]]),
    },
    {
      host_id: pickHost(0),
      title: "Конференц-зал у Львові",
      description: "Сучасний зал у бізнес-центрі. Усе необхідне для тренінгів і workshop'ів.",
      address: "м. Львів, вул. Городоцька, 174",
      location: { lat: 49.8264, lng: 23.9981 },
      price_per_hour: 350,
      max_guests: 30,
      category: "Конференц-зал",
      amenities: ["Wi-Fi", "Проєктор", "Мікрофон", "Кава/Чай"],
      rules: [],
      availability: fullWeek(9, 20, true),
      photos: photoSet([CONFER[2], CONFER[3]]),
    },

    // Photo studios
    {
      host_id: pickHost(2),
      title: "Фотостудія з професійним обладнанням",
      description: "Фони 5 кольорів, студійне світло, гримерна, душ. Ідеально для портретів та fashion-зйомок.",
      address: "м. Київ, вул. Саксаганського, 42",
      location: { lat: 50.4368, lng: 30.5103 },
      price_per_hour: 350,
      max_guests: 10,
      category: "Фотостудія",
      amenities: ["Освітлення для фото", "Кондиціонер", "Гардероб", "Wi-Fi", "Душ"],
      rules: ["Обережно з обладнанням", "Прибирання включено"],
      availability: fullWeek(10, 22),
      photos: photoSet(STUDIO),
    },
    {
      host_id: pickHost(2),
      title: "White cyclorama studio",
      description: "Простора циклорама 80м², ідеальна для відеозйомок і кліпів.",
      address: "м. Київ, вул. Кирилівська, 39",
      location: { lat: 50.4823, lng: 30.4731 },
      price_per_hour: 600,
      max_guests: 15,
      category: "Фотостудія",
      amenities: ["Освітлення для фото", "Wi-Fi", "Гардероб", "Кондиціонер"],
      rules: [],
      availability: fullWeek(9, 23),
      photos: photoSet([STUDIO[1], STUDIO[2], STUDIO[3]]),
    },
    {
      host_id: pickHost(1),
      title: "Затишна камерна фотостудія",
      description: "Маленька студія з натуральним світлом, чотирма локаціями та гримеркою.",
      address: "м. Київ, вул. Січових Стрільців, 21",
      location: { lat: 50.4541, lng: 30.5081 },
      price_per_hour: 250,
      max_guests: 6,
      category: "Фотостудія",
      amenities: ["Освітлення для фото", "Гардероб", "Wi-Fi"],
      rules: [],
      availability: fullWeek(10, 21),
      photos: photoSet([STUDIO[3], STUDIO[4]]),
    },
    {
      host_id: pickHost(2),
      title: "Лофт-студія з вікнами на Львів",
      description: "Велика студія з панорамними вікнами та дерев'яною підлогою.",
      address: "м. Львів, вул. Замарстинівська, 79",
      location: { lat: 49.8543, lng: 24.0345 },
      price_per_hour: 280,
      max_guests: 12,
      category: "Фотостудія",
      amenities: ["Освітлення для фото", "Wi-Fi", "Кава/Чай", "Кондиціонер"],
      rules: [],
      availability: fullWeek(10, 22),
      photos: photoSet([STUDIO[4], STUDIO[0]]),
    },

    // Gyms
    {
      host_id: pickHost(0),
      title: "Спортзал з повним інвентарем",
      description: "Тренажерний зал на 250м² з вільними вагами, кардіо-зоною та функціональним блоком.",
      address: "м. Київ, вул. Здолбунівська, 7",
      location: { lat: 50.3974, lng: 30.6147 },
      price_per_hour: 400,
      max_guests: 20,
      category: "Спортзал",
      amenities: ["Кондиціонер", "Душ", "Гардероб", "Wi-Fi"],
      rules: ["Спортивне взуття обов'язкове"],
      availability: fullWeek(7, 23),
      photos: photoSet(GYM),
    },
    {
      host_id: pickHost(1),
      title: "Кросфіт-бокс",
      description: "Зал для функціональних тренувань. Канати, кільця, штанги, бокси.",
      address: "м. Київ, вул. Казимира Малевича, 86",
      location: { lat: 50.4063, lng: 30.5141 },
      price_per_hour: 350,
      max_guests: 15,
      category: "Спортзал",
      amenities: ["Кондиціонер", "Душ", "Гардероб"],
      rules: [],
      availability: fullWeek(6, 23),
      photos: photoSet([GYM[1], GYM[2], GYM[3]]),
    },
    {
      host_id: pickHost(2),
      title: "Йога-студія",
      description: "Простір з дерев'яною підлогою, килимками й тишею. Підходить для йоги, пілатесу, медитації.",
      address: "м. Київ, вул. Володимирська, 51",
      location: { lat: 50.4439, lng: 30.5158 },
      price_per_hour: 200,
      max_guests: 12,
      category: "Спортзал",
      amenities: ["Кондиціонер", "Wi-Fi", "Душ"],
      rules: ["Без взуття"],
      availability: fullWeek(7, 22),
      photos: photoSet([GYM[4], GYM[0]]),
    },
    {
      host_id: pickHost(0),
      title: "Бойовий клуб",
      description: "Зал з рингом, мішками та дзеркалами. Для боксу, MMA, кікбоксингу.",
      address: "м. Одеса, вул. Дерибасівська, 14",
      location: { lat: 46.4853, lng: 30.7411 },
      price_per_hour: 300,
      max_guests: 16,
      category: "Спортзал",
      amenities: ["Кондиціонер", "Душ", "Гардероб"],
      rules: ["Спорядження своє"],
      availability: fullWeek(8, 22),
      photos: photoSet([GYM[2], GYM[3]]),
    },

    // Event venues
    {
      host_id: pickHost(1),
      title: "Бенкетний зал на 80 гостей",
      description: "Класичний інтер'єр з кришталевими люстрами. Ідеально для весіль і ювілеїв.",
      address: "м. Київ, вул. Саксаганського, 12",
      location: { lat: 50.4374, lng: 30.5121 },
      price_per_hour: 800,
      max_guests: 80,
      category: "Подієва локація",
      amenities: ["Кондиціонер", "Освітлення для фото", "Кухня", "Парковка"],
      rules: ["Без феєрверків у приміщенні"],
      availability: fullWeek(10, 24),
      photos: photoSet(EVENT),
    },
    {
      host_id: pickHost(2),
      title: "Лофт-простір для подій",
      description: "Індустріальний лофт 200м² для презентацій, виставок та вечірок.",
      address: "м. Київ, вул. Кирилівська, 102",
      location: { lat: 50.4856, lng: 30.4615 },
      price_per_hour: 700,
      max_guests: 100,
      category: "Подієва локація",
      amenities: ["Wi-Fi", "Освітлення для фото", "Звукоізоляція", "Парковка"],
      rules: ["Закінчення о 23:00"],
      availability: fullWeek(10, 23),
      photos: photoSet([EVENT[1], EVENT[2], EVENT[3]]),
    },
    {
      host_id: pickHost(0),
      title: "Тераса з краєвидом на Дніпро",
      description: "Відкрита тераса для літніх вечірок до 60 осіб. Бар, гриль, lounge-зона.",
      address: "м. Київ, наб. Володимира Івасюка, 4",
      location: { lat: 50.4458, lng: 30.5532 },
      price_per_hour: 600,
      max_guests: 60,
      category: "Подієва локація",
      amenities: ["Тераса", "Парковка", "Wi-Fi", "Кухня"],
      rules: ["Без музики після 22:00"],
      availability: fullWeek(12, 23, true),
      photos: photoSet([EVENT[3], EVENT[4]]),
    },
    {
      host_id: pickHost(1),
      title: "Простір для воркшопів і майстер-класів",
      description: "Світла кімната з великими столами, кухнею і всім інвентарем.",
      address: "м. Львів, вул. Старознесенська, 15",
      location: { lat: 49.8421, lng: 24.0501 },
      price_per_hour: 250,
      max_guests: 25,
      category: "Подієва локація",
      amenities: ["Wi-Fi", "Кухня", "Дошка", "Кава/Чай"],
      rules: [],
      availability: fullWeek(9, 21),
      photos: photoSet([EVENT[2], EVENT[0]]),
    },

    // Other
    {
      host_id: pickHost(2),
      title: "Танцювальна зала з дзеркалами",
      description: "Великий зал з дзеркальною стіною та паркетом. Підходить для репетицій та зйомок.",
      address: "м. Київ, вул. Горького, 47",
      location: { lat: 50.4321, lng: 30.5152 },
      price_per_hour: 220,
      max_guests: 20,
      category: "Інше",
      amenities: ["Кондиціонер", "Wi-Fi", "Гардероб"],
      rules: [],
      availability: fullWeek(8, 23),
      photos: photoSet(OTHER),
    },
    {
      host_id: pickHost(0),
      title: "Кухня для зйомок та кулінарних шоу",
      description: "Професійна кухня з усім обладнанням. Острів, дві духовки, плита.",
      address: "м. Київ, вул. Глибочицька, 32",
      location: { lat: 50.4623, lng: 30.4946 },
      price_per_hour: 450,
      max_guests: 12,
      category: "Інше",
      amenities: ["Кухня", "Wi-Fi", "Освітлення для фото", "Кондиціонер"],
      rules: ["Прибирання після зйомки"],
      availability: fullWeek(9, 22),
      photos: photoSet([OTHER[1], OTHER[2]]),
    },
    {
      host_id: pickHost(1),
      title: "Музична репетиційна база",
      description: "Звукоізольована кімната з drum-kit, підсилювачами та мікрофонами.",
      address: "м. Київ, вул. Олеся Гончара, 5",
      location: { lat: 50.4488, lng: 30.5043 },
      price_per_hour: 180,
      max_guests: 8,
      category: "Інше",
      amenities: ["Звукоізоляція", "Кондиціонер", "Wi-Fi"],
      rules: [],
      availability: fullWeek(10, 24),
      photos: photoSet([OTHER[3], OTHER[4]]),
    },
  ];

  // Wipe and reseed listings
  await Listing.deleteMany({});
  for (const listing of listings) {
    await Listing.create({ ...listing, isListed: true, isApproved: true });
  }

  console.log(`${listings.length} listings seeded`);
  console.log("Seed complete!");
  process.exit(0);
};

seedData().catch((err) => {
  console.error("Seed error:", err);
  process.exit(1);
});
