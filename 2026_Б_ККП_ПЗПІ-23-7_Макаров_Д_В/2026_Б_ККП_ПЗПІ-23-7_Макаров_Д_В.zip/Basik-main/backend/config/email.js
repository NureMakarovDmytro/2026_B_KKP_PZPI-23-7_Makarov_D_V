const nodemailer = require("nodemailer");

const SMTP_SERVER = process.env.BREVO_SMTP_HOST || "smtp-relay.brevo.com";
const PORT = parseInt(process.env.BREVO_SMTP_PORT) || 587;
const LOGIN = process.env.BREVO_SMTP_USER;
const PASSWORD = process.env.BREVO_SMTP_PASS;
const FROM_NAME = process.env.EMAIL_FROM_NAME || "Basik";
const FROM_EMAIL = process.env.EMAIL_FROM;
const SENDER = `"${FROM_NAME}" <${FROM_EMAIL}>`;

const transporter = nodemailer.createTransport({
  host: SMTP_SERVER,
  port: PORT,
  secure: false,
  auth: { user: LOGIN, pass: PASSWORD },
  tls: {
    rejectUnauthorized: false,
  },
});

const send = async ({ to, subject, text, html }) => {
  const info = await transporter.sendMail({ from: SENDER, to, subject, text, html });
  console.log(`✓ Email accepted by SMTP: messageId=${info.messageId} to=${to}`);
  return info;
};

const sendVerificationEmail = (email, token) =>
  send({
    to: email,
    subject: "Basik - Код підтвердження",
    text: `Ваш код підтвердження: ${token}\n\nКод дійсний 1 годину.\nЯкщо це не ви — проігноруйте лист.`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Ласкаво просимо до Basik!</h2>
        <p>Ваш код підтвердження:</p>
        <h1 style="text-align: center; color: #6366f1; letter-spacing: 8px;">${token}</h1>
        <p>Код дійсний протягом 1 години.</p>
      </div>
    `,
  });

const sendBookingConfirmationEmail = (email, booking, listing) =>
  send({
    to: email,
    subject: "Basik - Підтвердження бронювання",
    text: `Бронювання підтверджено. ${listing.title}, ${new Date(booking.date).toLocaleDateString("uk-UA")} ${booking.start_time}:00-${booking.end_time}:00. Сума: ${booking.total_price} грн.`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Бронювання підтверджено!</h2>
        <p><strong>Локація:</strong> ${listing.title}</p>
        <p><strong>Адреса:</strong> ${listing.address}</p>
        <p><strong>Дата:</strong> ${new Date(booking.date).toLocaleDateString("uk-UA")}</p>
        <p><strong>Час:</strong> ${booking.start_time}:00 - ${booking.end_time}:00</p>
        <p><strong>Гості:</strong> ${booking.guest_count}</p>
        <p><strong>Сума:</strong> ${booking.total_price} грн</p>
      </div>
    `,
  });

const sendBookingOwnerNotificationEmail = (email, booking, listing, guestName) =>
  send({
    to: email,
    subject: "Basik - Нове бронювання вашої локації",
    text: `Нове бронювання: ${listing.title}, орендар ${guestName}, ${new Date(booking.date).toLocaleDateString("uk-UA")} ${booking.start_time}:00-${booking.end_time}:00. Сума: ${booking.total_price} грн.`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Нове бронювання!</h2>
        <p><strong>Локація:</strong> ${listing.title}</p>
        <p><strong>Орендар:</strong> ${guestName}</p>
        <p><strong>Дата:</strong> ${new Date(booking.date).toLocaleDateString("uk-UA")}</p>
        <p><strong>Час:</strong> ${booking.start_time}:00 - ${booking.end_time}:00</p>
        <p><strong>Гості:</strong> ${booking.guest_count}</p>
        <p><strong>Сума:</strong> ${booking.total_price} грн</p>
      </div>
    `,
  });

const sendBookingCancellationEmail = (email, booking, listing, refundAmount) =>
  send({
    to: email,
    subject: "Basik - Бронювання скасовано",
    text: `Бронювання ${listing.title} на ${new Date(booking.date).toLocaleDateString("uk-UA")} скасовано. Повернення: ${refundAmount} грн.`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Бронювання скасовано</h2>
        <p><strong>Локація:</strong> ${listing.title}</p>
        <p><strong>Дата:</strong> ${new Date(booking.date).toLocaleDateString("uk-UA")}</p>
        <p><strong>Повернення:</strong> ${refundAmount} грн</p>
      </div>
    `,
  });

const verifyConnection = async () => {
  try {
    await transporter.verify();
    console.log(`✓ Brevo SMTP ready (${SMTP_SERVER}:${PORT}, sender: ${SENDER})`);
  } catch (err) {
    console.error("✗ Brevo SMTP error:", err.message);
  }
};

module.exports = {
  sendVerificationEmail,
  sendBookingConfirmationEmail,
  sendBookingOwnerNotificationEmail,
  sendBookingCancellationEmail,
  verifyConnection,
};
