const cron = require("node-cron");
const Booking = require("../models/booking");

// Run every hour - mark past bookings as completed
cron.schedule("0 * * * *", async () => {
  try {
    const now = new Date();
    const today = now.toISOString().split("T")[0];
    const currentHour = now.getHours();

    const result = await Booking.updateMany(
      {
        booking_status: "confirmed",
        $or: [
          { date: { $lt: new Date(today) } },
          {
            date: new Date(today),
            end_time: { $lte: currentHour },
          },
        ],
      },
      { $set: { booking_status: "completed" } }
    );

    if (result.modifiedCount > 0) {
      console.log(`Completed ${result.modifiedCount} past bookings`);
    }
  } catch (error) {
    console.error("Cron job error:", error.message);
  }
});
