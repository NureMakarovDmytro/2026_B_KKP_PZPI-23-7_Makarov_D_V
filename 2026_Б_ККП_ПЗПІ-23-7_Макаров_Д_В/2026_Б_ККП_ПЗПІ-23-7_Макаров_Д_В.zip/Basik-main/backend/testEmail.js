require("dotenv").config();
const { sendVerificationEmail, verifyConnection } = require("./config/email");

const TO = process.argv[2] || "oleksandr.kulykov@nure.ua";

(async () => {
  await verifyConnection();
  try {
    await sendVerificationEmail(TO, "123456");
    console.log(`✓ Test email sent to ${TO}`);
  } catch (err) {
    console.error("✗ Send failed:", err.message);
    if (err.response) console.error("SMTP response:", err.response);
  }
  process.exit(0);
})();
