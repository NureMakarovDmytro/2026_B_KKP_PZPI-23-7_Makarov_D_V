const User = require("../models/user");

const generateUserId = async () => {
  let userId;
  let exists = true;

  while (exists) {
    userId = Math.floor(100000 + Math.random() * 900000);
    exists = await User.findOne({ userId });
  }

  return userId;
};

module.exports = { generateUserId };
