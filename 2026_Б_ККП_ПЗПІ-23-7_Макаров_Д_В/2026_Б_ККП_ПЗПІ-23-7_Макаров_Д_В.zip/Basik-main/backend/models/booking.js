const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema(
  {
    guest_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    listing_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Listing",
      required: true,
    },
    date: {
      type: Date,
      required: true,
    },
    start_time: {
      type: Number, // Hour (0-23)
      required: true,
      min: 0,
      max: 23,
    },
    end_time: {
      type: Number, // Hour (1-24)
      required: true,
      min: 1,
      max: 24,
    },
    guest_count: {
      type: Number,
      required: true,
      min: 1,
    },
    total_price: {
      type: Number,
      required: true,
    },
    booking_status: {
      type: String,
      enum: [
        "pending",
        "confirmed",
        "cancelled_by_guest",
        "cancelled_by_host",
        "completed",
        "failed",
      ],
      default: "pending",
    },
    guestFullName: {
      type: String,
    },
    guestEmail: {
      type: String,
    },
    guestPhoneNumber: {
      type: String,
    },
    payment_info: {
      transaction_id: { type: String },
      payment_status: {
        type: String,
        enum: ["pending", "completed", "refunded", "failed"],
        default: "pending",
      },
      payment_method: { type: String, default: "stripe" },
      paid_at: { type: Date },
    },
  },
  { timestamps: true }
);

bookingSchema.pre("save", function (next) {
  if (this.end_time <= this.start_time) {
    return next(new Error("end_time must be greater than start_time"));
  }
  next();
});

bookingSchema.index({ guest_id: 1 });
bookingSchema.index({ listing_id: 1 });
bookingSchema.index({ date: 1, listing_id: 1 });

module.exports = mongoose.model("Booking", bookingSchema);
