const mongoose = require("mongoose");

const availabilitySchema = new mongoose.Schema(
  {
    day_of_week: {
      type: Number, // 0=Sunday, 1=Monday, ..., 6=Saturday
      required: true,
      min: 0,
      max: 6,
    },
    open_hour: {
      type: Number,
      required: true,
      min: 0,
      max: 23,
    },
    close_hour: {
      type: Number,
      required: true,
      min: 1,
      max: 24,
    },
    is_available: {
      type: Boolean,
      default: true,
    },
  },
  { _id: false }
);

const listingSchema = new mongoose.Schema(
  {
    host_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    location: {
      lat: { type: Number },
      lng: { type: Number },
    },
    price_per_hour: {
      type: Number,
      required: true,
      min: 0,
    },
    photos: [
      {
        url: { type: String, required: true },
        description: { type: String, default: "" },
      },
    ],
    amenities: [
      {
        type: String,
      },
    ],
    rules: [
      {
        type: String,
      },
    ],
    availability: [availabilitySchema],
    max_guests: {
      type: Number,
      required: true,
      min: 1,
    },
    category: {
      type: String,
      enum: [
        "Коворкінг",
        "Конференц-зал",
        "Фотостудія",
        "Спортзал",
        "Подієва локація",
        "Інше",
      ],
      default: "Інше",
    },
    averageRating: {
      type: Number,
      default: 0,
      min: 0,
      max: 10,
    },
    isListed: {
      type: Boolean,
      default: true,
    },
    isApproved: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

listingSchema.index({ host_id: 1 });
listingSchema.index({ category: 1 });
listingSchema.index({ price_per_hour: 1 });
listingSchema.index(
  { title: "text", description: "text", address: "text" },
  { weights: { title: 3, address: 2, description: 1 } }
);

module.exports = mongoose.model("Listing", listingSchema);
