const checkAdmin = (req, res, next) => {
  if (req.user && req.user.role === "Admin") {
    next();
  } else {
    res.status(403).json({ message: "Доступ тільки для адміністратора" });
  }
};

module.exports = { checkAdmin };
