const jwt = require("jsonwebtoken");
const User = require("../models/user");

const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    try {
      token = req.headers.authorization.split(" ")[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select("-password_hash");

      if (!req.user) {
        return res.status(401).json({ message: "Користувача не знайдено" });
      }

      if (req.user.isBlocked) {
        return res.status(403).json({ message: "Акаунт заблоковано" });
      }

      next();
    } catch (error) {
      return res.status(401).json({ message: "Недійсний токен" });
    }
  } else {
    return res.status(401).json({ message: "Авторизація потрібна" });
  }
};

module.exports = { protect };
