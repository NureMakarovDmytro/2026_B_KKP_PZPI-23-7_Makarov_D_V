const Listing = require("../models/listing");
const Booking = require("../models/booking");
const path = require("path");

// Available amenities and categories for the form
const AMENITIES = [
  "Wi-Fi",
  "Проєктор",
  "Кондиціонер",
  "Парковка",
  "Кухня",
  "Кава/Чай",
  "Дошка",
  "Звукоізоляція",
  "Принтер",
  "Телевізор",
  "Мікрофон",
  "Освітлення для фото",
  "Душ",
  "Гардероб",
  "Ліфт",
  "Охорона",
  "Інвалідний доступ",
  "Тераса",
];

const CATEGORIES = [
  "Коворкінг",
  "Конференц-зал",
  "Фотостудія",
  "Спортзал",
  "Подієва локація",
  "Інше",
];

// GET /api/listings/form-data
const getFormData = async (req, res) => {
  res.json({ amenities: AMENITIES, categories: CATEGORIES });
};

// POST /api/listings
const createListing = async (req, res) => {
  try {
    const {
      title,
      description,
      address,
      lat,
      lng,
      price_per_hour,
      amenities,
      rules,
      availability,
      max_guests,
      category,
    } = req.body;

    const photos = [];
    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        photos.push({
          url: `/public/listing_photos/${file.filename}`,
          description: "",
        });
      }
    }

    const listing = await Listing.create({
      host_id: req.user._id,
      title,
      description,
      address,
      location: { lat: parseFloat(lat) || 0, lng: parseFloat(lng) || 0 },
      price_per_hour: parseFloat(price_per_hour),
      photos,
      amenities: amenities ? JSON.parse(amenities) : [],
      rules: rules ? JSON.parse(rules) : [],
      availability: availability ? JSON.parse(availability) : [],
      max_guests: parseInt(max_guests),
      category: category || "Інше",
    });

    res.status(201).json(listing);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/listings
const getListings = async (req, res) => {
  try {
    const {
      search,
      category,
      minPrice,
      maxPrice,
      amenities,
      maxGuests,
      date,
      startTime,
      endTime,
      sort,
      page = 1,
      limit = 12,
    } = req.query;

    const filter = { isListed: true, isApproved: true };

    if (search) {
      filter.$text = { $search: search };
    }

    if (category) {
      filter.category = category;
    }

    if (minPrice || maxPrice) {
      filter.price_per_hour = {};
      if (minPrice) filter.price_per_hour.$gte = parseFloat(minPrice);
      if (maxPrice) filter.price_per_hour.$lte = parseFloat(maxPrice);
    }

    if (amenities) {
      const amenityList = amenities.split(",");
      filter.amenities = { $all: amenityList };
    }

    if (maxGuests) {
      filter.max_guests = { $gte: parseInt(maxGuests) };
    }

    // Filter out listings that are fully booked for the requested time slot
    let excludeListingIds = [];
    if (date && startTime && endTime) {
      const bookings = await Booking.find({
        date: new Date(date),
        booking_status: { $in: ["pending", "confirmed"] },
        $or: [
          {
            start_time: { $lt: parseInt(endTime) },
            end_time: { $gt: parseInt(startTime) },
          },
        ],
      }).select("listing_id");

      excludeListingIds = bookings.map((b) => b.listing_id);
      if (excludeListingIds.length > 0) {
        filter._id = { $nin: excludeListingIds };
      }
    }

    let sortOption = { createdAt: -1 };
    if (sort === "price_asc") sortOption = { price_per_hour: 1 };
    if (sort === "price_desc") sortOption = { price_per_hour: -1 };

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [listings, total] = await Promise.all([
      Listing.find(filter)
        .sort(sortOption)
        .skip(skip)
        .limit(parseInt(limit))
        .populate("host_id", "name"),
      Listing.countDocuments(filter),
    ]);

    res.json({
      listings,
      totalPages: Math.ceil(total / parseInt(limit)),
      currentPage: parseInt(page),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/listings/:id
const getListingById = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id).populate("host_id", "name email phone");

    if (!listing) {
      return res.status(404).json({ message: "Локацію не знайдено" });
    }

    res.json(listing);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/listings/:id/booked-slots?date=YYYY-MM-DD
const getBookedSlots = async (req, res) => {
  try {
    const { date } = req.query;

    if (!date) {
      return res.status(400).json({ message: "Дата обов'язкова" });
    }

    const bookings = await Booking.find({
      listing_id: req.params.id,
      date: new Date(date),
      booking_status: { $in: ["pending", "confirmed"] },
    }).select("start_time end_time");

    const bookedSlots = bookings.map((b) => ({
      start_time: b.start_time,
      end_time: b.end_time,
    }));

    res.json(bookedSlots);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/listings/my-listings (host)
const getMyListings = async (req, res) => {
  try {
    const listings = await Listing.find({ host_id: req.user._id }).sort({ createdAt: -1 });
    res.json(listings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// PUT /api/listings/:id
const updateListing = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id);

    if (!listing) {
      return res.status(404).json({ message: "Локацію не знайдено" });
    }

    if (listing.host_id.toString() !== req.user._id.toString() && req.user.role !== "Admin") {
      return res.status(403).json({ message: "Немає доступу" });
    }

    const updates = req.body;

    if (updates.amenities && typeof updates.amenities === "string") {
      updates.amenities = JSON.parse(updates.amenities);
    }
    if (updates.rules && typeof updates.rules === "string") {
      updates.rules = JSON.parse(updates.rules);
    }
    if (updates.availability && typeof updates.availability === "string") {
      updates.availability = JSON.parse(updates.availability);
    }

    if (updates.lat !== undefined || updates.lng !== undefined) {
      updates.location = {
        lat: parseFloat(updates.lat) || listing.location?.lat || 0,
        lng: parseFloat(updates.lng) || listing.location?.lng || 0,
      };
      delete updates.lat;
      delete updates.lng;
    }

    let keptPhotos = listing.photos || [];
    let photosChanged = false;
    if (updates.keptPhotoUrls !== undefined) {
      const keepUrls = JSON.parse(updates.keptPhotoUrls);
      keptPhotos = (listing.photos || []).filter((p) => keepUrls.includes(p.url));
      delete updates.keptPhotoUrls;
      photosChanged = true;
    }

    if (req.files && req.files.length > 0) {
      const newPhotos = req.files.map((file) => ({
        url: `/public/listing_photos/${file.filename}`,
        description: "",
      }));
      updates.photos = [...keptPhotos, ...newPhotos];
    } else if (photosChanged) {
      updates.photos = keptPhotos;
    }

    const updated = await Listing.findByIdAndUpdate(req.params.id, updates, { new: true });
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// DELETE /api/listings/:id
const deleteListing = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id);

    if (!listing) {
      return res.status(404).json({ message: "Локацію не знайдено" });
    }

    if (listing.host_id.toString() !== req.user._id.toString() && req.user.role !== "Admin") {
      return res.status(403).json({ message: "Немає доступу" });
    }

    // Check for active bookings
    const activeBookings = await Booking.countDocuments({
      listing_id: listing._id,
      booking_status: { $in: ["pending", "confirmed"] },
    });

    if (activeBookings > 0) {
      listing.isListed = false;
      await listing.save();
      return res.json({ message: "Локацію приховано (є активні бронювання)" });
    }

    await Listing.findByIdAndDelete(req.params.id);
    res.json({ message: "Локацію видалено" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getFormData,
  createListing,
  getListings,
  getListingById,
  getBookedSlots,
  getMyListings,
  updateListing,
  deleteListing,
};
