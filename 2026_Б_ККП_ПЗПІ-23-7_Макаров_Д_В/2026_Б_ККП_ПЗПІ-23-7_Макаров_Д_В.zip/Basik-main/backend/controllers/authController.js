const User = require("../models/user");
const { generateToken, generateEmailVerificationToken } = require("../utilits/generateToken");
const { generateUserId } = require("../utilits/generateId");
const { sendVerificationEmail } = require("../config/email");

const registerUser = async (req, res) => {
  try {
    const { name, email, role } = req.body;

    const exists = await User.findOne({ email });

    // If user exists and already verified — reject
    if (exists && exists.is_verified) {
      return res.status(400).json({ message: "Email вже зареєстровано" });
    }

    const token = generateEmailVerificationToken();
    const expires = new Date(Date.now() + 60 * 60 * 1000);

    let user;
    if (exists && !exists.is_verified) {
      // Resend code to unverified existing user
      exists.emailVerificationToken = token;
      exists.emailVerificationExpires = expires;
      user = await exists.save();
    } else {
      const userId = await generateUserId();
      const userRole = role === "Host" ? "Host" : "Guest";
      user = await User.create({
        userId,
        name,
        email,
        role: userRole,
        emailVerificationToken: token,
        emailVerificationExpires: expires,
      });
    }

    try {
      await sendVerificationEmail(email, token);
      console.log(`✓ Verification email sent to ${email}`);
    } catch (emailErr) {
      console.error(`✗ Failed to send verification email to ${email}:`, emailErr.message);
      return res.status(500).json({ message: "Не вдалося надіслати код. Перевірте email та спробуйте ще раз." });
    }

    res.status(201).json({ message: "Код надіслано", email: user.email });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const emailLogin = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "Користувача не знайдено" });

    const token = generateEmailVerificationToken();
    user.emailVerificationToken = token;
    user.emailVerificationExpires = new Date(Date.now() + 60 * 60 * 1000);
    await user.save();

    await sendVerificationEmail(email, token);
    console.log(`✓ Verification email sent to ${email}`);

    res.json({ message: "Код надіслано", email });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const verifyEmail = async (req, res) => {
  try {
    const { email, token } = req.body;

    const user = await User.findOne({
      email,
      emailVerificationToken: token,
      emailVerificationExpires: { $gt: new Date() },
    });

    if (!user) return res.status(400).json({ message: "Невірний або прострочений код" });

    user.is_verified = true;
    user.emailVerificationToken = undefined;
    user.emailVerificationExpires = undefined;
    await user.save();

    res.json({
      _id: user._id,
      userId: user.userId,
      name: user.name,
      email: user.email,
      role: user.role,
      is_verified: user.is_verified,
      token: generateToken(user._id),
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const googleCallback = (req, res) => {
  const user = req.user;
  const token = generateToken(user._id);

  const userData = encodeURIComponent(
    JSON.stringify({
      _id: user._id,
      userId: user.userId,
      name: user.name,
      email: user.email,
      role: user.role,
      is_verified: user.is_verified,
      token,
    })
  );

  res.redirect(`${process.env.FRONTEND_URL}/auth-success?data=${userData}`);
};

const getCurrentUser = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select("-password_hash");
    if (!user) return res.status(404).json({ message: "Користувача не знайдено" });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  registerUser,
  emailLogin,
  verifyEmail,
  googleCallback,
  getCurrentUser,
};
