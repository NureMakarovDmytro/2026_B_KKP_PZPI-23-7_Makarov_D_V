const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const Booking = require("../models/booking");
const Listing = require("../models/listing");
const User = require("../models/user");
const {
  sendBookingConfirmationEmail,
  sendBookingOwnerNotificationEmail,
  sendBookingCancellationEmail,
} = require("../config/email");

// POST /api/bookings/create
const createBookingWithPayment = async (req, res) => {
  try {
    const { listing_id, date, start_time, end_time, guest_count, guestFullName, guestEmail, guestPhoneNumber } = req.body;

    const listing = await Listing.findById(listing_id);
    if (!listing) {
      return res.status(404).json({ message: "Локацію не знайдено" });
    }

    if (!listing.isListed || !listing.isApproved) {
      return res.status(400).json({ message: "Локація недоступна" });
    }

    if (guest_count > listing.max_guests) {
      return res.status(400).json({ message: `Максимум гостей: ${listing.max_guests}` });
    }

    // Check for overlapping bookings
    const overlapping = await Booking.findOne({
      listing_id,
      date: new Date(date),
      booking_status: { $in: ["pending", "confirmed"] },
      start_time: { $lt: parseInt(end_time) },
      end_time: { $gt: parseInt(start_time) },
    });

    if (overlapping) {
      return res.status(400).json({ message: "Цей часовий слот вже зайнятий" });
    }

    const hours = parseInt(end_time) - parseInt(start_time);
    const total_price = hours * listing.price_per_hour;

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "uah",
            product_data: {
              name: listing.title,
              description: `${new Date(date).toLocaleDateString("uk-UA")} | ${start_time}:00 - ${end_time}:00`,
            },
            unit_amount: Math.round(total_price * 100),
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${process.env.FRONTEND_URL}/booking/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/booking/cancel?session_id={CHECKOUT_SESSION_ID}`,
      metadata: {
        guest_id: req.user._id.toString(),
        listing_id: listing_id,
        date,
        start_time: start_time.toString(),
        end_time: end_time.toString(),
        guest_count: guest_count.toString(),
        total_price: total_price.toString(),
        guestFullName: guestFullName || req.user.name,
        guestEmail: guestEmail || req.user.email,
        guestPhoneNumber: guestPhoneNumber || "",
      },
    });

    res.json({ sessionId: session.id, url: session.url });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/bookings/success
const handlePaymentSuccess = async (req, res) => {
  try {
    const { session_id } = req.query;
    const session = await stripe.checkout.sessions.retrieve(session_id);

    if (session.payment_status !== "paid") {
      return res.status(400).json({ message: "Оплата не завершена" });
    }

    // Check if booking already created
    const existingBooking = await Booking.findOne({
      "payment_info.transaction_id": session.id,
    });

    if (existingBooking) {
      return res.json(existingBooking);
    }

    const meta = session.metadata;

    const booking = await Booking.create({
      guest_id: meta.guest_id,
      listing_id: meta.listing_id,
      date: new Date(meta.date),
      start_time: parseInt(meta.start_time),
      end_time: parseInt(meta.end_time),
      guest_count: parseInt(meta.guest_count),
      total_price: parseFloat(meta.total_price),
      booking_status: "confirmed",
      guestFullName: meta.guestFullName,
      guestEmail: meta.guestEmail,
      guestPhoneNumber: meta.guestPhoneNumber,
      payment_info: {
        transaction_id: session.id,
        payment_status: "completed",
        payment_method: "stripe",
        paid_at: new Date(),
      },
    });

    // Send confirmation emails
    try {
      const listing = await Listing.findById(meta.listing_id).populate("host_id");
      await sendBookingConfirmationEmail(meta.guestEmail, booking, listing);
      if (listing.host_id && listing.host_id.email) {
        await sendBookingOwnerNotificationEmail(
          listing.host_id.email,
          booking,
          listing,
          meta.guestFullName
        );
      }
    } catch (emailErr) {
      console.error("Email send error:", emailErr.message);
    }

    res.json(booking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/bookings/cancel
const handlePaymentCancel = async (req, res) => {
  res.json({ message: "Оплату скасовано" });
};

// GET /api/bookings/user
const getUserBookings = async (req, res) => {
  try {
    const now = new Date();

    const bookings = await Booking.find({ guest_id: req.user._id })
      .populate("listing_id", "title address photos price_per_hour")
      .sort({ date: -1 });

    const current = [];
    const past = [];

    bookings.forEach((b) => {
      if (
        b.booking_status === "completed" ||
        b.booking_status === "cancelled_by_guest" ||
        b.booking_status === "cancelled_by_host" ||
        b.booking_status === "failed"
      ) {
        past.push(b);
      } else {
        current.push(b);
      }
    });

    res.json({ current, past });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// POST /api/bookings/:bookingId/cancel
const cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.bookingId);

    if (!booking) {
      return res.status(404).json({ message: "Бронювання не знайдено" });
    }

    const isGuest = booking.guest_id.toString() === req.user._id.toString();
    const listing = await Listing.findById(booking.listing_id).populate("host_id");
    const isHost = listing && listing.host_id._id.toString() === req.user._id.toString();

    if (!isGuest && !isHost && req.user.role !== "Admin") {
      return res.status(403).json({ message: "Немає доступу" });
    }

    if (!["pending", "confirmed"].includes(booking.booking_status)) {
      return res.status(400).json({ message: "Неможливо скасувати це бронювання" });
    }

    // Process Stripe refund
    let refundAmount = booking.total_price;
    if (booking.payment_info && booking.payment_info.transaction_id) {
      try {
        const session = await stripe.checkout.sessions.retrieve(
          booking.payment_info.transaction_id
        );
        if (session.payment_intent) {
          await stripe.refunds.create({
            payment_intent: session.payment_intent,
            amount: Math.round(refundAmount * 100),
          });
        }
      } catch (stripeErr) {
        console.error("Stripe refund error:", stripeErr.message);
      }
    }

    booking.booking_status = isGuest ? "cancelled_by_guest" : "cancelled_by_host";
    booking.payment_info.payment_status = "refunded";
    await booking.save();

    // Send cancellation email
    try {
      await sendBookingCancellationEmail(
        booking.guestEmail,
        booking,
        listing,
        refundAmount
      );
    } catch (emailErr) {
      console.error("Cancellation email error:", emailErr.message);
    }

    res.json({ message: "Бронювання скасовано", refundAmount });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/bookings/host
const getHostBookings = async (req, res) => {
  try {
    const listings = await Listing.find({ host_id: req.user._id }).select("_id title");
    const listingIds = listings.map((l) => l._id);

    const bookings = await Booking.find({ listing_id: { $in: listingIds } })
      .populate("listing_id", "title address")
      .populate("guest_id", "name email phone")
      .sort({ date: -1 });

    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createBookingWithPayment,
  handlePaymentSuccess,
  handlePaymentCancel,
  getUserBookings,
  cancelBooking,
  getHostBookings,
};
