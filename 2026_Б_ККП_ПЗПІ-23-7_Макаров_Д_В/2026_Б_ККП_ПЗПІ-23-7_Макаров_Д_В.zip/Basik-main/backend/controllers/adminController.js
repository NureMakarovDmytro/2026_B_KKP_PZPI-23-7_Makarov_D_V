const User = require("../models/user");
const Listing = require("../models/listing");
const Booking = require("../models/booking");

// === Users ===

// GET /api/admin/users
const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password_hash").sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET /api/admin/users/:id
const getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password_hash");
    if (!user) return res.status(404).json({ message: "Користувача не знайдено" });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// PUT /api/admin/users/:id
const updateUser = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true }).select(
      "-password_hash"
    );
    if (!user) return res.status(404).json({ message: "Користувача не знайдено" });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// DELETE /api/admin/users/:id
const deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ message: "Користувача не знайдено" });
    res.json({ message: "Користувача видалено" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// PATCH /api/admin/users/:id/block
const toggleUserBlock = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: "Користувача не знайдено" });

    user.isBlocked = !user.isBlocked;
    await user.save();

    res.json({ message: user.isBlocked ? "Заблоковано" : "Розблоковано", user });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// === Listings ===

// GET /api/admin/listings
const getAllListings = async (req, res) => {
  try {
    const listings = await Listing.find()
      .populate("host_id", "name email")
      .sort({ createdAt: -1 });
    res.json(listings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// PATCH /api/admin/listings/:id/approve
const approveListing = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id);
    if (!listing) return res.status(404).json({ message: "Локацію не знайдено" });

    listing.isApproved = !listing.isApproved;
    await listing.save();

    res.json({ message: listing.isApproved ? "Затверджено" : "Відхилено", listing });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// PATCH /api/admin/listings/:id/toggle-listed
const toggleListingListed = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id);
    if (!listing) return res.status(404).json({ message: "Локацію не знайдено" });

    listing.isListed = !listing.isListed;
    await listing.save();

    res.json({ message: listing.isListed ? "Опубліковано" : "Приховано", listing });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// DELETE /api/admin/listings/:id
const deleteListing = async (req, res) => {
  try {
    await Listing.findByIdAndDelete(req.params.id);
    res.json({ message: "Локацію видалено" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// === Bookings ===

// GET /api/admin/bookings
const getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate("listing_id", "title address")
      .populate("guest_id", "name email")
      .sort({ createdAt: -1 });
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// DELETE /api/admin/bookings/:id
const deleteBooking = async (req, res) => {
  try {
    await Booking.findByIdAndDelete(req.params.id);
    res.json({ message: "Бронювання видалено" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// GET /api/admin/stats
const getPlatformStats = async (req, res) => {
  try {
    const [totalUsers, totalListings, totalBookings, totalRevenue] = await Promise.all([
      User.countDocuments(),
      Listing.countDocuments(),
      Booking.countDocuments({ booking_status: { $in: ["confirmed", "completed"] } }),
      Booking.aggregate([
        { $match: { booking_status: { $in: ["confirmed", "completed"] } } },
        { $group: { _id: null, total: { $sum: "$total_price" } } },
      ]),
    ]);

    res.json({
      totalUsers,
      totalListings,
      totalBookings,
      totalRevenue: totalRevenue[0]?.total || 0,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  toggleUserBlock,
  getAllListings,
  approveListing,
  toggleListingListed,
  deleteListing,
  getAllBookings,
  deleteBooking,
  getPlatformStats,
};
