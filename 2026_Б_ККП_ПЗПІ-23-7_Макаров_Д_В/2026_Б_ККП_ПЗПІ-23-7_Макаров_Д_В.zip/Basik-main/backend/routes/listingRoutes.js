const express = require("express");
const multer = require("multer");
const path = require("path");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  getFormData,
  createListing,
  getListings,
  getListingById,
  getBookedSlots,
  getMyListings,
  updateListing,
  deleteListing,
} = require("../controllers/listingController");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../public/listing_photos"));
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1000)}${path.extname(file.originalname)}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const types = /jpeg|jpg|png|webp/;
    const ext = types.test(path.extname(file.originalname).toLowerCase());
    const mime = types.test(file.mimetype);
    if (ext && mime) return cb(null, true);
    cb(new Error("Тільки зображення (jpg, png, webp)"));
  },
});

router.get("/form-data", getFormData);
router.get("/my-listings", protect, getMyListings);
router.get("/", getListings);
router.get("/:id", getListingById);
router.get("/:id/booked-slots", getBookedSlots);
router.post("/", protect, upload.array("photos", 10), createListing);
router.put("/:id", protect, upload.array("photos", 10), updateListing);
router.delete("/:id", protect, deleteListing);

module.exports = router;
