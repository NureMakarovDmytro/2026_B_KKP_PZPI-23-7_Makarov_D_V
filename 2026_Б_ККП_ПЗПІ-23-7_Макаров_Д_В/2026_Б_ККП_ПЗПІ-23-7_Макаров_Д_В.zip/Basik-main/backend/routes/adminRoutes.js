const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { checkAdmin } = require("../middleware/adminMiddleware");
const {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  toggleUserBlock,
  getAllListings,
  approveListing,
  toggleListingListed,
  deleteListing,
  getAllBookings,
  deleteBooking,
  getPlatformStats,
} = require("../controllers/adminController");

router.use(protect, checkAdmin);

router.get("/stats", getPlatformStats);

router.get("/users", getAllUsers);
router.get("/users/:id", getUserById);
router.put("/users/:id", updateUser);
router.delete("/users/:id", deleteUser);
router.patch("/users/:id/block", toggleUserBlock);

router.get("/listings", getAllListings);
router.patch("/listings/:id/approve", approveListing);
router.patch("/listings/:id/toggle-listed", toggleListingListed);
router.delete("/listings/:id", deleteListing);

router.get("/bookings", getAllBookings);
router.delete("/bookings/:id", deleteBooking);

module.exports = router;
