const express = require("express");
const passport = require("passport");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  registerUser,
  emailLogin,
  verifyEmail,
  googleCallback,
  getCurrentUser,
} = require("../controllers/authController");

router.post("/register", registerUser);
router.post("/email-login", emailLogin);
router.post("/verify-email", verifyEmail);
router.get("/me", protect, getCurrentUser);

router.get(
  "/google",
  passport.authenticate("google", { scope: ["profile", "email"] })
);

router.get(
  "/google/callback",
  passport.authenticate("google", { session: false, failureRedirect: "/login" }),
  googleCallback
);

module.exports = router;
