const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  createBookingWithPayment,
  handlePaymentSuccess,
  handlePaymentCancel,
  getUserBookings,
  cancelBooking,
  getHostBookings,
} = require("../controllers/bookingController");

router.post("/create", protect, createBookingWithPayment);
router.get("/success", handlePaymentSuccess);
router.get("/cancel", handlePaymentCancel);
router.get("/user", protect, getUserBookings);
router.get("/host", protect, getHostBookings);
router.post("/:bookingId/cancel", protect, cancelBooking);

module.exports = router;
